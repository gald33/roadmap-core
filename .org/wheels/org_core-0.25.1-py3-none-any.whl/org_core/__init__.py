"""org-core — the org builder.

Installs, verifies and measures a named cast of engineering agent roles into a
repository. See SPEC.md at the repository root; this package is phase 1 of it.
"""

from __future__ import annotations

__version__ = "0.25.1"

ROLE_IDS: tuple[str, ...] = (
    "ceo",
    "dispatcher",
    "builder",
    "reviewer",
    "verifier",
    "checks-watch",
    "registrar",
    "account-manager",
    "methods",
    "doctor",
)

RUNTIMES: tuple[str, ...] = ("fresh", "session", "spawned")
