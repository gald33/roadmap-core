"""`org apply`: write what the plan says, and nothing the plan did not say (SPEC.md §6)."""

from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import __version__
from . import gitfiles as gf
from .lock import INSTALL_LOG_REL, build, write
from .vendor import vendor
from .plan import Plan


class ApplyRefused(Exception):
    pass


@dataclass
class ApplyResult:
    written: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    lock_path: str = ""
    unignored: list[str] = field(default_factory=list)   # negations apply appended so git carries what it wrote (row 93)


def apply_plan(repo: Path, manifest: dict[str, Any], packages: dict[str, Any], plan: Plan, *, overwrite_changed: bool = False) -> ApplyResult:
    blocking = plan.blocking()
    if blocking:
        raise ApplyRefused("plan has blocking entries:\n  " + "\n  ".join(f"{a.status:<10} {a.path}  {a.detail}" for a in blocking))
    changed = [a for a in plan.actions if a.status == "changed"]
    if changed and not overwrite_changed:
        raise ApplyRefused(
            "these files differ from the package and would be overwritten; re-run with --overwrite-changed after reading the diff:\n  "
            + "\n  ".join(f"{a.path}  ({a.diff_lines} diff lines)  {a.detail}" for a in changed)
        )
    result = ApplyResult()
    for a in plan.actions:
        if a.content is None:
            continue
        target = repo / a.path
        if a.status == "unchanged":
            result.skipped.append(a.path)
            continue
        # new, markers-only, upgrade, adopt, and changed-with-flag are all written; nothing else reaches here
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(a.content)
        if a.kind == "setup":
            target.chmod(target.stat().st_mode | 0o111)
        result.written.append(a.path)
    if gf.is_git_repo(repo):
        # what git would ignore, it will never carry to a fresh container: Lucille's `.claude/*` kept the hook out of two
        # PRs while apply and verify both passed (row 93). Unchanged files are checked too — an earlier apply may have
        # written them into the same hole.
        for a in plan.actions:
            if a.content is not None and not gf.tracked(repo, a.path) and gf.ignored(repo, a.path) is not None:
                result.unignored.extend(gf.unignore(repo, a.path))
    lock = build(manifest, packages, plan.actions)
    lock["vendored_wheel"] = str(vendor(repo).relative_to(repo))   # the tool ships with the org (row 54)
    result.lock_path = str(write(repo, lock).relative_to(repo))
    if gf.is_git_repo(repo):
        for rel in (result.lock_path, lock["vendored_wheel"]):
            if not gf.tracked(repo, rel) and gf.ignored(repo, rel) is not None:
                result.unignored.extend(gf.unignore(repo, rel))
    log = repo / INSTALL_LOG_REL
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open("a") as fh:
        fh.write(json.dumps({
            "at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "org_core": __version__,
            "manifest_version": manifest["manifest_version"],
            "written": result.written,
            "skipped": result.skipped,
            "by_status": plan.by_status(),
        }) + "\n")
    return result
