"""checks-core: a production checks registry any org can run (SPEC.md §4 `checks` port; §16 decision 3).

Semantics are Lucille's `post_merge_checks.py`, extracted — not reinvented:

* a check is `{id, title, statement, query, check_after, until, severity, ...}`;
  the query is ONE read-only statement returning a boolean column `ok`, any
  other columns are diagnostics, and an optional `population` column gates
  the verdict: no population → INCONCLUSIVE, never pass or fail;
* `ok` NULL is a FAIL (an aggregate over an empty table says nothing, and
  reading that as fine is the defect this exists to remove);
* before `check_after` a check is PENDING, after `until` it is EXPIRED — and
  an inconclusive check within 14 days of `until` is escalated, because a
  question about to retire unanswered is the state that lets an unverified
  item read as verified;
* the ledger lists every check ever declared as `active` or `retired`, so a
  check deleted without being retired is reported as LOST rather than
  silently gone.

The runner is split so ANY executor works: `plan` says what to run today,
`evaluate` turns rows into verdicts, `record` appends the durable results
line and files or retires issues. `run --executor psql` chains them; a role
whose only production access is the Supabase MCP runs the SQL itself between
`plan` and `evaluate`.
"""

from __future__ import annotations

import datetime as dt
import json
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Any

import yaml

PASS, FAIL, PENDING, EXPIRED, ERROR, INCONCLUSIVE = "pass", "fail", "pending", "expired", "error", "inconclusive"
SEVERITIES = ("high", "medium", "low")
INCONCLUSIVE_ESCALATION_DAYS = 14
POPULATION_COLUMN = "population"
LEDGER_ACTIVE, LEDGER_RETIRED = "active", "retired"
RESOLVED_RECOVERED, RESOLVED_RETIRED = "check_recovered", "check_retired_unanswered"
_READ_ONLY_PREFIX = re.compile(r"^\s*(select|with)\b", re.IGNORECASE)
DEFAULT_REGISTRY = "checks/registry.yaml"
DEFAULT_LEDGER = "checks/ledger.txt"
DEFAULT_RESULTS = "checks/results.jsonl"


class RegistryError(Exception):
    pass


@dataclass(frozen=True)
class Check:
    id: str
    title: str
    statement: str
    query: str
    check_after: dt.date
    until: dt.date
    severity: str = "high"
    item: str | None = None
    pr: int | None = None
    recheck_after_hours: int = 24
    known_vacuous: bool = False
    vacuous_reason: str | None = None

    def state_on(self, today: dt.date) -> str | None:
        """None when due; otherwise why it is skipped."""
        if today < self.check_after:
            return PENDING
        if today > self.until:
            return EXPIRED
        return None


@dataclass
class Result:
    check: Check
    state: str
    detail: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    escalated: bool = False

    @property
    def is_actionable(self) -> bool:
        if self.state in (FAIL, ERROR):
            return True
        return self.state == INCONCLUSIVE and self.escalated

    def to_json(self, today: dt.date) -> dict[str, Any]:
        return {
            "check": self.check.id, "date": today.isoformat(), "state": self.state,
            "detail": self.detail, "error": self.error, "escalated": self.escalated,
            "severity": self.check.severity, "item": self.check.item, "until": self.check.until.isoformat(),
        }


def validate_query(query: str) -> None:
    stripped = query.strip().rstrip(";").strip()
    if not _READ_ONLY_PREFIX.match(stripped):
        raise ValueError("check query must start with SELECT or WITH")
    if ";" in stripped:
        raise ValueError("check query must be a single statement")


def _date(v: Any, where: str) -> dt.date:
    if isinstance(v, dt.date):
        return v
    try:
        return dt.date.fromisoformat(str(v))
    except ValueError as e:
        raise RegistryError(f"{where}: not a date: {v!r}") from e


def load_registry(path: Path) -> list[Check]:
    if not path.exists():
        raise RegistryError(f"no registry at {path}")
    data = yaml.safe_load(path.read_text()) or {}
    if data.get("schema_version") != 1:
        raise RegistryError(f"{path}: schema_version must be 1")
    checks: list[Check] = []
    seen: set[str] = set()
    for i, raw in enumerate(data.get("checks") or []):
        where = f"{path}: checks[{i}]"
        for key in ("id", "title", "statement", "query", "check_after", "until"):
            if key not in raw:
                raise RegistryError(f"{where}: missing `{key}`")
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", str(raw["id"])):
            raise RegistryError(f"{where}: id must be lower-case kebab: {raw['id']!r}")
        if raw["id"] in seen:
            raise RegistryError(f"{where}: duplicate id {raw['id']!r}")
        seen.add(raw["id"])
        try:
            validate_query(raw["query"])
        except ValueError as e:
            raise RegistryError(f"{where} ({raw['id']}): {e}") from e
        sev = raw.get("severity", "high")
        if sev not in SEVERITIES:
            raise RegistryError(f"{where}: severity must be one of {SEVERITIES}")
        c = Check(
            id=raw["id"], title=str(raw["title"]).strip(), statement=str(raw["statement"]).strip(), query=str(raw["query"]),
            check_after=_date(raw["check_after"], where), until=_date(raw["until"], where), severity=sev,
            item=raw.get("item"), pr=raw.get("pr"), recheck_after_hours=int(raw.get("recheck_after_hours", 24)),
            known_vacuous=bool(raw.get("known_vacuous", False)), vacuous_reason=raw.get("vacuous_reason"),
        )
        if c.until < c.check_after:
            raise RegistryError(f"{where} ({c.id}): until {c.until} is before check_after {c.check_after}")
        if c.known_vacuous and not c.vacuous_reason:
            raise RegistryError(f"{where} ({c.id}): known_vacuous needs a vacuous_reason — a pass that cannot fail must say why it is accepted")
        checks.append(c)
    return checks


def load_ledger(path: Path) -> dict[str, str]:
    """{check_id: active|retired}; strict — a line it cannot parse is an error, never skipped."""
    if not path.exists():
        raise RegistryError(f"no ledger at {path} — every declared check must be listed as active or retired")
    states: dict[str, str] = {}
    for lineno, raw in enumerate(path.read_text().splitlines(), start=1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) != 2 or parts[1] not in (LEDGER_ACTIVE, LEDGER_RETIRED):
            raise RegistryError(f"{path.name}:{lineno}: expected `<check-id> active|retired`, got {raw.strip()!r}")
        if parts[0] in states:
            raise RegistryError(f"{path.name}:{lineno}: duplicate id {parts[0]!r}")
        states[parts[0]] = parts[1]
    return states


def ledger_problems(checks: list[Check], ledger: dict[str, str]) -> list[str]:
    """A check missing from the ledger, or a ledger-active check missing from the registry (LOST), is a finding."""
    problems = []
    ids = {c.id for c in checks}
    for c in checks:
        if c.id not in ledger:
            problems.append(f"{c.id}: declared in the registry but not in the ledger — add `{c.id} active`")
        elif ledger[c.id] == LEDGER_RETIRED:
            problems.append(f"{c.id}: retired in the ledger but still declared — remove it from the registry or mark it active")
    for cid, state in ledger.items():
        if state == LEDGER_ACTIVE and cid not in ids:
            problems.append(f"{cid}: LOST — active in the ledger and absent from the registry; retire it explicitly (`{cid} retired`) or restore it")
    return problems


def _population_present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float, Decimal)):
        return value != 0
    raise TypeError(type(value).__name__)


def _plain(v: Any) -> Any:
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, (dt.date, dt.datetime)):
        return v.isoformat()
    return v


def evaluate(check: Check, row: dict[str, Any] | None, *, today: dt.date, error: str | None = None) -> Result:
    """Turn one query's row into a verdict. Never raises: a broken check is an ERROR result."""
    skipped = check.state_on(today)
    if skipped is not None:
        return Result(check, skipped)
    if error:
        return Result(check, ERROR, error=error)
    if row is None:
        return Result(check, ERROR, error="query returned no rows")
    raw = dict(row)
    detail = {k: _plain(v) for k, v in raw.items()}
    if "ok" not in detail:
        return Result(check, ERROR, error="query must return a boolean column named 'ok'", detail=detail)
    if POPULATION_COLUMN in raw:
        try:
            has_population = _population_present(raw[POPULATION_COLUMN])
        except TypeError:
            return Result(check, ERROR, error=f"'{POPULATION_COLUMN}' must be a number or a boolean, got {type(raw[POPULATION_COLUMN]).__name__}", detail=detail)
        if not has_population:
            return Result(check, INCONCLUSIVE, detail=detail, escalated=(check.until - today).days <= INCONCLUSIVE_ESCALATION_DAYS)
    ok = detail.get("ok")
    if ok is None:
        return Result(check, FAIL, detail=detail)
    if isinstance(ok, str):
        ok = ok.strip().lower() in ("t", "true", "1", "yes")
    return Result(check, PASS if bool(ok) else FAIL, detail=detail)


def plan(checks: list[Check], today: dt.date) -> list[dict[str, Any]]:
    out = []
    for c in checks:
        out.append({"id": c.id, "state": c.state_on(today) or "due", "query": c.query.strip().rstrip(";") if c.state_on(today) is None else None,
                    "check_after": c.check_after.isoformat(), "until": c.until.isoformat(), "severity": c.severity})
    return out


def evaluate_all(checks: list[Check], rows: dict[str, Any], today: dt.date) -> list[Result]:
    """rows: {check_id: <row dict> | {"error": "..."} | null}. A due check with no entry in rows is an ERROR ("not executed")."""
    results = []
    for c in checks:
        if c.state_on(today) is not None:
            results.append(Result(c, c.state_on(today)))
            continue
        if c.id not in rows:
            results.append(Result(c, ERROR, error="not executed — no row supplied for a due check"))
            continue
        entry = rows[c.id]
        if isinstance(entry, dict) and "error" in entry and "ok" not in entry:
            results.append(evaluate(c, None, today=today, error=str(entry["error"])))
        elif isinstance(entry, list):
            results.append(evaluate(c, entry[0] if entry else None, today=today))
        else:
            results.append(evaluate(c, entry, today=today))
    return results


def run_psql(checks: list[Check], today: dt.date, dsn: str, timeout_ms: int = 15_000) -> dict[str, Any]:
    """Execute every due check through psql, read-only and time-bounded; returns the rows map `evaluate_all` takes."""
    if shutil.which("psql") is None:
        raise RuntimeError("psql not on PATH")
    rows: dict[str, Any] = {}
    for c in checks:
        if c.state_on(today) is not None:
            continue
        sql = f"SET statement_timeout = {int(timeout_ms)}; SET default_transaction_read_only = on; SET transaction_read_only = on;\n" \
              f"SELECT row_to_json(r) FROM ({c.query.strip().rstrip(';')}) r LIMIT 1;"
        p = subprocess.run(["psql", dsn, "-v", "ON_ERROR_STOP=1", "-At", "-c", sql], capture_output=True, text=True, timeout=timeout_ms / 1000 + 10)
        if p.returncode != 0:
            rows[c.id] = {"error": (p.stderr or p.stdout).strip()[-300:]}
            continue
        line = (p.stdout or "").strip().splitlines()
        line = [x for x in line if x.startswith("{")]
        rows[c.id] = json.loads(line[-1]) if line else None
    return rows


def append_results(results_path: Path, results: list[Result], today: dt.date) -> int:
    results_path.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with results_path.open("a") as fh:
        for r in results:
            fh.write(json.dumps(r.to_json(today)) + "\n")
            n += 1
    return n


def read_results(results_path: Path) -> list[dict[str, Any]]:
    if not results_path.exists():
        return []
    out = []
    for line in results_path.read_text().splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out


def latest_by_check(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    latest: dict[str, dict[str, Any]] = {}
    for r in rows:
        prev = latest.get(r["check"])
        if prev is None or r["date"] >= prev["date"]:
            latest[r["check"]] = r
    return latest


def _numeric_diagnostics(detail: dict[str, Any]) -> dict[str, float]:
    return {k: float(v) for k, v in detail.items() if k != "ok" and isinstance(v, (int, float)) and not isinstance(v, bool)}


def report(checks: list[Check], history: list[dict[str, Any]], today: dt.date, roadmap_items: Path | None = None) -> dict[str, Any]:
    """What Gus reads: counts by state, the oldest failure, unowned failures, vacuous passes, expiries, worsening."""
    latest = latest_by_check(history)
    by_id = {c.id: c for c in checks}
    counts = {s: 0 for s in (PASS, FAIL, PENDING, EXPIRED, ERROR, INCONCLUSIVE)}
    high_fail = 0
    failures: list[dict[str, Any]] = []
    vacuous: list[str] = []
    unowned: list[str] = []
    expiring: list[str] = []
    expired_while_red: list[str] = []
    worsening: list[str] = []
    never_run: list[str] = []
    for c in checks:
        cur = latest.get(c.id)
        state = c.state_on(today) or (cur["state"] if cur else None)
        if state is None:
            never_run.append(c.id)
            continue
        counts[state] = counts.get(state, 0) + 1
        if state == FAIL:
            if c.severity == "high":
                high_fail += 1
            first_red = None
            for r in sorted((r for r in history if r["check"] == c.id), key=lambda r: r["date"]):
                if r["state"] == FAIL and first_red is None:
                    first_red = r["date"]
                elif r["state"] == PASS:
                    first_red = None
            failures.append({"id": c.id, "red_since": first_red, "days": (today - dt.date.fromisoformat(first_red)).days if first_red else None})
            owned = bool(c.item) and (roadmap_items is None or (roadmap_items / f"{c.item}.yaml").exists())
            if not owned:
                unowned.append(c.id)
            runs = sorted((r for r in history if r["check"] == c.id and r["state"] == FAIL), key=lambda r: r["date"])
            if len(runs) >= 2:
                a, b = _numeric_diagnostics(runs[-2].get("detail", {})), _numeric_diagnostics(runs[-1].get("detail", {}))
                worse = [k for k in b if k in a and b[k] > a[k]]
                if worse:
                    worsening.append(f"{c.id}: {', '.join(f'{k} {a[k]:g}→{b[k]:g}' for k in worse)}")
        if state == PASS and cur and not c.known_vacuous:
            nums = _numeric_diagnostics(cur.get("detail", {}))
            if nums and all(v == 0 for v in nums.values()):
                vacuous.append(f"{c.id}: every numeric diagnostic is 0 ({', '.join(nums)}) — what would this show if the feature were broken?")
        if state not in (EXPIRED,) and 0 <= (c.until - today).days <= 7:
            expiring.append(f"{c.id}: until {c.until.isoformat()}")
        if state == EXPIRED and cur and cur["state"] == FAIL:
            expired_while_red.append(c.id)
    failures.sort(key=lambda f: (f["days"] is None, -(f["days"] or 0)))
    return {
        "date": today.isoformat(), "checked": len(checks), "counts": counts, "high": high_fail,
        "oldest_failure": failures[0] if failures else None, "failures": failures, "failures_without_item": unowned,
        "vacuous_unflagged": vacuous, "expiring_within_7d": expiring, "expired_while_red": expired_while_red,
        "worsening": worsening, "never_run": never_run,
    }


# --- the GitHub-issues adapter (SPEC §16 decision 4) --------------------------------------------------------------

def issue_body(r: Result, repo: str) -> str:
    c = r.check
    lines = [f"Post-merge check FAILED: {c.title}", "", c.statement, ""]
    if r.state == ERROR:
        lines.insert(0, "(the check itself could not run — see error below)")
        lines += [f"error: {r.error}", ""]
    elif r.state == INCONCLUSIVE:
        lines[0] = f"Post-merge check NEVER BECAME ANSWERABLE: {c.title}"
        lines.insert(1, f"\nIts population has been empty every time it ran, and it expires on {c.until.isoformat()}. Nothing below was ever tested against production. Three honest answers: the feature never shipped (fix it or drop it), the check asks about the wrong population (rewrite the query), or it was always a question CI could have answered (delete it). Extending `until` is not one of them.\n")
    observed = ", ".join(f"{k}={v}" for k, v in r.detail.items() if k != "ok")
    if observed:
        lines += [f"observed: {observed}", ""]
    if c.pr:
        lines.append(f"PR: https://github.com/{repo}/pull/{c.pr}")
    if c.item:
        lines.append(f"owning roadmap item: {c.item}")
    lines.append(f"check id: {c.id} (checks/registry.yaml)")
    return "\n".join(lines)


LABEL_MAX = 50   # GitHub refuses a longer label name with 422 (measured 2026-09-18: `check:the-published-questionnaire-collects-documents`, 52 chars)


def check_label(check_id: str) -> str:
    """`check:<id>`, shortened deterministically when GitHub would refuse it: the first 35 characters of the id, a dash, and 8 hex of its sha1 —
    so the label filed today is the label matched tomorrow, and two long ids never share one."""
    full = f"check:{check_id}"
    if len(full) <= LABEL_MAX:
        return full
    import hashlib
    return f"check:{check_id[:LABEL_MAX - 6 - 9]}-{hashlib.sha1(check_id.encode()).hexdigest()[:8]}"


def issue_actions(results: list[Result], open_issues: list[dict[str, Any]], now: dt.datetime, repo: str, label: str = "ticket") -> list[dict[str, Any]]:
    """What to file and what to close, as data — so a dry run is the same code path as the real one.

    open_issues: [{number, title, labels: [names], created_at}] for issues carrying `label`.
    """
    by_label: dict[str, list[dict[str, Any]]] = {}
    for iss in open_issues:
        for lab in iss.get("labels", []):
            if str(lab).startswith("check:"):
                by_label.setdefault(str(lab), []).append(iss)
    actions: list[dict[str, Any]] = []
    for r in results:
        existing = by_label.get(check_label(r.check.id), [])
        if r.is_actionable:
            young = [i for i in existing if (now - dt.datetime.fromisoformat(str(i["created_at"]).replace("Z", "+00:00"))).total_seconds() < r.check.recheck_after_hours * 3600]
            if existing and young:
                actions.append({"op": "skip", "check": r.check.id, "why": f"open issue #{young[0]['number']} younger than {r.check.recheck_after_hours}h"})
            elif existing:
                actions.append({"op": "comment", "check": r.check.id, "number": existing[0]["number"], "body": f"Still {r.state} on {now.date().isoformat()}: " + (", ".join(f"{k}={v}" for k, v in r.detail.items()) or r.error or "")})
            else:
                actions.append({"op": "create", "check": r.check.id, "title": f"[check] {r.check.title}", "labels": [label, check_label(r.check.id), f"severity:{r.check.severity}"], "body": issue_body(r, repo)})
        elif r.state in (PASS, EXPIRED) and existing:
            reason = RESOLVED_RECOVERED if r.state == PASS else RESOLVED_RETIRED
            for i in existing:
                actions.append({"op": "close", "check": r.check.id, "number": i["number"], "reason": reason, "body": f"Closing: {reason} on {now.date().isoformat()} (" + ("the check passes" if r.state == PASS else "the check expired unanswered") + ")."})
    return actions


def gh_open_issues(repo: str, label: str) -> list[dict[str, Any]]:
    if shutil.which("gh") is None:
        raise RuntimeError("gh not on PATH")
    p = subprocess.run(["gh", "api", f"repos/{repo}/issues?state=open&labels={label}&per_page=100"], capture_output=True, text=True, timeout=60)
    if p.returncode != 0:
        raise RuntimeError(f"gh api failed: {(p.stderr or p.stdout).strip()[:200]}")
    out = []
    for i in json.loads(p.stdout or "[]"):
        if "pull_request" in i:
            continue
        out.append({"number": i["number"], "title": i["title"], "labels": [lab["name"] for lab in i.get("labels", [])], "created_at": i["created_at"]})
    return out


def gh_apply(repo: str, actions: list[dict[str, Any]]) -> list[str]:
    done = []
    for a in actions:
        if a["op"] == "create":
            try:  # a label that does not exist is silently dropped by the issues API; make them first
                from .tickets import ensure_labels
                done.extend(ensure_labels(repo, a["labels"]))
            except Exception as e:  # noqa: BLE001 — filing still proceeds; the missing label is then visible in the result
                done.append(f"ensure labels for {a['check']}: FAILED {str(e)[:160]}")
            p = subprocess.run(["gh", "api", f"repos/{repo}/issues", "-f", f"title={a['title']}", "-f", f"body={a['body']}", *sum((["-f", f"labels[]={lab}"] for lab in a["labels"]), [])], capture_output=True, text=True, timeout=60)
        elif a["op"] == "comment":
            p = subprocess.run(["gh", "api", f"repos/{repo}/issues/{a['number']}/comments", "-f", f"body={a['body']}"], capture_output=True, text=True, timeout=60)
        elif a["op"] == "close":
            subprocess.run(["gh", "api", f"repos/{repo}/issues/{a['number']}/comments", "-f", f"body={a['body']}"], capture_output=True, text=True, timeout=60)
            p = subprocess.run(["gh", "api", "-X", "PATCH", f"repos/{repo}/issues/{a['number']}", "-f", "state=closed", "-f", "state_reason=completed"], capture_output=True, text=True, timeout=60)
        else:
            done.append(f"skip {a['check']}: {a['why']}")
            continue
        done.append(f"{a['op']} {a['check']}: " + ("ok" if p.returncode == 0 else "FAILED " + (p.stderr or p.stdout).strip()[:160]))
    return done
