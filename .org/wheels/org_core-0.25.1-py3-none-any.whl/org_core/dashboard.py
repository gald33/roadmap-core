"""`org status --html` — the same reading, as a page (SPEC §9).

A pure function: `render_html(status_dict)` returns one self-contained document and reaches nothing. The
page is scanned, not read, so state is encoded in form as well as colour — every tile carries the word
`RED` / `CLEAR` / `DARK` beside its mark, because a status colour must never carry meaning alone.

`DARK` is deliberately **not** a third severity. A tile nobody could measure is absent, not bad, so it
takes a muted neutral and a dashed edge rather than a warning hue — the whole point of rows 62 and 65 is
that "not measured" must never read as either "fine" or "failing".
"""

from __future__ import annotations

import html
import json
from typing import Any

from .status import FINDING

#: status steps, fixed — never reused for anything but state (dataviz: the status palette is reserved)
CRITICAL, GOOD = "#d03b3b", "#0ca30c"

STATE_MARK = {"RED": "●", "CLEAR": "○", "DARK": "—"}

CSS = """
:root{
  --bg:#fbfbfc; --surface:#fff; --surface-2:#f6f7f9; --ink:#12141a; --ink-2:#565c6b; --muted:#8b91a1;
  --border:#e3e5ea; --accent:#3d6ea8;
  --red:#d03b3b; --green:#0ca30c; --dark-mark:#9aa0ae;
  --red-wash:#fdf2f2; --green-wash:#f1faf1; --dark-wash:#f6f7f9;
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --bg:#131417; --surface:#1a1c21; --surface-2:#212429; --ink:#f2f3f5; --ink-2:#a8aebd; --muted:#767c8b;
  --border:#2a2d35; --accent:#7aa8dc;
  --red:#e2584f; --green:#3fbb3f; --dark-mark:#767c8b;
  --red-wash:#241a1b; --green-wash:#16231a; --dark-wash:#1f2228;
}}
:root[data-theme="dark"]{
  --bg:#131417; --surface:#1a1c21; --surface-2:#212429; --ink:#f2f3f5; --ink-2:#a8aebd; --muted:#767c8b;
  --border:#2a2d35; --accent:#7aa8dc;
  --red:#e2584f; --green:#3fbb3f; --dark-mark:#767c8b;
  --red-wash:#241a1b; --green-wash:#16231a; --dark-wash:#1f2228;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
  font-family:"IBM Plex Sans",ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;
  font-size:14px;line-height:1.5;-webkit-font-smoothing:antialiased}
.wrap{max-width:1180px;margin:0 auto;padding-inline:16px;padding-block:28px 56px}
h1{font-size:19px;font-weight:600;margin:0;letter-spacing:-.01em}
.sub{color:var(--ink-2);font-size:12.5px;margin-top:3px;
  font-family:"IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,monospace;font-variant-numeric:tabular-nums}
.eyebrow{font-size:10.5px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}
.banner{display:flex;gap:12px;margin-top:20px;padding:14px 16px;border:1px solid var(--border);
  border-left-width:4px;border-radius:7px;background:var(--surface)}
.banner.RED{border-left-color:var(--red);background:var(--red-wash)}
.banner.CLEAR{border-left-color:var(--green);background:var(--green-wash)}
.banner.DARK{border-left-color:var(--dark-mark);border-left-style:dashed;background:var(--dark-wash)}
.banner p{margin:4px 0 0;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px;
  word-break:break-word;line-height:1.55}
.note{margin-top:14px;padding:10px 13px;border:1px dashed var(--border);border-radius:7px;
  background:var(--surface-2);color:var(--ink-2);font-size:12.5px}
.grid{display:grid;gap:14px;margin-top:18px;grid-template-columns:repeat(auto-fit,minmax(330px,1fr))}
.tile{border:1px solid var(--border);border-radius:9px;background:var(--surface);padding:14px 16px;
  display:flex;flex-direction:column;gap:9px;min-width:0}
.tile.span{grid-column:1/-1}
.tile.DARK{border-style:dashed}
.thead{display:flex;align-items:baseline;gap:9px;flex-wrap:wrap}
.chip{display:inline-flex;align-items:center;gap:5px;font-size:10.5px;font-weight:600;letter-spacing:.07em;
  padding:2px 8px;border-radius:99px;border:1px solid var(--border);white-space:nowrap}
.chip.RED{color:var(--red);border-color:var(--red)}
.chip.CLEAR{color:var(--green);border-color:var(--green)}
.chip.DARK{color:var(--dark-mark);border-style:dashed}
.tname{font-weight:600;font-size:14px}
.tier{font-size:11.5px;color:var(--muted)}
.lines{margin:0;font-family:"IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12.5px;
  line-height:1.65;overflow-x:auto;font-variant-numeric:tabular-nums}
.lines div{padding:1px 0;word-break:break-word}
.lines div.hot{color:var(--red)}
.broken{font-size:11.5px;color:var(--muted);border-top:1px dotted var(--border);padding-top:8px;margin-top:auto}
.broken b{font-weight:600;color:var(--ink-2)}
table{border-collapse:collapse;width:100%;font-size:12.5px;
  font-family:"IBM Plex Mono",ui-monospace,monospace;font-variant-numeric:tabular-nums}
th{text-align:left;font-weight:600;color:var(--muted);font-size:10.5px;letter-spacing:.07em;
  text-transform:uppercase;padding:0 10px 6px 0;white-space:nowrap}
td{padding:5px 10px 5px 0;border-top:1px solid var(--border);vertical-align:middle;white-space:nowrap}
td.wide{white-space:normal;min-width:150px}
.scroll{overflow-x:auto}
.bar{position:relative;display:inline-block;height:8px;min-width:90px;width:120px;vertical-align:middle;background:var(--surface-2);border-radius:4px}
.bar i{position:absolute;inset:0 auto 0 0;border-radius:4px;background:var(--green)}
.bar i.over{background:var(--red)}
.bar u{position:absolute;top:-3px;bottom:-3px;width:2px;background:var(--ink-2);opacity:.6}
.foot{margin-top:26px;padding-top:14px;border-top:1px solid var(--border);color:var(--muted);font-size:12px}
.foot code{font-family:"IBM Plex Mono",ui-monospace,monospace;color:var(--ink-2);word-break:break-all}
.foot p{margin:5px 0}
@media (max-width:460px){.wrap{padding-block:20px 40px}.grid{grid-template-columns:1fr}}
"""


def reading_doc(st: dict[str, Any], *, source: str = "org status") -> dict[str, Any]:
    """One reading, flattened to what the page draws — defined once, so the copy embedded in the page and
    the copy a live store holds are the same shape and can never disagree.

    `report` is dropped: it is the whole measurement and a store document is capped, and the page renders
    none of it directly. Everything the page shows is here.
    """
    from .status import EDGE_OWNER, EDGE_TIER, NO_MEDIAN

    rep = st.get("report") or {}
    edges = []
    for name, e in (rep.get("edges") or {}).items():
        edges.append({"name": name, "tier": EDGE_TIER.get(name, "board"), "owner": EDGE_OWNER.get(name, "?"),
                      "median_hours": e.get("median_hours"), "n": e.get("n"), "waiting": e.get("waiting"),
                      "worst_item": e.get("worst_waiting_item"), "worst_hours": e.get("worst_waiting_hours"),
                      "target": (rep.get("targets") or {}).get(name),
                      "note": NO_MEDIAN.get(name, "") or ("the board kept no earlier record (row 62)"
                                                          if EDGE_TIER.get(name) == "board" and not e.get("n") else "")})
    return {"at": st.get("at"), "org": st.get("org"), "headline": st.get("headline"),
            "tiles": [{k: t[k] for k in ("id", "title", "tier", "state", "lines", "broken_looks_like")} for t in st["tiles"]],
            "edges": edges, "coverage": st.get("coverage") or {}, "tiers": st.get("tiers") or {},
            "could_not_read": st.get("could_not_read") or [], "source": source}

#: the page is live by subscription, not by polling: it draws the reading it shipped with, then redraws
#: whenever a newer one lands in the artifact's store. org-core writes no store — rule 6 — so the writer is
#: whatever session can reach the org. With no store granted the page still shows its embedded reading and
#: says so, because a dashboard that silently shows stale numbers is the failure this whole file is about.
LIVE_JS = r"""
<script>
(function () {
  var EL = function (t, c, x) { var e = document.createElement(t); if (c) e.className = c;
    if (x !== undefined && x !== null) e.textContent = String(x); return e; };
  var MARK = { RED: "\u25cf", CLEAR: "\u25cb", DARK: "\u2014" };
  var FINDING = ["DEAD","WAITING","NOT RECEIVED","BLOCKED","QUEUE","CEO record ABSENT","SKEWED","UNFORWARDED",
                 "FIRED-NO-RECEIVER","SUPPRESSED","NOT LISTENING","NEVER REGISTERED","ABSENT","SLOW"];
  var isFinding = function (l) { for (var i = 0; i < FINDING.length; i++) if (l.indexOf(FINDING[i]) === 0) return true; return false; };
  var seen = null;

  function ago(iso) {
    var t = Date.parse(iso); if (isNaN(t)) return "";
    var m = Math.round((Date.now() - t) / 60000);
    if (m < 1) return "just now"; if (m < 60) return m + " min ago";
    var h = m / 60; return (h < 48 ? h.toFixed(1) + "h ago" : Math.round(h / 24) + "d ago");
  }
  function tickAges() {
    var n = document.getElementById("age"); if (n && seen) n.textContent = " \u00b7 read " + ago(seen.at);
  }
  function banner(tiles) {
    for (var i = 0; i < tiles.length; i++) if (tiles[i].state === "RED") return "RED";
    for (var j = 0; j < tiles.length; j++) if (tiles[j].state === "DARK") return "DARK";
    return "CLEAR";
  }
  function edgeTable(d) {
    var wrap = EL("div", "scroll"), t = EL("table"), h = EL("thead"), hr = EL("tr");
    ["edge","tier","owner","median","n","waiting","worst now","vs target"].forEach(function (c) { hr.appendChild(EL("th", null, c)); });
    h.appendChild(hr); t.appendChild(h);
    var b = EL("tbody");
    (d.edges || []).forEach(function (e) {
      var r = EL("tr");
      [e.name, e.tier, e.owner,
       (e.median_hours === null || e.median_hours === undefined) ? "\u2014" : e.median_hours + "h",
       e.n, e.waiting,
       e.worst_item ? e.worst_item + " " + e.worst_hours + "h" : "\u2014"].forEach(function (v, i) {
        var td = EL("td", i === 6 ? "wide" : null, v); r.appendChild(td);
      });
      var td = EL("td");
      if (e.worst_hours !== null && e.worst_hours !== undefined && e.target) {
        var bar = EL("span", "bar"), fill = EL("i"), tick = EL("u");
        var ratio = e.worst_hours / e.target;
        fill.style.width = Math.min(ratio, 1) * 100 + "%"; if (ratio > 1) fill.className = "over";
        tick.style.left = "100%"; bar.appendChild(fill); bar.appendChild(tick);
        bar.title = "worst " + e.worst_hours + "h against a " + e.target + "h target";
        td.appendChild(bar);
      } else { td.appendChild(document.createTextNode("\u2014")); }
      if (e.target) td.appendChild(document.createTextNode("  (target " + e.target + "h)"));
      r.appendChild(td); b.appendChild(r);
      if (e.note) { var nr = EL("tr"), nd = EL("td", "wide", e.note);
        nd.colSpan = 8; nd.style.color = "var(--muted)"; nd.style.borderTop = "none"; nd.style.paddingTop = "0";
        nr.appendChild(nd); b.appendChild(nr); }
    });
    t.appendChild(b); wrap.appendChild(t); return wrap;
  }
  function paint(d) {
    seen = d;
    document.getElementById("org").textContent = d.org || "";
    document.getElementById("readat").textContent = "read at " + (d.at || "");
    var hl = document.getElementById("headline"); hl.textContent = d.headline || "";
    var bn = document.getElementById("banner"); bn.className = "banner " + banner(d.tiles || []);
    var grid = document.getElementById("tiles"); grid.textContent = "";
    (d.tiles || []).forEach(function (t) {
      var sec = EL("section", "tile " + t.state + (t.id === "chain" ? " span" : ""));
      var head = EL("div", "thead");
      head.appendChild(EL("span", "chip " + t.state, MARK[t.state] + " " + t.state));
      head.appendChild(EL("span", "tname", t.title));
      head.appendChild(EL("span", "tier", t.tier + " \u2014 " + ((d.tiers || {})[t.tier] || "several sources")));
      sec.appendChild(head);
      var hasTable = t.id === "chain" && (d.edges || []).length;
      if (hasTable) sec.appendChild(edgeTable(d));
      var lines = EL("div", "lines");
      (t.lines || []).forEach(function (l) {
        if (hasTable && !isFinding(l)) return;
        lines.appendChild(EL("div", isFinding(l) ? "hot" : null, l));
      });
      sec.appendChild(lines);
      if (t.state !== "RED") {
        var br = EL("div", "broken"); br.appendChild(EL("b", null, "broken looks like: "));
        br.appendChild(document.createTextNode(t.broken_looks_like || "")); sec.appendChild(br);
      }
      grid.appendChild(sec);
    });
    var c = d.coverage || {}, foot = document.getElementById("cover"); foot.textContent = "";
    foot.appendChild(EL("b", null, "read " + c.measured + " of " + c.tiles + " tiles"));
    if (c.dark && c.dark.length) foot.appendChild(document.createTextNode(" \u00b7 dark: " + c.dark.join(", ")));
    if (d.source) foot.appendChild(document.createTextNode(" \u00b7 " + d.source));
    var un = document.getElementById("unread"); un.textContent = "";
    (d.could_not_read || []).forEach(function (x) {
      var pEl = document.createElement("p"); pEl.appendChild(EL("code", null, "could not read: " + x)); un.appendChild(pEl);
    });
    tickAges();
  }
  function history(docs) {
    var h = document.getElementById("history"); h.textContent = "";
    if (docs.length < 2) return;
    h.appendChild(EL("span", "eyebrow", "readings"));
    docs.forEach(function (d, i) {
      var b = EL("button", "hbtn" + (i === 0 ? " now" : ""), ago(d.at));
      b.title = d.at + " \u2014 " + (d.headline || "");
      b.onclick = function () {
        paint(d);
        Array.prototype.forEach.call(h.querySelectorAll(".hbtn"), function (x) { x.classList.remove("now"); });
        b.classList.add("now");
      };
      h.appendChild(b);
    });
  }
  function live(txt, on) {
    var n = document.getElementById("live");
    n.textContent = txt; n.className = "live " + (on ? "on" : "off");
  }

  var initial = null;
  try { initial = JSON.parse(document.getElementById("reading").textContent); } catch (e) {}
  if (initial) paint(initial);
  setInterval(tickAges, 30000);

  __SOURCE__
})();
</script>
"""

#: the artifact source: a store subscription. org-core pushes nothing (rule 6) — the page only reads.
SOURCE_STORE = r"""

  (async function () {
    var db = null;
    try { db = window.claude && window.claude.use ? await window.claude.use("db") : null; } catch (e) { db = null; }
    if (!db) { live("not live \u2014 showing the reading this page shipped with", false); return; }
    live("live \u2014 watching for new readings", true);
    try {
      db.collection("readings").orderBy("at", "desc").limit(20).onSnapshot(
        function (snap) {
          var docs = snap.docs.map(function (x) { return x.data(); }).filter(Boolean);
          if (!docs.length) { live("live \u2014 no reading written yet; showing the embedded one", true); return; }
          paint(docs[0]); history(docs);
          live("live \u2014 " + docs.length + " reading(s), newest " + ago(docs[0].at), true);
        },
        function (err) { live("live updates stopped (" + (err && err.code) + ") \u2014 showing the last reading received", false); }
      );
    } catch (e) { live("not live \u2014 " + e, false); }
  })();
"""

#: the served source: poll the process that took the reading. That process re-reads on its own interval, so
#: polling faster than it costs nothing — and the age on screen stays the truth about how old the data is.
SOURCE_POLL = r"""
  var POLL_URL = "__POLL__", POLL_MS = __POLL_MS__;
  async function pollOnce() {
    try {
      var r = await fetch(POLL_URL, { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      var d = await r.json();
      if (!seen || d.at !== seen.at) paint(d); else tickAges();
      live("live \u2014 re-read " + ago(d.at), true);
    } catch (e) {
      live("the reader stopped answering \u2014 showing the last reading received", false);
    }
  }
  pollOnce();
  setInterval(pollOnce, POLL_MS);
"""

LIVE_CSS = """
.live{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:600;letter-spacing:.06em;
  text-transform:uppercase;padding:2px 9px;border-radius:99px;border:1px solid var(--border);color:var(--muted)}
.live.on{color:var(--green);border-color:var(--green)}
.live.on::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--green)}
.live.off::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--dark-mark)}
#history{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-top:14px}
.hbtn{font:inherit;font-size:11.5px;font-family:"IBM Plex Mono",ui-monospace,monospace;color:var(--ink-2);
  background:var(--surface);border:1px solid var(--border);border-radius:99px;padding:3px 10px;cursor:pointer}
.hbtn:hover{border-color:var(--accent);color:var(--accent)}
.hbtn.now{border-color:var(--accent);color:var(--accent);font-weight:600}
.hbtn:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
"""


def _e(x: Any) -> str:
    return html.escape(str(x if x is not None else ""))


def _edge_rows(rep: dict[str, Any], tiers: dict[str, str]) -> str:
    """The chain as a table: every median beside its n, every worst-waiting beside its target.

    A board-tier edge shows what it is: a worst-waiting-now and no median, because the board keeps one
    record per key (row 62). The bar compares the worst wait to that edge's target and to nothing else.
    """
    from .status import EDGE_OWNER, EDGE_TIER, NO_MEDIAN

    out = ["<div class='scroll'><table><thead><tr><th>edge</th><th>tier</th><th>owner</th>"
           "<th>median</th><th>n</th><th>waiting</th><th>worst now</th><th>vs target</th></tr></thead><tbody>"]
    for name, e in (rep.get("edges") or {}).items():
        tier = EDGE_TIER.get(name, "board")
        t = (rep.get("targets") or {}).get(name)
        med = f"{e['median_hours']}h" if e.get("median_hours") is not None else "—"
        worst = f"{e['worst_waiting_item']} {e['worst_waiting_hours']}h" if e.get("worst_waiting_item") else "—"
        bar = "—"
        if e.get("worst_waiting_hours") is not None and t:
            ratio = e["worst_waiting_hours"] / t
            pct = min(ratio, 1.0) * 100
            over = " over" if ratio > 1 else ""
            bar = (f"<span class='bar' title='worst {e['worst_waiting_hours']}h against a {t}h target'>"
                   f"<i class='{over.strip()}' style='width:{pct:.0f}%'></i><u style='left:100%'></u></span>")
        why = NO_MEDIAN.get(name, "") or ("the board kept no earlier record (row 62)" if tier == "board" and not e.get("n") else "")
        out.append(
            f"<tr><td>{_e(name)}</td><td>{_e(tier)}</td><td>{_e(EDGE_OWNER.get(name, '?'))}</td>"
            f"<td>{_e(med)}</td><td>{_e(e.get('n'))}</td><td>{_e(e.get('waiting'))}</td>"
            f"<td class='wide'>{_e(worst)}</td><td>{bar}{('  (target ' + str(t) + 'h)') if t else ''}</td></tr>")
        if why:
            out.append(f"<tr><td colspan='8' class='wide' style='color:var(--muted);border-top:none;padding-top:0'>{_e(why)}</td></tr>")
    out.append("</tbody></table></div>")
    return "".join(out)


def render_html(st: dict[str, Any], *, sample_note: str | None = None, live: bool = False,
                source: str = "org status", poll: str | None = None, poll_ms: int = 5000) -> str:
    """One self-contained page from one status dict. No network, no clock: everything is `st`.

    `live=True` adds the subscription layer: the page still renders this reading at rest, and redraws
    when a newer one lands in the artifact's store. The page never writes — org-core sends nothing
    (rule 6), so whoever can reach the org writes the readings.
    """
    c = st.get("coverage") or {}
    tiers = st.get("tiers") or {}
    states = [t["state"] for t in st["tiles"]]
    banner = "RED" if "RED" in states else ("DARK" if "DARK" in states else "CLEAR")

    tiles = []
    for t in st["tiles"]:
        body = _edge_rows(st.get("report") or {}, tiers) if t["id"] == "chain" and (st.get("report") or {}).get("edges") else ""
        lines = "".join(
            f"<div class='{'hot' if l.startswith(FINDING) else ''}'>{_e(l)}</div>"
            for l in t["lines"]) if (t["id"] != "chain" or not body) else "".join(
            f"<div class='hot'>{_e(l)}</div>" for l in t["lines"] if l.startswith(FINDING))
        tiles.append(
            f"<section class='tile {t['state']}{' span' if t['id'] == 'chain' else ''}'>"
            f"<div class='thead'><span class='chip {t['state']}'>{STATE_MARK[t['state']]} {t['state']}</span>"
            f"<span class='tname'>{_e(t['title'])}</span>"
            f"<span class='tier'>{_e(t['tier'])} — {_e(tiers.get(t['tier'], 'several sources'))}</span></div>"
            f"{body}<div class='lines'>{lines}</div>"
            + (f"<div class='broken'><b>broken looks like:</b> {_e(t['broken_looks_like'])}</div>" if t["state"] != "RED" else "")
            + "</section>")

    note = f"<div class='note'>{_e(sample_note)}</div>" if sample_note else ""
    dark = f" · dark: {', '.join(c.get('dark') or [])}" if c.get("dark") else ""
    age = f" · facts {_e(c.get('facts_gathered_at'))} ({_e(c.get('facts_age_hours'))}h old)" if c.get("facts_gathered_at") else ""
    unread = "".join(f"<p><code>could not read: {_e(x)}</code></p>" for x in (st.get("could_not_read") or []))
    seed = json.dumps(reading_doc(st, source=source), ensure_ascii=False).replace("<", "\\u003c")
    live_head = (f"<span class='live off' id='live'>not live</span>" if live else "")
    if poll:                                  # served: the page asks the reader that took this reading
        js = LIVE_JS.replace("__SOURCE__", SOURCE_POLL.replace("__POLL__", poll).replace("__POLL_MS__", str(int(poll_ms))))
        live = True
    else:                                     # published: the page watches the artifact's own store
        js = LIVE_JS.replace("__SOURCE__", SOURCE_STORE)
    live_history = "<div id='history'></div>" if (live and not poll) else ""
    # the script goes LAST: it paints #tiles, #cover and #unread, which are further down the document
    live_script = (f"<script type='application/json' id='reading'>{seed}</script>{js}" if live else "")
    return f"""<title>Org Status</title>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap">
<style>{CSS}{LIVE_CSS if live else ""}</style>
<div class="wrap">
  <div class="eyebrow">org status {live_head}</div>
  <h1 id="org">{_e(st.get('org'))}</h1>
  <div class="sub"><span id="readat">read at {_e(st.get('at'))}</span><span id="age"></span>{age}</div>
  {note}
  <div class="banner {banner}" id="banner">
    <div><div class="eyebrow">headline</div><p id="headline">{_e(st.get('headline'))}</p></div>
  </div>
  {live_history}
  <div class="grid" id="tiles">{''.join(tiles)}</div>
  <div class="foot">
    <p id="cover"><b>read {_e(c.get('measured'))} of {_e(c.get('tiles'))} tiles</b>{_e(dark)}</p>
    <p>sessions tier: {_e(c.get('sessions_tier'))}</p>
    <span id="unread">{unread}</span>
    <p>A tile nobody could measure is <b>DARK</b> — absent, not failing. It shows a dashed edge and a
       muted mark, never a warning colour, so "not measured" reads as neither "fine" nor "broken".</p>
  </div>
  {live_script}
</div>
"""
