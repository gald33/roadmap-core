"""`org fleet` — every installed org's default branch read against the package (SPEC §11; row 108).

NumeroTech sat at 0.15.1 with the suite never applied while the package was at 0.16.0, and only a direct
question found it (roadmap item guard-installs-drifting-behind-the-package); on 2026-09-20 both orgs sat
behind again — 0.17.4 and 0.19.0 against 0.21.3 — until the installer happened to look. An installed org
cannot see org-core's releases from inside itself (`gh api repos/gald33/org-core` is 403 from its
sessions), so the reading is the fleet's: it runs where the package is, reads each org's default branch
over the GitHub API, and says who is behind, since when, and whether an upgrade PR is already open.
"""

from __future__ import annotations

import base64
import datetime as dt
import json
import re
import subprocess
from pathlib import Path
from typing import Any, Callable

import yaml

from . import __version__
from .tempo import hours

Runner = Callable[[list[str]], str]
VERSION_RE = re.compile(r'__version__\s*=\s*"(\d+)\.(\d+)\.(\d+)"')
UPGRADE_TITLE_PREFIX = "org-core "
CURRENT, AHEAD, BEHIND, BEHIND_PR_OPEN, UNREAD = "CURRENT", "AHEAD", "BEHIND", "BEHIND, PR OPEN", "UNREAD"


def _run(cmd: list[str]) -> str:
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if out.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd[:3])}: {(out.stderr or out.stdout).strip()[:300]}")
    return out.stdout


def parse_version(s: Any) -> tuple[int, int, int] | None:
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", str(s or ""))
    return (int(m[1]), int(m[2]), int(m[3])) if m else None


def load_registry(path: Path) -> list[dict[str, Any]]:
    """`fleet/orgs.yaml`: `orgs: [{id, repo, default_branch?, checkout?}, …]` — every org the fleet knows about."""
    data = yaml.safe_load(path.read_text()) or {}
    orgs = data.get("orgs") or []
    for o in orgs:
        if not o.get("id") or not o.get("repo"):
            raise ValueError(f"{path}: every org needs `id` and `repo`: {o}")
    return orgs


def version_history(repo_root: Path, run: Runner = _run) -> tuple[list[tuple[str, tuple[int, int, int]]], str | None]:
    """(committed_at, version) for every commit on the default branch's first-parent chain that set `__version__`,
    oldest first, from one `git log -p` (a merge shows its diff against the first parent, so a release that arrived
    by merge is dated by the merge) — and a note when the checkout cannot say: a shallow clone (this session's
    org-core checkout reached two commits on 2026-09-20) dates nothing, and says so rather than dating wrongly."""
    if run(["git", "-C", str(repo_root), "rev-parse", "--is-shallow-repository"]).strip() == "true":
        return [], f"shallow clone at {repo_root}: when the package moved past an org is unknown — `git fetch --unshallow origin` to date it"
    text = run(["git", "-C", str(repo_root), "log", "--first-parent", "--diff-merges=first-parent", "--reverse",
                "--format=commit %H %cI", "-p", "--", "org_core/__init__.py"])
    out: list[tuple[str, tuple[int, int, int]]] = []
    when: str | None = None
    for line in text.splitlines():
        if line.startswith("commit "):
            parts = line.split()
            when = parts[2] if len(parts) > 2 else None
        elif line.startswith("+") and not line.startswith("+++"):
            m = VERSION_RE.search(line)
            if m and when:
                out.append((when, (int(m[1]), int(m[2]), int(m[3]))))
    return out, None


def superseded_at(history: list[tuple[str, tuple[int, int, int]]], installed: tuple[int, int, int]) -> str | None:
    """When the package first moved past `installed`: the commit date of the first version above it."""
    for when, v in history:
        if v > installed:
            return when
    return None


def read_org(org: dict[str, Any], run: Runner = _run) -> dict[str, Any]:
    slug, branch = org["repo"], org.get("default_branch") or "main"
    rec: dict[str, Any] = {"id": org["id"], "repo": slug, "branch": branch, "installed": None, "lock_generated_at": None,
                           "lock_changed_at": None, "lock_commit": None, "upgrade_pr": None, "could_not_read": []}
    try:
        content = json.loads(run(["gh", "api", f"repos/{slug}/contents/.org/lock.yaml?ref={branch}"]))["content"]
        lock = yaml.safe_load(base64.b64decode(content)) or {}
        rec["installed"] = str(lock.get("org_core")) if lock.get("org_core") else None
        rec["lock_generated_at"] = lock.get("generated_at")
        if rec["installed"] is None:
            rec["could_not_read"].append("lock: no `org_core` in .org/lock.yaml")
    except Exception as e:   # a 404 is "no install on that branch", and says so
        rec["could_not_read"].append(f"lock: {str(e)[:160]}")
    try:
        commits = json.loads(run(["gh", "api", f"repos/{slug}/commits?path=.org/lock.yaml&sha={branch}&per_page=1"]))
        if commits:
            rec["lock_changed_at"] = commits[0]["commit"]["committer"]["date"]
            rec["lock_commit"] = str(commits[0]["sha"])[:7]
    except Exception as e:
        rec["could_not_read"].append(f"lock history: {str(e)[:160]}")
    try:
        prs = json.loads(run(["gh", "api", f"repos/{slug}/pulls?state=open&per_page=50"]))
        ups = [p for p in prs if str(p.get("title", "")).startswith(UPGRADE_TITLE_PREFIX)]
        if ups:
            p = ups[0]
            rec["upgrade_pr"] = {"number": p["number"], "title": p["title"], "opened_at": p.get("created_at"), "head": str((p.get("head") or {}).get("sha", ""))[:7]}
    except Exception as e:
        rec["could_not_read"].append(f"open PRs: {str(e)[:160]}")
    return rec


def report(registry: list[dict[str, Any]], *, package_version: str = __version__, history: list[tuple[str, tuple[int, int, int]]] | None = None,
           history_note: str | None = None, now: dt.datetime | None = None, run: Runner = _run) -> dict[str, Any]:
    now = now or dt.datetime.now(dt.timezone.utc)
    pkg = parse_version(package_version)
    rows = []
    for org in registry:
        r = read_org(org, run)
        inst = parse_version(r["installed"])
        r["package"] = package_version
        if inst is None:
            r["state"] = UNREAD
        elif inst == pkg:
            r["state"] = CURRENT
        elif inst > pkg:
            r["state"] = AHEAD    # the org carries a newer wheel than this checkout: this reading is from a stale org-core
        else:
            r["state"] = BEHIND_PR_OPEN if r["upgrade_pr"] else BEHIND
        r["superseded_at"] = superseded_at(history or [], inst) if inst and inst < (pkg or inst) else None
        r["hours_behind"] = hours(r["superseded_at"], now.isoformat()) if r["superseded_at"] else None
        rows.append(r)
    unread = sum(1 for r in rows if r["state"] == UNREAD)
    behind = sum(1 for r in rows if r["state"] == BEHIND)
    return {"package": package_version, "at": now.isoformat(timespec="seconds"), "orgs": rows, "history_note": history_note,
            "current": sum(1 for r in rows if r["state"] == CURRENT), "behind_no_pr": behind, "unread": unread,
            "exit": 2 if unread else (1 if behind else 0)}


def render(rep: dict[str, Any]) -> str:
    L = [f"fleet — org-core {rep['package']} at {rep['at']}", ""]
    for r in rep["orgs"]:
        line = f"  {r['id']:<12} {r['repo']:<28} {r['branch']:<6} {str(r['installed'] or '?'):<8} {r['state']}"
        if r.get("upgrade_pr"):
            line += f" #{r['upgrade_pr']['number']} (opened {r['upgrade_pr']['opened_at']}, head {r['upgrade_pr']['head']})"
        if r.get("superseded_at"):
            line += f" — the package moved past it at {r['superseded_at']}, {r['hours_behind']}h ago"
        if r.get("lock_changed_at"):
            line += f"; lock last changed {r['lock_changed_at']} ({r['lock_commit']})"
        L.append(line)
        for c in r["could_not_read"]:
            L.append(f"               could not read — {c}")
    if rep.get("history_note"):
        L.append(f"  (dates: {rep['history_note']})")
    L.append("")
    L.append(f"{rep['current']} of {len(rep['orgs'])} current; {rep['behind_no_pr']} behind with no upgrade PR; {rep['unread']} unread"
             + ("  (exit 2: an org could not be read)" if rep["unread"] else ("  (exit 1: an org is behind and nobody has opened its upgrade)" if rep["behind_no_pr"] else "")))
    return "\n".join(L)
