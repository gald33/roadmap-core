"""Lessons — the fleet's inflow (SPEC §11): what an org wrote into its own ground truth since a watermark.

An org learns in prose: a measured fact in CLAUDE.md, a rule in a role file's project section, a decision in the
operator file, a watchlist entry. Three repositories learn this way at once — org-core and every installed org — and
nothing joins them. `pull` reads one repository's ground-truth files from git since a watermark (an ISO time or a
commit) and writes every hunk with its provenance: commit, date, author, PR, file, and for a managed role file whether
the hunk landed in the generated base (a lesson that wants upstreaming, or an edit the next upgrade would have refused)
or in the org's own project section. `digest` renders one or more pulls as a reading for the curator, who decides what
generalises (an org-core template, a doctor check, a SPEC row), what stays one org's, and what contradicts the package.
Nothing here judges; the tags are a heuristic sort order for a reader, not a verdict.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import subprocess
from pathlib import Path
from typing import Any

#: the files that direct an installed org, relative to its checkout; the manifest adds the watchlist and the operator file
GROUND_TRUTH = ("CLAUDE.md", "AGENTS.md", "org.yaml", "docs/AGENT_ORG.md", "docs/ai", ".claude/agents", ".claude/skills", ".claude/hooks")
#: the files that direct org-core itself
CORE_GROUND_TRUTH = ("SPEC.md", "CLAUDE.md", "README.md", "org_core/templates", "org_core/roles", "fidelity")
#: generated, never a lesson
SKIP_SUFFIXES = ("ROADMAP.md", "ARCS.md")
#: the org's own lessons file: a managed file whose base is the format and whose project section is the rows (0.14.0)
LESSONS_REL = "docs/ai/lessons.md"
COLUMNS = ("id", "date", "role", "lesson", "source", "scope", "status")
TABLE_HEADER = "| id | date | role | lesson | source | scope | status |\n|---|---|---|---|---|---|---|\n"
STATUSES = ("open", "upstreamed", "already in org-core", "stays", "proposed", "contradiction", "could not tell")
_CELL_SPLIT = re.compile(r"(?<!\\)\|")
_REF_RE = re.compile(r"\b([A-Z])(\d+)(?:\s*[–-]\s*(?:[A-Z])?(\d+))?")
_VERSION_RE = re.compile(r"\b(\d+\.\d+\.\d+)\b")
PR_RE = re.compile(r"\(#(\d+)\)\s*$")
HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
STAMP_RE = re.compile(r"^(###\s+\S.*·|\*\*last run\*\*|- \*\*last run|last run:)", re.I)
TAG_RULES = (
    ("measured", re.compile(r"\bmeasured\b|\bverified\b|\bprobed\b", re.I)),
    ("rule", re.compile(r"\bnever\b|\bdo not\b|\bmust\b|⚠️|\balways\b", re.I)),
    ("pitfall", re.compile(r"\*\*(problem|fix)\b|\btrap\b|\bsilent(ly)?\b|\bfalse\b", re.I)),
    ("decision", re.compile(r"\boperator(?:'s)?\b.*\b(ruled|ruling|decided|decision|said|asked)\b|\bruling\b", re.I)),
    ("upstream", re.compile(r"\borg-core\b", re.I)),
)


def _run(cmd: list[str], cwd: Path) -> str:
    return subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, check=True).stdout


def is_core(repo: Path) -> bool:
    return (repo / "org_core").is_dir() and (repo / "SPEC.md").exists()


def ground_truth_paths(repo: Path, manifest: dict[str, Any] | None) -> list[str]:
    if is_core(repo) and not manifest:
        return list(CORE_GROUND_TRUTH)
    paths = list(GROUND_TRUTH)
    m = manifest or {}
    for p in ((m.get("org") or {}).get("paths") or {}).values():
        if isinstance(p, str) and p not in paths:
            paths.append(p)
    surface = (m.get("ports") or {}).get("operator_surface")
    if isinstance(surface, str) and surface not in paths:
        paths.append(surface)
    return [p for p in paths if (repo / p).exists() or True]   # git decides what existed; a missing path is simply empty history


def _section_of(repo: Path, commit: str, path: str, new_start: int) -> str:
    """Where a hunk landed in a managed role file at that commit: `base`, `project`, or `frontmatter`; `n/a` elsewhere."""
    if not (path.startswith(".claude/agents/") or path.startswith(".claude/skills/")):
        return "n/a"
    try:
        text = _run(["git", "show", f"{commit}:{path}"], repo)
    except subprocess.CalledProcessError:
        return "n/a"
    base_at = project_at = None
    for i, line in enumerate(text.splitlines(), 1):
        if line.strip() == "<!-- org-core:base -->" and base_at is None:
            base_at = i
        elif line.strip() == "<!-- org-core:project -->" and project_at is None:
            project_at = i
    if base_at is None:
        return "unmanaged"
    if project_at is not None and new_start >= project_at:
        return "project"
    if new_start >= base_at:
        return "base"
    return "frontmatter"


def tags_for(added: list[str]) -> list[str]:
    text = "\n".join(added)
    out = [name for name, rx in TAG_RULES if rx.search(text)]
    if added and all(STAMP_RE.match(l.strip()) or not l.strip() or l.strip().startswith(("- **", "* **", "**last", "**outcome", "**blocked")) for l in added[:6]) and any(STAMP_RE.match(l.strip()) for l in added[:3]):
        out.append("stamp")
    return out


def pull(repo: Path, manifest: dict[str, Any] | None, *, since: str, now: dt.datetime | None = None, max_lines: int = 400) -> dict[str, Any]:
    """Every hunk in the ground-truth files since `since` (an ISO time, or a commit: everything after it), newest last."""
    now = now or dt.datetime.now(dt.timezone.utc)
    repo = repo.resolve()
    paths = ground_truth_paths(repo, manifest)
    head = _run(["git", "rev-parse", "HEAD"], repo).strip()
    if re.fullmatch(r"[0-9a-f]{7,40}", since):
        rev = [f"{since}..HEAD"]
    else:
        rev = [f"--since={since}", "HEAD"]
    log = _run(["git", "log", "--reverse", "--no-merges", "--first-parent", *rev, "--format=%x1e%H%x1f%aI%x1f%an%x1f%s", "-p", "--no-color", "--unified=0", "--", *paths], repo)
    hunks: list[dict[str, Any]] = []
    commits: list[dict[str, Any]] = []
    for block in log.split("\x1e")[1:]:
        header, _, body = block.partition("\n")
        sha, date, author, subject = (header.split("\x1f") + ["", "", ""])[:4]
        pr = PR_RE.search(subject)
        c = {"commit": sha[:10], "date": date, "author": author, "subject": subject, "pr": int(pr.group(1)) if pr else None}
        commits.append(c)
        path = None
        cur: dict[str, Any] | None = None
        for line in body.splitlines():
            if line.startswith("diff --git "):
                path = line.split(" b/", 1)[-1] if " b/" in line else None
                cur = None
                continue
            if line.startswith(("+++", "---", "index ", "new file", "deleted file", "similarity", "rename ", "old mode", "new mode")):
                continue
            m = HUNK_RE.match(line)
            if m and path:
                if path.endswith(SKIP_SUFFIXES):
                    cur = None
                    continue
                new_start = int(m.group(3))
                cur = {**c, "file": path, "new_start": new_start, "section": _section_of(repo, sha, path, new_start), "added": [], "removed": []}
                hunks.append(cur)
                continue
            if cur is None:
                continue
            if line.startswith("+"):
                cur["added"].append(line[1:])
            elif line.startswith("-"):
                cur["removed"].append(line[1:])
    for h in hunks:
        h["tags"] = tags_for(h["added"])
        h["truncated"] = max(0, len(h["added"]) - max_lines)
        h["added"] = h["added"][:max_lines]
        h["removed"] = h["removed"][:max_lines]
    org_id = (manifest or {}).get("org", {}).get("id") if manifest else ("org-core" if is_core(repo) else repo.name)
    rows = file_rows(repo) if not is_core(repo) or manifest else []
    return {"kind": "lessons-pull", "org": org_id, "repo_head": head[:10], "since": since, "pulled_at": now.isoformat(timespec="seconds"),
            "paths": paths, "commits": commits, "hunks": hunks, "rows": rows,
            "counts": {"commits": len(commits), "hunks": len(hunks), "added_lines": sum(len(h["added"]) + h["truncated"] for h in hunks),
                       "rows": len(rows), "rows_open": sum(1 for r in rows if str(r.get("status", "")).startswith("open")),
                       "by_section": _count(hunks, "section"), "by_file": _count(hunks, "file")}}


def _count(hunks: list[dict[str, Any]], key: str) -> dict[str, int]:
    out: dict[str, int] = {}
    for h in hunks:
        out[h[key]] = out.get(h[key], 0) + 1
    return dict(sorted(out.items(), key=lambda kv: -kv[1]))


def merge_pulls(pulls: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Several orgs' pulls, one list of hunks each carrying its org."""
    out = []
    for p in pulls:
        for h in p.get("hunks", []):
            out.append({**h, "org": p.get("org")})
    return out


def digest(pulls: list[dict[str, Any]], *, min_added: int = 1, skip_tags: tuple[str, ...] = ("stamp",), skip_sections: tuple[str, ...] = (),
           max_lines: int = 60, subjects_skip: tuple[str, ...] = ()) -> str:
    """A reading for the curator: per org, per file, every hunk with its provenance, tags and added text (trimmed)."""
    L: list[str] = []
    for p in pulls:
        hs = [h for h in p.get("hunks", []) if len(h["added"]) + h.get("truncated", 0) >= min_added and not (set(h.get("tags", [])) & set(skip_tags))
              and h["section"] not in skip_sections and not any(h["subject"].startswith(s) for s in subjects_skip)]
        L.append(f"# {p.get('org')} — {len(hs)} hunk(s) of {p['counts']['hunks']} since {p['since']} (head {p['repo_head']}, pulled {p['pulled_at']})")
        L.append("")
        open_rows = [r for r in p.get("rows", []) if str(r.get("status", "")).startswith("open")]
        if open_rows:
            L.append(f"## {LESSONS_REL} — {len(open_rows)} open row(s), read these first")
            for r in open_rows:
                L.append(f"- {r['id']} · {r['date']} · {r['role']} · {r['scope']} — {r['lesson'][:400]}" + (f" (source: {r['source'][:120]})" if r.get("source") else ""))
            L.append("")
        by_file: dict[str, list[dict[str, Any]]] = {}
        for h in hs:
            by_file.setdefault(h["file"], []).append(h)
        for f, items in by_file.items():
            L.append(f"## {f}  ({len(items)} hunk(s))")
            for h in items:
                pr = f" #{h['pr']}" if h.get("pr") else ""
                L.append(f"### {h['commit']} {h['date'][:10]} {h['author']}{pr} — {h['subject'][:110]}")
                L.append(f"section: {h['section']} · tags: {', '.join(h['tags']) or '—'} · +{len(h['added']) + h.get('truncated', 0)}/−{len(h['removed'])} lines")
                if h["removed"]:
                    L.append("removed:")
                    L.extend("    - " + l for l in h["removed"][:max(6, max_lines // 4)])
                L.append("added:")
                L.extend("    " + l for l in h["added"][:max_lines])
                if len(h["added"]) > max_lines or h.get("truncated"):
                    L.append(f"    … {len(h['added']) - max_lines + h.get('truncated', 0)} more line(s)")
                L.append("")
    return "\n".join(L) + "\n"


# --- the org's lessons file --------------------------------------------------------------

def _cells(line: str) -> list[str]:
    parts = _CELL_SPLIT.split(line.strip())
    if len(parts) >= 2 and parts[0].strip() == "" and parts[-1].strip() == "":
        parts = parts[1:-1]
    return [c.strip().replace("\\|", "|") for c in parts]


def _esc(s: Any) -> str:
    return str(s).replace("|", "\\|").replace("\n", " ").strip()


def _is_rule_line(cells: list[str]) -> bool:
    return bool(cells) and all(set(c) <= set("-: ") for c in cells)


def parse_rows(text: str) -> list[dict[str, str]]:
    """The rows of a lessons table, whatever else the text holds; the header and the rule line are skipped."""
    rows: list[dict[str, str]] = []
    for line in text.splitlines():
        if not line.lstrip().startswith("|"):
            continue
        cells = _cells(line)
        if not cells or cells[0] == "id" or _is_rule_line(cells):
            continue
        cells = (cells + [""] * len(COLUMNS))[:len(COLUMNS)]
        rows.append(dict(zip(COLUMNS, cells)))
    return rows


def render_row(row: dict[str, Any]) -> str:
    return "| " + " | ".join(_esc(row.get(c, "")) for c in COLUMNS) + " |"


def status_label(entry: dict[str, Any]) -> str:
    label = str(entry.get("status") or "open")
    if entry.get("version") and label == "upstreamed":
        label += f" {entry['version']}"
    if entry.get("where"):
        label += f" — {entry['where']}"
    return label


def apply_statuses(project_text: str, statuses: dict[str, dict[str, Any]]) -> tuple[str, list[str]]:
    """The one edit org-core makes inside a project section: the `status` column of a row the curator has answered."""
    out, changed = [], []
    for line in project_text.splitlines():
        if line.lstrip().startswith("|"):
            cells = _cells(line)
            if cells and cells[0] in statuses and not _is_rule_line(cells):
                cells = (cells + [""] * len(COLUMNS))[:len(COLUMNS)]
                label = status_label(statuses[cells[0]])
                if cells[6] != label:
                    cells[6] = label
                    changed.append(cells[0])
                    line = "| " + " | ".join(_esc(c) for c in cells) + " |"
        out.append(line)
    text = "\n".join(out)
    if project_text.endswith("\n"):
        text += "\n"
    return text, changed


def load_statuses(path: Path | None = None) -> dict[str, dict[str, Any]]:
    """The curator's answers, shipped with the package as org_core/lessons_status.json (written by `org lessons status`)."""
    p = path or Path(__file__).with_name("lessons_status.json")
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text())
    except json.JSONDecodeError:
        return {}
    return {k: v for k, v in data.items() if isinstance(v, dict)} if isinstance(data, dict) else {}


def normalize_scope(scope: str) -> str:
    s = scope.strip().strip("*").lower()
    if s.startswith("general"):
        return "general"
    if "already" in s:
        return "already in org-core"
    if s.startswith("org-specific") or "own" in s[:30]:
        return "org-specific"
    if "contradict" in s:
        return "contradicts org-core"
    return s[:40] or "unsure"


def role_of(source: str, names: dict[str, str] | None = None) -> str:
    low = source.lower()
    for name, role in (names or {}).items():
        if name and name.lower() in low:
            return role
    m = re.search(r"\((ceo|dispatcher|builder|reviewer|verifier|checks-watch|registrar|account-manager|methods|doctor)\)", low)
    if m:
        return m.group(1)
    for r in ("account-manager", "checks-watch", "dispatcher", "registrar", "reviewer", "verifier", "builder", "methods", "doctor", "ceo"):
        if f"/{r}" in low or f"{r}." in low or f"{r}/" in low:
            return r
    return "—"


def rows_from_extraction(text: str, org: str, date: str, *, statuses: dict[str, dict[str, Any]] | None = None,
                         names: dict[str, str] | None = None) -> list[dict[str, str]]:
    """A reader's extraction table (`# | lesson | source | scope | destination | confidence`) as rows of the org's file:
    id `<org>-<date>-<n>`, the lesson and source verbatim, the scope normalised, the status from the curator's answers."""
    statuses = statuses or {}
    out = []
    for line in text.splitlines():
        if not line.lstrip().startswith("|"):
            continue
        cells = _cells(line)
        if len(cells) < 4 or not cells[0].isdigit():
            continue
        rid = f"{org}-{date}-{cells[0]}"
        out.append({"id": rid, "date": date, "role": role_of(cells[2], names), "lesson": cells[1], "source": cells[2],
                    "scope": normalize_scope(cells[3]), "status": status_label(statuses[rid]) if rid in statuses else "open"})
    return out


def seed(project_text: str, rows: list[dict[str, str]]) -> tuple[str, int]:
    """Append rows whose id the table does not carry yet; the header is written if the section has no table."""
    have = {r["id"] for r in parse_rows(project_text)}
    fresh = [r for r in rows if r["id"] not in have]
    text = project_text
    if "| id |" not in text:
        text = text.rstrip("\n") + ("\n\n" if text.strip() else "") + TABLE_HEADER
    if fresh:
        text = text.rstrip("\n") + "\n" + "\n".join(render_row(r) for r in fresh) + "\n"
    return text, len(fresh)


def file_rows(repo: Path, rev: str = "HEAD") -> list[dict[str, str]]:
    """The rows of the org's lessons file at a revision, [] when there is no such file."""
    try:
        text = _run(["git", "show", f"{rev}:{LESSONS_REL}"], repo)
    except subprocess.CalledProcessError:
        return []
    m = re.search(r"<!-- org-core:project -->\n(.*?)<!-- org-core:end -->", text, re.S)
    return parse_rows(m.group(1) if m else text)


def brief(org_id: str, *, digest_path: str, digest_lines: int, core_path: str, out_path: str, since: str, head: str) -> str:
    from .render import render_base
    src = (Path(__file__).parent / "templates" / "lessons-brief.md").read_text()
    return render_base(src, {"org_id": org_id, "digest_path": digest_path, "digest_lines": digest_lines, "core_path": core_path,
                             "out_path": out_path, "since": since, "head": head})


def _extraction_counts(text: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for line in text.splitlines():
        if not line.lstrip().startswith("|"):
            continue
        cells = _cells(line)
        if len(cells) >= 4 and cells[0].isdigit():
            k = normalize_scope(cells[3])
            counts[k] = counts.get(k, 0) + 1
    return counts


def ledger_scaffold(pulls: list[dict[str, Any]], extractions: list[tuple[str, str]], date: str) -> str:
    """The curated ledger's fixed shape, with the watermarks and counts filled in and the judgment left to the curator."""
    L = [f"# Lessons — {date}", "", "**Watermarks.** " + " ".join(
        f"{p.get('org')}: since `{p.get('since')}` → head `{p.get('repo_head')}` ({p['counts']['commits']} commit(s), {p['counts']['hunks']} hunk(s), "
        f"{p['counts'].get('rows_open', 0)} open row(s) in docs/ai/lessons.md)." for p in pulls),
        "The next pull starts from these heads.", ""]
    L.append("**Method.** `org lessons pull` per repository; `org lessons digest` (stamps and installer re-renders skipped); one reader per org "
             "with `org lessons brief`, reading the whole digest and checking every lesson against org-core before scoping it; the readers' tables "
             "kept verbatim beside this file; this ledger is the curator's decision per lesson. Row references below are `<letter><n>` into those tables.")
    L.append("")
    for org, text in extractions:
        c = _extraction_counts(text)
        L.append(f"- {org}: {sum(c.values())} lessons — " + ", ".join(f"{k} {v}" for k, v in sorted(c.items(), key=lambda kv: -kv[1])))
    L += ["", "## Dispersed — org-core <version>, reaching each org by `org upgrade`", "", "| lesson | rows | where it went |", "|---|---|---|",
          "| (the curator writes this) | | |", "",
          "## Already in org-core — verified by the readers, file and line", "", "(row references)", "",
          "## Stays with the org", "", "(row references)", "",
          "## Contradictions, both dated", "", "(numbered, each with its resolution or its owner)", "",
          "## Proposed, not adopted blind", "", "- (row references)", "",
          "## Could not tell", "", "- (row references)", ""]
    return "\n".join(L)


_SECTION_STATUS = (("dispersed", "upstreamed"), ("contradiction", "contradiction"), ("already in org-core", "already in org-core"),
                   ("stays", "stays"), ("proposed", "proposed"), ("could not tell", "could not tell"))


def status_from_ledger(md: str, prefixes: dict[str, str]) -> dict[str, dict[str, Any]]:
    """The curator's answers, read out of a ledger written in the scaffold's shape: every `<letter><n>` reference in a section
    takes that section's status; `prefixes` maps the letter to the org's row-id prefix (`N` → `numerotech-2026-09-19`).
    A row named in several sections keeps the first in this order: dispersed, contradictions, already, stays, proposed, could not tell."""
    sections: dict[str, list[str]] = {}
    cur = None
    for line in md.splitlines():
        if line.startswith("## "):
            cur = line[3:].strip().lower()
            sections[cur] = []
        elif cur is not None:
            sections[cur].append(line)
    out: dict[str, dict[str, Any]] = {}
    for key, status in _SECTION_STATUS:
        for name, lines in sections.items():
            if not name.startswith(key):
                continue
            for line in lines:
                version = None
                where = None
                if status == "upstreamed" and line.lstrip().startswith("|"):
                    cells = _cells(line)
                    if len(cells) >= 3 and not _is_rule_line(cells) and cells[0] != "lesson":
                        m = _VERSION_RE.search(cells[2])
                        version = m.group(1) if m else None
                        where = cells[2][:90]
                        refs_text = cells[1]
                    else:
                        continue
                else:
                    refs_text = line
                for m in _REF_RE.finditer(refs_text):
                    letter, a, b = m.group(1), int(m.group(2)), m.group(3)
                    if letter not in prefixes:
                        continue
                    for n in range(a, (int(b) if b else a) + 1):
                        rid = f"{prefixes[letter]}-{n}"
                        if rid not in out:
                            entry: dict[str, Any] = {"status": status}
                            if version:
                                entry["version"] = version
                            if where:
                                entry["where"] = where
                            out[rid] = entry
    return out
