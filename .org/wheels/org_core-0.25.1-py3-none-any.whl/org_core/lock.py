"""`.org/lock.yaml` — what was rendered from which template (SPEC.md §6, §14)."""

from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Any

import yaml

from . import __version__
from .render import sha256

LOCK_REL = ".org/lock.yaml"
INSTALL_LOG_REL = ".org/install.jsonl"


def build(manifest: dict[str, Any], packages: dict[str, Any], actions: list[Any]) -> dict[str, Any]:
    files: dict[str, Any] = {}
    for a in actions:
        if a.kind in ("manifest", "settings", "mcp") or a.content is None:
            continue   # the org's own files: merged by entry, never hashed — the org edits them freely
        files[a.path] = {
            "role": a.role,
            "kind": a.kind,
            "template_version": packages[a.role].version if a.role in packages else __version__,   # an org-level managed file (docs/ai/lessons.md) is versioned by org-core itself
            "template_sha256": a.template_sha256,
            "rendered_sha256": sha256(a.content),
            "base_sha256": a.base_sha256,
        }
    from .suite import suite_of

    suite = suite_of(manifest)
    return {
        "org_core": __version__,
        "manifest_version": manifest["manifest_version"],
        "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "ports": {k: (v.get("tool") if isinstance(v, dict) else v) for k, v in manifest["ports"].items()},
        "suite": {name: {k: v for k, v in (("policy", c["policy"]), ("spec", c.get("spec")), ("cli", c.get("cli")), ("mcp", c.get("mcp"))) if v}
                  for name, c in suite.enabled().items()},
        "files": dict(sorted(files.items())),
    }


def write(repo: Path, lock: dict[str, Any]) -> Path:
    p = repo / LOCK_REL
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(yaml.safe_dump(lock, sort_keys=False))
    return p


def read(repo: Path) -> dict[str, Any] | None:
    p = repo / LOCK_REL
    if not p.exists():
        return None
    return yaml.safe_load(p.read_text()) or {}
