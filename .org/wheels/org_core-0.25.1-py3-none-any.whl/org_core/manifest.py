"""Load, validate and layer an org manifest (SPEC.md §2).

Layers, later wins: package defaults (each role package's `role.yaml`) →
the project's `org.yaml`. Runtime knobs (§10) are not read here; they live on
the coordination board and are the doctor's business.
"""

from __future__ import annotations

import copy
import json
import re
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from . import ROLE_IDS

SCHEMA_PATH = Path(__file__).parent / "schemas" / "org.schema.json"


class ManifestError(Exception):
    """The manifest cannot be used. The message lists every problem found."""


def load_schema() -> dict[str, Any]:
    return json.loads(SCHEMA_PATH.read_text())


PLACEHOLDER = re.compile(r"<[^<>]+>")


def unfilled(data: Any) -> list[str]:
    """Every value `org init` left for a person to fill, still unfilled.

    `init --write` writes a draft whose unknowns are `<...>` — it says so
    itself: "every <...> is a value the tool would not guess". Nothing read
    them back. Measured 2026-09-22 against 0.24.2: a manifest still saying
    `repo: <owner/repo>` passed `validate` (exit 0) and `apply` (exit 0),
    which rendered 24 files with the literal text in 21 of them, including
    `org-setup.sh` exporting `SWITCHBOARD_URL='<hub url>'`. The install
    reported success and was unusable.

    Broken looks like: this returns [] for a manifest whose `org.repo` is
    `<owner/repo>`. The match is any `<...>` inside a string value, not just
    a whole-value one, because `init` emits embedded ones too
    (`fleet.report_to: <org-core repo>/fleet/repo-`). A real value containing
    angle brackets would be a false positive; it names the path, so it reads
    as one rather than as a mystery.
    """
    return [f"{path}: {value} — still the draft `org init` wrote" for path, value, _ in _placeholders(data)]


def _placeholders(data: Any) -> list[tuple[str, str, list[str]]]:
    """(dotted manifest path, the whole value, the `<...>` fragments in it), sorted.

    The path is the one an operator edits — `ports.coordination.url`, not the
    render-context name `hub_url` — because the only job of this list is to tell
    somebody which line of `org.yaml` to change.
    """
    out: list[tuple[str, str, list[str]]] = []

    def walk(node: Any, path: str) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{path}.{k}" if path else str(k))
        elif isinstance(node, list):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")
        elif isinstance(node, str):
            found = PLACEHOLDER.findall(node)
            if found:
                out.append((path, node, found))

    walk(data, "")
    return sorted(out)


def unfilled_rendered(data: Any) -> list[str]:
    """The unfilled values that reach role files — the fatal subset.

    Computed from `flat_vars`, which IS the render context, rather than from a
    hand-kept list of field names: a field that becomes rendered is covered the
    day it is added, and one that stops being rendered stops being fatal.

    Why a subset at all. Measured 2026-09-22: `examples/lucille/org.yaml` and
    NumeroTech's live manifest each carry four `<...>` values — `budget.daily_usd`,
    `fleet.report_to`, `fleet.workspace`, `org.account`. They are real and worth
    filling, but none is read by `flat_vars`, so none has ever been written into a
    role file, and failing `validate` on them would redden two running orgs over
    text no agent reads. What DID reach files is the other kind: `<owner/repo>`
    and `<hub url>` landed in 21 of 24 rendered files, including `org-setup.sh`
    exporting `SWITCHBOARD_URL='<hub url>'`.

    Broken looks like: this returns [] for a manifest whose `org.repo` is
    `<owner/repo>`, or a non-empty list for either shipped example manifest.
    """
    try:
        ctx = flat_vars(data)
    except Exception:
        return []     # malformed beyond the placeholder question; the schema errors say so

    rendered: set[str] = set()

    def collect(node: Any) -> None:
        if isinstance(node, dict):
            for v in node.values():
                collect(v)
        elif isinstance(node, list):
            for v in node:
                collect(v)
        elif isinstance(node, str):
            rendered.update(PLACEHOLDER.findall(node))

    collect(ctx)
    return [
        f"{path}: {value} — fill this; it renders into role files"
        for path, value, found in _placeholders(data)
        if rendered.intersection(found)
    ]


def validate(data: Any) -> list[str]:
    """Every schema violation as one line; empty means valid.

    Includes the unfilled-draft check for values that reach the renderer, so
    `read` — and therefore `plan`, `apply` and `upgrade` — fail closed on a
    manifest nobody finished. `unfilled` is the wider advisory list.
    """
    validator = jsonschema.Draft202012Validator(load_schema())
    problems = []
    for err in sorted(validator.iter_errors(data), key=lambda e: list(e.absolute_path)):
        where = "/".join(str(p) for p in err.absolute_path) or "<root>"
        problems.append(f"{where}: {err.message}")
    if problems:
        return problems
    return unfilled_rendered(data)


def read(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise ManifestError(f"no manifest at {p}")
    data = yaml.safe_load(p.read_text()) or {}
    problems = validate(data)
    if problems:
        raise ManifestError("manifest invalid:\n  " + "\n  ".join(problems))
    return data


def layer(manifest: dict[str, Any], role_defaults: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Fill each declared role from its package defaults; the manifest wins.

    A role the manifest does not mention is not installed — absence is a
    decision, not a default. The result is what every other module reads.
    """
    out = copy.deepcopy(manifest)
    roles = out.setdefault("roles", {})
    for role_id, entry in roles.items():
        defaults = role_defaults.get(role_id, {})
        merged: dict[str, Any] = {}
        merged.update(defaults)
        merged.update(entry)
        merged.setdefault("enabled", True)
        roles[role_id] = merged
    return out


def enabled_roles(manifest: dict[str, Any]) -> list[str]:
    return [r for r in ROLE_IDS if r in manifest.get("roles", {}) and manifest["roles"][r].get("enabled", True)]


def flat_vars(manifest: dict[str, Any]) -> dict[str, Any]:
    """The render context: a flat namespace derived from the structured manifest.

    Templates use these names. Anything a role needs that the manifest does not
    declare is left OUT of the context on purpose, so the renderer's strict
    mode reports "role X needs Y, undeclared" instead of printing a blank.
    """
    org = manifest["org"]
    ports = manifest["ports"]
    v: dict[str, Any] = {}
    v["org_id"] = org["id"]
    v["repo"] = org["repo"]
    v["repo_url"] = f"https://github.com/{org['repo']}"
    v["default_branch"] = org["default_branch"]
    v["checkout"] = org.get("checkout") or f"/home/user/{org['repo'].split('/')[1]}"
    v["operator_name"] = org["operator"]["name"]
    if "watchlist" in org.get("paths", {}):
        v["watchlist"] = org["paths"]["watchlist"]

    ws = ports["work_store"]
    v["roadmap_cli"] = ws["cli"]
    v["work_store_mode"] = ws["mode"]
    if "credential" in ws:
        v["store_credential"] = ws["credential"]
    if "sync_workflow" in ws:
        v["sync_workflow"] = ws["sync_workflow"]

    co = ports["coordination"]
    v["workspace"] = co["workspace"]
    v["hub_url"] = co["url"]

    ch = ports.get("checks") or {"tool": "absent"}
    v["checks_tool"] = ch.get("tool", "absent")
    if ch.get("tool") != "absent":
        if "runner" in ch:
            v["checks_runner"] = ch["runner"]
        if "read_only_invocation" in ch:
            v["checks_read_only_invocation"] = ch["read_only_invocation"]
        if ch.get("tool") == "checks-core":
            v["checks_registry"] = ch.get("registry", "checks/registry.yaml")
            v["checks_results"] = ch.get("results", "checks/results.jsonl")
            v["checks_executor"] = ch.get("executor", "manual")
            v["checks_dsn_env"] = ch.get("dsn_env", "CHECKS_DSN")

    if "tickets" in ports and ports["tickets"].get("tool") != "absent":
        tk = ports["tickets"]
        if "cli" in tk:
            v["ticket_cli"] = tk["cli"]
        if "user_visible_status" in tk:
            v["user_visible_status"] = tk["user_visible_status"]

    if "prod_read" in ports:
        pr = ports["prod_read"]
        v["prod_read_method"] = pr["method"]
        for k in ("credential", "mint_opt_in", "mint_script", "jwt_cache", "guard"):
            if k in pr:
                v[{"credential": "admin_jwt"}.get(k, k)] = pr[k]

    v["operator_surface"] = ports["operator_surface"]

    names: dict[str, str] = {}
    labels: dict[str, str] = {}
    for role_id, entry in manifest.get("roles", {}).items():
        names[role_id.replace("-", "_")] = entry["name"]
        if entry.get("cadence_label"):
            labels[role_id.replace("-", "_")] = entry["cadence_label"]
    v["names"] = names
    v["cadence_label"] = labels

    owns = manifest.get("operator_owns", {})
    v["merge_owner"] = owns.get("merge_to_main", "operator")
    return v
