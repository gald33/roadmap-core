"""The operator file, rendered from the board by the chair (SPEC §9; rows 65, 98).

`docs/human/state-of-the-org.md` is the one report the operator reads without an agent. Until 0.19.0 every role wrote
its own three lines there from its own branch, and the file then said `never ran` for roles that ran daily: a stamp in a
pull request sits behind whatever merges before it, and every settlement PR also rewrote the generated roadmap view, so
the merge ahead dirtied the one behind. Three NumeroTech roles reported the same wall in their own words (row 98).

So the chair — the one role with a path to `main` — renders every role's section from `roles/<role>/last-run` each wake
and commits the file. Only the three bullet lines are touched: **last run** from the record's `at`, **outcome** from its
`headline`, **blocked** from its `blocked`. Everything else in the file is the org's prose and is kept byte for byte.
"""

from __future__ import annotations

import datetime as dt
import re
from dataclasses import dataclass
from typing import Any

HEADING_RE = re.compile(r"^### (?P<name>[^—\n]+) — (?P<role>[A-Za-z][A-Za-z -]*[A-Za-z]) · (?P<label>.+)$")
BULLET_RE = re.compile(r"^- \*\*(?P<label>last run|outcome|blocked):\*\* ?(?P<rest>.*)$")
LABELS = ("last run", "outcome", "blocked")
END_RE = re.compile(r"^(#{1,3} |---\s*$)")


@dataclass
class Section:
    role: str
    heading: str
    lines: dict[str, str]   # label -> one-line value


def _one_line(v: Any, cap: int) -> str:
    s = " ".join(str(v).split())
    return s if len(s) <= cap else s[: cap - 1].rstrip() + "…"


def lines_from_record(role: str, key: str, rec: dict[str, Any] | None, now: dt.datetime) -> dict[str, str]:
    """The three lines a record yields. No record: `never`, and where the doctor would have looked."""
    from .doctor import parse_ts
    if not rec:
        return {"last run": f"never — no record at `{key}` on the board (rendered {now.strftime('%Y-%m-%d %H:%MZ')})", "outcome": "—", "blocked": "unknown — no record"}
    at = parse_ts(rec.get("at"))
    when = at.astimezone(dt.timezone.utc).strftime("%Y-%m-%d %H:%MZ") if at else _one_line(rec.get("at") or "unknown", 40)
    if str(rec.get("status") or "") == "in_progress":
        when += " (in progress — the run had not finished when this was rendered)"
    outcome = rec.get("headline") or rec.get("outcome") or rec.get("summary") or "—"
    blocked = rec.get("blocked")
    return {"last run": when, "outcome": _one_line(outcome, 400), "blocked": "no" if not blocked else _one_line(blocked, 600)}


def _norm_role(s: str) -> str:
    return s.strip().lower().replace(" ", "-")


def render(text: str, sections: list[Section]) -> tuple[str, list[str]]:
    """Rewrite each section's three bullet lines; append a section that is missing; keep everything else. Returns the new
    text and one change line per section touched (empty when the file already says what the board says)."""
    lines = text.split("\n")
    changes: list[str] = []
    # locate sections: heading line index -> (role, end index exclusive)
    heads: list[tuple[int, str]] = [(i, _norm_role(m["role"])) for i, l in enumerate(lines) if (m := HEADING_RE.match(l))]
    for sec in sections:
        idx = next((i for i, r in heads if r == sec.role), None)
        if idx is None:
            block = ["", sec.heading, ""] + [f"- **{k}:** {sec.lines[k]}" for k in LABELS]
            if lines and lines[-1] != "":
                lines.append("")
            lines.extend(block)
            changes.append(f"{sec.role}: section added")
            heads = [(i, _norm_role(m["role"])) for i, l in enumerate(lines) if (m := HEADING_RE.match(l))]
            continue
        end = next((j for j in range(idx + 1, len(lines)) if END_RE.match(lines[j])), len(lines))
        body = lines[idx + 1:end]
        # bullet blocks: a bullet line plus its indented continuation lines
        blocks: list[tuple[str | None, list[str]]] = []
        for l in body:
            if BULLET_RE.match(l):
                blocks.append((BULLET_RE.match(l)["label"], [l]))
            elif l.startswith("- **") or not (l.startswith("  ") and blocks and blocks[-1][0] is not None):
                blocks.append((None, [l]))
            else:
                blocks[-1][1].append(l)
        new_body: list[str] = []
        seen: set[str] = set()
        touched = False
        for label, blk in blocks:
            if label in LABELS:
                want = f"- **{label}:** {sec.lines[label]}"
                if blk != [want]:
                    touched = True
                new_body.append(want)
                seen.add(label)
            else:
                new_body.extend(blk)
        missing = [k for k in LABELS if k not in seen]
        if missing:
            touched = True
            insert_at = 1 if new_body and new_body[0] == "" else 0
            for k in reversed(missing):
                new_body.insert(insert_at, f"- **{k}:** {sec.lines[k]}")
            if insert_at == 0:
                new_body.insert(0, "")
        if touched:
            changes.append(f"{sec.role}: {', '.join(k for k in LABELS)} rendered")
        lines[idx + 1:end] = new_body
        heads = [(i, _norm_role(m["role"])) for i, l in enumerate(lines) if (m := HEADING_RE.match(l))]
    return "\n".join(lines), changes


def heading_for(role_id: str, manifest: dict[str, Any], contract: dict[str, Any]) -> str:
    entry = manifest["roles"].get(role_id) or {}
    name = entry.get("name") or contract.get("display") or role_id
    cad = contract.get("cadence") or {}
    label = entry.get("cadence_label") or (cad.get("label") if isinstance(cad, dict) else None) or entry.get("cadence") or ""
    fmt = contract.get("stamps") or "### {name} — " + role_id + " · {cadence_label}"
    return fmt.format(name=name, cadence_label=label)


def render_repo(repo, manifest: dict[str, Any], packages: dict[str, Any], read_record, now: dt.datetime | None = None, roles: list[str] | None = None) -> tuple[str, str, list[str]]:
    """(relative path, new text, changes) for the org's operator file, from `read_record(key) -> dict | None`."""
    from .manifest import enabled_roles
    now = now or dt.datetime.now(dt.timezone.utc)
    rel = manifest["ports"]["operator_surface"]
    p = repo / rel
    text = p.read_text() if p.exists() else "# State of the org\n"
    secs: list[Section] = []
    for rid in enabled_roles(manifest):
        pkg = packages.get(rid)
        contract = pkg.contract if pkg is not None else {}
        if not contract.get("stamps"):
            continue
        if roles and rid not in roles:
            continue
        key = (manifest["roles"][rid] or {}).get("report_key") or f"roles/{rid}/last-run"
        secs.append(Section(rid, heading_for(rid, manifest, contract), lines_from_record(rid, key, read_record(key), now)))
    new, changes = render(text, secs)
    return rel, new, changes
