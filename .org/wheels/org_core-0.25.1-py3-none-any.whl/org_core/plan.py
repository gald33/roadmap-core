"""`org plan`: what apply would do to a repository, without doing it (SPEC.md §6)."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from .manifest import enabled_roles, flat_vars
from .render import (
    UndeclaredVariable,
    frame,
    normalize,
    parse_managed,
    render_base,
    split_frontmatter,
    strip_markers,
    unified,
)
from .roles import RolePackage

STATUSES = ("new", "unchanged", "markers-only", "upgrade", "merge", "adopt", "changed", "undeclared", "error")

TEMPLATES = Path(__file__).parent / "templates"
FRONTMATTER = {
    "agent": "---\nname: {[ role_id ]}\ndescription: >-\n  {[ contract.description ]}\ntools: {[ contract.tools ]}\nmodel: {[ role.model ]}\n---\n",
    "skill": "---\nname: {[ role_id ]}\ndescription: >-\n  {[ contract.skill_description ]}\n---\n",
}
PROJECT_SEED_NAMES = {"agent": "agent.md", "skill": "SKILL.md"}


@dataclass
class FileAction:
    path: str
    role: str
    kind: str
    status: str
    detail: str = ""
    diff: str = ""
    content: str | None = None
    template_sha256: str | None = None
    base_sha256: str | None = None

    @property
    def diff_lines(self) -> int:
        return sum(1 for line in self.diff.splitlines() if line[:1] in "+-" and not line.startswith(("+++", "---")))


@dataclass
class Plan:
    actions: list[FileAction] = field(default_factory=list)

    def by_status(self) -> dict[str, int]:
        out = {s: 0 for s in STATUSES}
        for a in self.actions:
            out[a.status] = out.get(a.status, 0) + 1
        return out

    @property
    def worst(self) -> str:
        order = ["error", "undeclared", "changed", "adopt", "upgrade", "merge", "new", "markers-only", "unchanged"]
        present = {a.status for a in self.actions}
        for s in order:
            if s in present:
                return s
        return "empty"

    def blocking(self) -> list[FileAction]:
        return [a for a in self.actions if a.status in ("error", "undeclared")]


def _today() -> str:
    import datetime as dt

    return dt.datetime.now(dt.timezone.utc).date().isoformat()


def _render_role(manifest: dict[str, Any], role_id: str, pkg: RolePackage, kind: str, ctx_base: dict[str, Any]) -> tuple[str, str, str]:
    """(frontmatter, base body, template source hashed) for one role file."""
    from . import __version__
    from .doctor import cron_period_hours
    from .render import sha256

    entry = manifest["roles"][role_id]
    ctx = dict(ctx_base)
    ctx["role"] = entry
    ctx["role_id"] = role_id
    ctx["contract"] = pkg.contract
    ctx["org_core_version"] = __version__
    ctx["operator_owns"] = manifest.get("operator_owns", {})
    ctx["report_key"] = entry.get("report_key") or f"roles/{role_id}/last-run"
    ctx["period_hours"] = entry.get("period_hours") or cron_period_hours(entry.get("cadence", ""))
    ctx["counts_required"] = list((pkg.record_schema or {}).get("required", []))
    ctx["lists_optional"] = [k for k, v in ((pkg.record_schema or {}).get("properties") or {}).items() if isinstance(v, dict) and v.get("type") == "array"]   # item-name lists beside the counts (row 94)
    from .tempo import DEFAULT_LISTEN_MINUTES
    ctx["listen_minutes"] = int((manifest.get("tempo") or {}).get("listen_minutes") or DEFAULT_LISTEN_MINUTES)
    ctx["listen_label"] = f"{ctx['listen_minutes'] // 60} h" if ctx["listen_minutes"] % 60 == 0 else f"{ctx['listen_minutes']} min"
    addendum_src = pkg.addenda[kind].read_text() if kind in pkg.addenda else ""
    ctx["addendum"] = render_base(addendum_src, ctx) if addendum_src else ""
    core_src = (TEMPLATES / f"{kind}.core.md").read_text()
    body = "\n" + render_base(core_src, ctx)
    fm = render_base(FRONTMATTER[kind], ctx)
    return fm, body, sha256(core_src + addendum_src)


def _seed_ctx(manifest: dict[str, Any], role_id: str, pkg: RolePackage, ctx_base: dict[str, Any]) -> dict[str, Any]:
    ctx = dict(ctx_base)
    ctx["role"] = manifest["roles"][role_id]
    ctx["role_id"] = role_id
    ctx["contract"] = pkg.contract
    return ctx


def _role_files(repo: Path, manifest: dict[str, Any], role_id: str, pkg: RolePackage, ctx_base: dict[str, Any], lock: dict[str, Any] | None,
                adopt_existing: bool, project_from: Path | None) -> list[FileAction]:
    from .render import sha256

    out: list[FileAction] = []
    locked = (lock or {}).get("files", {})
    for kind in RolePackage.KINDS:
        rel = pkg.target(kind)
        target = repo / rel
        try:
            fm, body, tpl_hash = _render_role(manifest, role_id, pkg, kind, ctx_base)
        except UndeclaredVariable as e:
            out.append(FileAction(rel, role_id, kind, "undeclared", detail=f"template needs a value the manifest does not declare: {e}"))
            continue
        base_hash = sha256(normalize(body))
        existing = target.read_text() if target.exists() else None

        if existing is None:
            seed = ""
            if project_from is not None:
                sp = project_from / role_id / PROJECT_SEED_NAMES[kind]
                if sp.exists():
                    # a seed is rendered ONCE, here — an extracted seed carries template variables; a project section never does
                    try:
                        seed = render_base(sp.read_text(), _seed_ctx(manifest, role_id, pkg, ctx_base))
                    except UndeclaredVariable as e:
                        out.append(FileAction(rel, role_id, kind, "undeclared", detail=f"project seed {sp} needs a value the manifest does not declare: {e}"))
                        continue
            out.append(FileAction(rel, role_id, kind, "new", detail=("project section seeded from " + str(project_from / role_id / PROJECT_SEED_NAMES[kind])) if seed else "",
                                  content=frame(fm, body, seed, role_id, kind, pkg.version), template_sha256=tpl_hash, base_sha256=base_hash))
            continue

        try:
            managed = parse_managed(existing)
        except ValueError as e:
            out.append(FileAction(rel, role_id, kind, "error", detail=str(e)))
            continue

        if managed is not None:
            same = normalize(managed.base) == normalize(body) and normalize(managed.frontmatter) == normalize(fm) and managed.version == pkg.version
            if same:
                out.append(FileAction(rel, role_id, kind, "unchanged", content=frame(fm, body, managed.project, role_id, kind, pkg.version), template_sha256=tpl_hash, base_sha256=base_hash))
                continue
            migration = pkg.migration_for(managed.version)
            if migration == "base-to-project":
                note = f"<!-- org-core: moved here from base {managed.version} on {_today()} — this org's own text, kept verbatim -->\n"
                project = note + managed.base + ("\n" if managed.base and managed.project else "") + managed.project
                out.append(FileAction(rel, role_id, kind, "upgrade", detail=f"base {managed.version} -> {pkg.version}: previous base moved into the project section (migration base-to-project)",
                                      content=frame(fm, body, project, role_id, kind, pkg.version), template_sha256=tpl_hash, base_sha256=base_hash))
                continue
            rec = locked.get(rel, {})
            pristine = bool(rec) and (rec.get("base_sha256") == sha256(normalize(managed.base)) or rec.get("rendered_sha256") == sha256(existing))
            if pristine:
                detail = f"base {managed.version} -> {pkg.version}, project section kept" + _frontmatter_note(managed.frontmatter, fm)
                out.append(FileAction(rel, role_id, kind, "upgrade", detail=detail,
                                      diff=unified(normalize(managed.base), normalize(body), "installed base", "package base"),
                                      content=frame(fm, body, managed.project, role_id, kind, pkg.version), template_sha256=tpl_hash, base_sha256=base_hash))
            else:
                out.append(FileAction(rel, role_id, kind, "changed", detail=f"installed base {managed.version} was edited after apply (not in the lock as rendered); apply refuses without --overwrite-changed — move the edit into the project section first",
                                      diff=unified(normalize(managed.base), normalize(body), "installed base", "package base"),
                                      content=frame(fm, body, managed.project, role_id, kind, pkg.version), template_sha256=tpl_hash, base_sha256=base_hash))
            continue

        # an unmanaged file with this name
        if adopt_existing:
            _, old_body = split_frontmatter(existing)
            note = f"<!-- org-core: adopted from the pre-existing file on {_today()} — this org's own text, kept verbatim -->\n"
            out.append(FileAction(rel, role_id, kind, "adopt", detail="pre-existing file kept verbatim as the project section beneath the package base",
                                  content=frame(fm, body, note + old_body.lstrip("\n"), role_id, kind, pkg.version), template_sha256=tpl_hash, base_sha256=base_hash))
            continue
        full = frame(fm, body, "", role_id, kind, pkg.version)
        if normalize(strip_markers(full)) == normalize(existing):
            out.append(FileAction(rel, role_id, kind, "markers-only", content=full, template_sha256=tpl_hash, base_sha256=base_hash))
        else:
            out.append(FileAction(rel, role_id, kind, "changed", detail="an unmanaged file with this name differs from the package; re-run with --adopt-existing to keep it as the project section, or --overwrite-changed to replace it",
                                  diff=unified(normalize(existing), normalize(strip_markers(full))), content=full, template_sha256=tpl_hash, base_sha256=base_hash))
    return out


def _fm_lines(fm: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in fm.splitlines():
        if line.startswith("---") or not line.strip() or line[:1].isspace():
            continue
        k, _, v = line.partition(":")
        out[k.strip()] = v.strip()
    return out


def _frontmatter_note(installed_fm: str, rendered_fm: str) -> str:
    """Name the frontmatter lines this upgrade rewrites. The frontmatter is generated with the base, but nothing said so when
    NumeroTech's adopt rewrote eight `tools:` lines and silently dropped every tool an org had added by hand (2026-09-17,
    SPEC row 80): a pristine base upgrades, and the org sees here exactly what its frontmatter loses."""
    old, new = _fm_lines(installed_fm), _fm_lines(rendered_fm)
    changed = [k for k in old if old[k] != new.get(k, "")]
    if not changed:
        return ""
    shown = ", ".join(f"{k}: {old[k][:70]!r} -> {new.get(k, '')[:70]!r}" for k in changed[:4])
    return f"; frontmatter rewritten ({shown}) — the frontmatter is generated with the base; a capability lives in org.yaml, never here"


def _org_files(repo: Path, manifest: dict[str, Any], ctx_base: dict[str, Any], lock: dict[str, Any] | None, adopt_existing: bool) -> list[FileAction]:
    """The org-level managed file, `docs/ai/lessons.md` (SPEC §11, 0.14.0): the base is the format, versioned by org-core itself;
    the project section is the org's rows, which org-core never rewrites except for the `status` column of a row the curator has
    answered (`org_core/lessons_status.json`)."""
    from . import lessons as ls
    from .render import sha256

    rel = ls.LESSONS_REL
    target = repo / rel
    core_src = (TEMPLATES / "lessons.core.md").read_text()
    try:
        body = "\n" + render_base(core_src, dict(ctx_base))
    except UndeclaredVariable as e:
        return [FileAction(rel, "org", "lessons", "undeclared", detail=f"template needs a value the manifest does not declare: {e}")]
    from . import __version__

    tpl_hash, base_hash, version = sha256(core_src), sha256(normalize(body)), __version__
    existing = target.read_text() if target.exists() else None
    if existing is None:
        return [FileAction(rel, "org", "lessons", "new", detail="the org's lessons file: the format in the base, its rows in the project section",
                           content=frame("", body, ls.TABLE_HEADER, "org", "lessons", version), template_sha256=tpl_hash, base_sha256=base_hash)]
    try:
        managed = parse_managed(existing)
    except ValueError as e:
        return [FileAction(rel, "org", "lessons", "error", detail=str(e))]
    if managed is None:
        note = f"<!-- org-core: adopted from the pre-existing file on {_today()} — this org's own text, kept verbatim -->\n"
        content = frame("", body, ls.TABLE_HEADER + "\n" + note + existing.lstrip("\n"), "org", "lessons", version)
        if adopt_existing:
            return [FileAction(rel, "org", "lessons", "adopt", detail="pre-existing file kept verbatim beneath the table", content=content, template_sha256=tpl_hash, base_sha256=base_hash)]
        return [FileAction(rel, "org", "lessons", "changed", detail="an unmanaged docs/ai/lessons.md exists; re-run with --adopt-existing to keep it beneath the table",
                           diff=unified(normalize(existing), normalize(strip_markers(content))), content=content, template_sha256=tpl_hash, base_sha256=base_hash)]
    project, answered = ls.apply_statuses(managed.project, ls.load_statuses())
    same_base = normalize(managed.base) == normalize(body) and managed.version == version
    if same_base and not answered:
        return [FileAction(rel, "org", "lessons", "unchanged", content=frame("", body, managed.project, "org", "lessons", version), template_sha256=tpl_hash, base_sha256=base_hash)]
    rec = (lock or {}).get("files", {}).get(rel, {})
    pristine = same_base or (bool(rec) and (rec.get("base_sha256") == sha256(normalize(managed.base)) or rec.get("rendered_sha256") == sha256(existing)))
    detail = (f"base {managed.version} -> {version}" if not same_base else "base unchanged") + (f"; status answered for {len(answered)} row(s): " + ", ".join(answered[:6]) + (" …" if len(answered) > 6 else "") if answered else "")
    content = frame("", body, project, "org", "lessons", version)
    if pristine:
        return [FileAction(rel, "org", "lessons", "upgrade", detail=detail, diff=unified(normalize(managed.base), normalize(body), "installed base", "package base"),
                           content=content, template_sha256=tpl_hash, base_sha256=base_hash)]
    return [FileAction(rel, "org", "lessons", "changed", detail=f"installed base {managed.version} was edited after apply; apply refuses without --overwrite-changed — the base is the format, the rows are yours",
                       diff=unified(normalize(managed.base), normalize(body), "installed base", "package base"), content=content, template_sha256=tpl_hash, base_sha256=base_hash)]


def _suite_files(repo: Path, manifest: dict[str, Any], lock: dict[str, Any] | None) -> list[FileAction]:
    """The suite install (SPEC §18, 0.16.0): the generated setup script — whole-file managed, no project section, its head
    marker a comment on line 2 — and the two org-owned files it is wired into, merged by entry and never rewritten."""
    from . import settings as st
    from . import suite as su
    from .render import sha256

    suite = su.suite_of(manifest)
    if suite.problems:
        return [FileAction("org.yaml#suite", "org", "setup", "error", detail="; ".join(suite.problems))]
    out: list[FileAction] = []
    rel = su.SETUP_REL
    target = repo / rel
    try:
        rendered, tpl_hash = su.render_setup(manifest, suite)
    except UndeclaredVariable as e:
        return [FileAction(rel, "org", "setup", "undeclared", detail=f"template needs a value the manifest does not declare: {e}")]
    existing = target.read_text() if target.exists() else None
    if existing is None:
        out.append(FileAction(rel, "org", "setup", "new", detail="the suite install: " + ", ".join(f"{n} ({c['policy']})" for n, c in suite.enabled().items()),
                              content=rendered, template_sha256=tpl_hash))
    elif normalize(existing) == normalize(rendered):
        out.append(FileAction(rel, "org", "setup", "unchanged", content=rendered, template_sha256=tpl_hash))
    else:
        head = su.head_version(existing)
        rec = (lock or {}).get("files", {}).get(rel, {})
        pristine = bool(rec) and rec.get("rendered_sha256") == sha256(existing)
        diff = unified(normalize(existing), normalize(rendered), "installed", "rendered")
        if head is None:
            out.append(FileAction(rel, "org", "setup", "changed", detail=f"an unmanaged file with this name exists; the suite's script is generated from org.yaml — move what it does into the org's own scripts or `suite:`, then re-run with --overwrite-changed",
                                  diff=diff, content=rendered, template_sha256=tpl_hash))
        elif pristine:
            out.append(FileAction(rel, "org", "setup", "upgrade", detail=f"setup {head} -> {su.__version__} (or the manifest's ports/suite changed); the script is whole-file generated", diff=diff, content=rendered, template_sha256=tpl_hash))
        else:
            out.append(FileAction(rel, "org", "setup", "changed", detail=f"the generated setup script ({head}) was edited after apply; edits belong in org.yaml `suite:` or the org's own scripts, never here — apply refuses without --overwrite-changed",
                                  diff=diff, content=rendered, template_sha256=tpl_hash))
    for rel2, kind in ((st.SETTINGS_REL, "settings"), (st.MCP_REL, "mcp")):
        status, detail, content = st.plan_file(repo, rel2, suite)
        out.append(FileAction(rel2, "org", kind, status, detail=detail, content=content,
                              diff=unified((repo / rel2).read_text(), content, "existing", "merged") if status == "merge" and content else ""))
    return out


def _note_ignored(repo: Path, plan: Plan) -> None:
    """A managed path git would ignore is written by apply and carried by nobody (row 93): the plan says so on the line,
    whatever the status — an `unchanged` file in that hole is the exact shape Lucille had."""
    from . import gitfiles as gf
    if not gf.is_git_repo(repo):
        return
    for a in plan.actions:
        if a.content is None or gf.tracked(repo, a.path):
            continue
        ig = gf.ignored(repo, a.path)
        if ig is not None:
            a.detail = (a.detail + " — " if a.detail else "") + f"IGNORED by {ig}: untracked; apply whitelists it, then commit"


def make_plan(repo: Path, manifest: dict[str, Any], packages: dict[str, RolePackage], manifest_source: Path | None = None,
              adopt_existing: bool = False, project_from: Path | None = None) -> Plan:
    from .lock import read as read_lock

    plan = Plan()
    ctx_base = flat_vars(manifest)
    lock = read_lock(repo)
    for role_id in enabled_roles(manifest):
        pkg = packages.get(role_id)
        if pkg is None:
            plan.actions.append(FileAction(f"<{role_id}>", role_id, "-", "error", detail="no role package for an enabled role"))
            continue
        plan.actions.extend(_role_files(repo, manifest, role_id, pkg, ctx_base, lock, adopt_existing, project_from))
    plan.actions.extend(_org_files(repo, manifest, ctx_base, lock, adopt_existing))
    plan.actions.extend(_suite_files(repo, manifest, lock))
    _note_ignored(repo, plan)
    # the manifest itself
    target = repo / "org.yaml"
    if manifest_source is not None and manifest_source.resolve() != target.resolve():
        src_text = manifest_source.read_text()
        if not target.exists():
            plan.actions.append(FileAction("org.yaml", "-", "manifest", "new", content=src_text))
        elif yaml.safe_load(target.read_text()) == yaml.safe_load(src_text):
            plan.actions.append(FileAction("org.yaml", "-", "manifest", "unchanged", content=src_text))
        else:
            plan.actions.append(FileAction("org.yaml", "-", "manifest", "changed", diff=unified(target.read_text(), src_text), content=src_text))
    return plan
