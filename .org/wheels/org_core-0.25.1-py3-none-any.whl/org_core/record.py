"""Run records (SPEC.md §9, Appendix B): validation against the common schema plus a role's own counts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import jsonschema

SCHEMA_PATH = Path(__file__).parent / "schemas" / "run-record.schema.json"


def load_schema() -> dict[str, Any]:
    return json.loads(SCHEMA_PATH.read_text())


def validate(record: Any, counts_schema: dict[str, Any] | None = None) -> list[str]:
    problems: list[str] = []
    v = jsonschema.Draft202012Validator(load_schema(), format_checker=jsonschema.FormatChecker())
    for err in sorted(v.iter_errors(record), key=lambda e: list(e.absolute_path)):
        where = "/".join(str(p) for p in err.absolute_path) or "<root>"
        problems.append(f"{where}: {err.message}")
    if counts_schema and isinstance(record, dict) and "counts" in record:
        cv = jsonschema.Draft202012Validator(counts_schema)
        for err in cv.iter_errors(record["counts"]):
            where = "counts/" + "/".join(str(p) for p in err.absolute_path)
            problems.append(f"{where}: {err.message}")
    if isinstance(record, dict) and record.get("outcome") == "blocked" and not record.get("blocked"):
        problems.append("outcome is blocked but `blocked` is empty — say what stopped you")
    return problems


def from_doctor(report: dict[str, Any], *, org: str, name: str, runtime: str, session_id: str | None = None,
                manifest_version: int | None = None, role_version: str | None = None, git_sha: str | None = None,
                pr: int | str | None = None, next_due: str | None = None, started_at: str | None = None,
                suite: dict[str, Any] | None = None) -> dict[str, Any]:
    """The doctor's run record (SPEC Appendix B) from `org doctor --json` output. Valid by construction, or validate() says why not."""
    s = report["summary"]
    at = report["at"]
    dead = s.get("dead_roles", [])
    blocked = None
    if s["bad"]:
        blocked = f"{s['bad']} bad check(s); dead: {', '.join(dead) or 'none'}"
    ran_all = s["ran"] == s["checks_total"]
    headline = f"ran {s['ran']} of {s['checks_total']} checks; {s['bad']} bad; dead: {', '.join(dead) or 'none'}"
    if not ran_all:
        headline += f" — {s['not_implemented']} not implemented, {s['needs_facts']} need facts, {s['unreachable']} unreachable"
    could_not_reach = []
    if s.get("needs_facts"):
        could_not_reach.append("sessions")
    if s.get("unreachable"):
        could_not_reach.append("ports:unreachable")
    return {
        "schema": 1, "org": org, "role": "doctor", "name": name,
        "run_id": f"{at}-doctor-{abs(hash(at)) % 0xFFFF:04x}",
        "started_at": started_at or at, "ended_at": at,
        "runtime": runtime, "session_id": session_id,
        "manifest_version": manifest_version, "role_version": role_version, "git_sha": git_sha,
        "outcome": "blocked" if blocked else "ran",
        "blocked": blocked, "headline": headline,
        "counts": {"checks_total": s["checks_total"], "ran": s["ran"], "bad": s["bad"], "dead": len(dead),
                   "blocked": s.get("blocked", 0), "not_implemented": s["not_implemented"], "needs_facts": s["needs_facts"]},
        "artifacts": {"pr": pr, "board_keys": ["roles/doctor/last-run"], "files": [".org/runs/doctor.jsonl"]},
        "could_not_reach": could_not_reach, "next_due": next_due, "cost_usd": None, "tokens": None,
        "drill": bool(report.get("drill")),
        "suite": dict(suite or {}),   # the org-core and suite versions of the container that ran the doctor (SPEC §18, check 21)
    }
