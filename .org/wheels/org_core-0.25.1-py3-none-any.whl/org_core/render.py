"""Rendering a role file (SPEC.md §3 "Base and project sections", §6).

A managed file is: frontmatter (if any), a head marker, the base section
(rendered from the package template), the project section (never touched by
the tool), an end marker. Stripping the four marker lines from a freshly
rendered file with an empty project section gives back exactly the template's
output — which is what the fidelity test relies on.
"""

from __future__ import annotations

import difflib
import hashlib
import re
from dataclasses import dataclass
from typing import Any

import jinja2

HEAD_RE = re.compile(r"^<!-- org-core: role=(?P<role>[a-z-]+) file=(?P<kind>agent|skill|lessons) base=(?P<version>\S+) -->$")
MARK_BASE = "<!-- org-core:base -->"
MARK_PROJECT = "<!-- org-core:project -->"
MARK_END = "<!-- org-core:end -->"


def head_marker(role: str, kind: str, version: str) -> str:
    return f"<!-- org-core: role={role} file={kind} base={version} -->"


def is_marker(line: str) -> bool:
    s = line.rstrip("\n")
    return s in (MARK_BASE, MARK_PROJECT, MARK_END) or bool(HEAD_RE.match(s))


def split_frontmatter(text: str) -> tuple[str, str]:
    """(frontmatter including both fences and its trailing newline, body). Empty frontmatter if none."""
    if text.startswith("---\n"):
        end = text.find("\n---\n", 4)
        if end != -1:
            cut = end + len("\n---\n")
            return text[:cut], text[cut:]
    return "", text


class UndeclaredVariable(Exception):
    """The template needs a value the manifest does not declare."""


def render_base(template_text: str, ctx: dict[str, Any]) -> str:
    env = jinja2.Environment(
        undefined=jinja2.StrictUndefined,
        keep_trailing_newline=True,
        autoescape=False,
        # `{{ }}` collides with bash `${VAR:-…}` and JSON; `{[ ]}` occurs in neither (measured against every Lucille role file, 2026-09-17)
        variable_start_string="{[",
        variable_end_string="]}",
    )
    try:
        return env.from_string(template_text).render(**ctx)
    except jinja2.UndefinedError as e:
        raise UndeclaredVariable(str(e)) from e
    except jinja2.TemplateSyntaxError as e:
        raise UndeclaredVariable(f"template syntax error at line {e.lineno}: {e.message}") from e


@dataclass
class Managed:
    role: str
    kind: str
    version: str
    frontmatter: str
    base: str
    project: str


def frame(frontmatter: str, base: str, project: str, role: str, kind: str, version: str) -> str:
    if base and not base.endswith("\n"):
        base += "\n"
    if project and not project.endswith("\n"):
        project += "\n"
    return (
        frontmatter
        + head_marker(role, kind, version) + "\n"
        + MARK_BASE + "\n"
        + base
        + MARK_PROJECT + "\n"
        + project
        + MARK_END + "\n"
    )


def parse_managed(text: str) -> Managed | None:
    """The sections of a managed file, or None if the file carries no head marker."""
    fm, body = split_frontmatter(text)
    lines = body.split("\n")
    if not lines:
        return None
    m = HEAD_RE.match(lines[0])
    if not m:
        return None
    if len(lines) < 2 or lines[1] != MARK_BASE:
        raise ValueError("managed file has a head marker but no base marker on the next line")
    try:
        p = lines.index(MARK_PROJECT)
        e = lines.index(MARK_END, p)
    except ValueError as err:
        raise ValueError("managed file is missing its project or end marker") from err
    trailing = "".join(lines[e + 1:]).strip()
    if trailing:
        raise ValueError("managed file has content after its end marker — it belongs in the project section, where the tool will keep it")
    base = "\n".join(lines[2:p])
    project = "\n".join(lines[p + 1:e])
    return Managed(m["role"], m["kind"], m["version"], fm, base + ("\n" if base else ""), project + ("\n" if project else ""))


def strip_markers(text: str) -> str:
    return "".join(line for line in text.splitlines(keepends=True) if not is_marker(line))


def normalize(text: str) -> str:
    """Trailing whitespace per line and trailing newlines are not differences."""
    return "\n".join(line.rstrip() for line in text.splitlines()).strip("\n") + "\n"


def unified(a: str, b: str, a_name: str = "existing", b_name: str = "rendered") -> str:
    return "".join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), a_name, b_name))


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()
