## 1. Pin the workspace before any board call

```bash
export SWITCHBOARD_WORKSPACE={[ workspace ]}
switchboard --json whoami        # confirm: "workspace": "{[ workspace ]}"
```

A report in the wrong room is indistinguishable from no report, and the CLI
reports success either way.

## 2. Read your own last record first

```bash
switchboard --json board get {[ report_key ]}
```

Your trend lines come from here. If there is no record, say so in today's —
"first run, or the last one died" — rather than starting the trend at today.

## 3. Read the registry, read-only

{% if checks_tool == "checks-core" %}This org's checks port is **checks-core** (`{[ checks_registry ]}`, executor `{[ checks_executor ]}`).

```bash
org checks --repo {[ checkout ]} validate                       # a LOST check is a finding, not a skip
org checks --repo {[ checkout ]} plan --json > "$CLAUDE_SCRATCHPAD/checks-plan.json"
```

Run every `due` query **read-only**, one row per check id, into
`$CLAUDE_SCRATCHPAD/rows.json` as `{ "<check-id>": <row> | {"error": "<why>"} }`:

{% if checks_executor == "psql" %}* `org checks --repo {[ checkout ]} run --executor psql --file-issues --dry-run` does plan → execute → record in one step; the DSN comes from `${[ checks_dsn_env ]}` and the session sets `transaction_read_only`.
{% elif checks_executor == "supabase-mcp" %}* the executor is the Supabase MCP: for each due query call the tool whose name ends in `__execute_sql` with `read_only: true`, pin the production ref from `org.yaml` (`ports.prod_read.guard`), and copy the single row back under the check id. `read_only` is a rule you keep, not something the server enforces — a query that is not a `SELECT`/`WITH` is refused by `org checks validate` before you ever see it.
{% else %}* the executor is manual: run each query by whatever read-only path this org declares in `org.yaml` and copy the single row back under the check id.
{% endif %}
Then record and read:

```bash
org checks --repo {[ checkout ]} record --rows "$CLAUDE_SCRATCHPAD/rows.json" --file-issues   # appends {[ checks_results ]}; files a failure once per recheck window, closes what passed or expired
org checks --repo {[ checkout ]} report --json > "$CLAUDE_SCRATCHPAD/checks-report.json"
org checks --repo {[ checkout ]} report
```

A due check with no row is recorded as ERROR ("not executed") — never as a
pass. If the executor is unreachable, stop there and put it in `blocked`.
{% elif checks_read_only_invocation is defined %}The invocation is declared per install and must write nothing:

```
{[ checks_read_only_invocation ]}
```

Do not use any path that files tickets or retires checks. If the declared
invocation is unreachable from where you run (no tunnel, no credential),
**stop and report that** — `blocked` in your record, one line on `ops` — and
do not substitute a partial read for the whole.
{% else %}**This org declares no checks port** (`org.yaml` ports.checks is absent), so there
is no registry to read. Write a record with `blocked: "no checks port declared"`,
stamp the operator file, and stop — and say in the headline that this role
should be `enabled: false` until a registry exists.
{% endif %}
## 4. Compute the reading

For every check: state (`pass`, `fail`, `pending`, `expired`, `inconclusive`,
`error`), severity, `check_after`, `until`, and its diagnostics.

* **Counts by state**, and `high` among the failures.
* **Oldest failure**: id and days red.
* **Failures without an owner**: for each failing check, `grep -l <check-id>
  roadmap/items/*.yaml`; none → unowned.
* **Vacuous passes**: every numeric diagnostic is 0 and the id is not in the
  registry's known-vacuous list. For each, write the one sentence: *if this
  feature were completely broken, this check would show ___.* If the blank is
  "the same", it is a finding.
* **Expiring within 7 days**, and **expired while red** since your last record.
* **Trend**: for each failure present in your last record, is its diagnostic
  better, worse or the same? A worsening failure is its own line.

## 5. Write the record — on every run, including a clean one

```bash
export SUITE="$(org setup --repo {[ checkout ]} status --compact)"     # the org-core and suite versions this container runs (doctor check 21)
switchboard --json board set {[ report_key ]} "$(python3 -c '
import json, datetime, os
print(json.dumps({
  "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "by": "{[ names.checks_watch ]}",
  "suite": json.loads(os.environ.get("SUITE") or "{}"),
  "checked": 0, "pass": 0, "fail": 0, "high": 0, "pending": 0, "expired": 0, "inconclusive": 0, "error": 0,
  "oldest_failure": "<id>, red since <date>, <n> days",
  "failures_without_item": [],
  "vacuous_unflagged": [],
  "expired_while_red": [],
  "worsening": [],
  "blocked": None,
  "method": "<the exact read-only invocation used>",
  "headline": "one sentence a human should act on",
}))')" --ttl 604800
switchboard --json say ops "checks-watch ({[ names.checks_watch ]}): <fail> red (<high> high), <n> unowned, <m> vacuous — <headline>" --ttl 86400
```

`at` is the time you write it. A record whose `at` is ahead of the hub's own
timestamp is a run time that is not the run time, and the doctor flags it.

## 6. Your line in the operator file is rendered, not stamped

`{[ operator_surface ]}` — `### {[ names.checks_watch ]} — checks-watch · {[ cadence_label.checks_watch ]}`,
three lines: **last run**, **outcome**, **blocked** — is the one report the
operator reads without an agent relaying it, and the chair renders every role's
three lines from `roles/<role>/last-run` on `main` each wake. You have no path
to `main`; a stamp from your branch sits behind whatever merges before it, and
the file then said `never ran` for roles that ran daily (rows 65, 98). Write the
record; the file follows.

## 7. What you do not do

No fix, no item, no ticket, no status change. If a reading is worth an item,
say so in the headline; the roles that file and build read this record.
