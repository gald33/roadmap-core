## 1b. Pin the repo you will measure

`{[ checkout ]}` is a shared checkout: any session may move its branch under
you, and a doctor that reads it measures whatever branch it was left on (a
doctor in Lucille found it 31 commits behind `origin/main` with no `org.yaml`
at all, 2026-09-19). Take your own tree at `origin/{[ default_branch ]}` and
measure there:

```bash
cd {[ checkout ]} && git fetch origin {[ default_branch ]} --quiet
BASE=$(git rev-parse origin/{[ default_branch ]})
export REPO="$CLAUDE_SCRATCHPAD/doctor-wt-$(date -u +%Y%m%dT%H%M)"   # exported: the steps below read it; unique, so a stale worktree from an earlier run is never measured
git worktree remove --force "$REPO" 2>/dev/null; git worktree prune
git worktree add "$REPO" "$BASE" --detach     # never `git checkout` in the shared dir
test "$(git -C "$REPO" rev-parse HEAD)" = "$BASE" || echo "the worktree is not at $BASE — report this, do not improvise"
test -f "$REPO/org.yaml" || echo "no manifest at $BASE — report this, do not improvise"
```

Use `"$REPO"` for every `--repo` and `--manifest` below, and for step 5's PR.

## 2. Gather facts, if you can

The trigger and session checks need what only the sessions port can list.
Search your tool list by **suffix** — tools register under hashed names and a
literal-name miss is not proof of absence:

* anything ending in `__list_triggers` → save the result as `triggers`
* anything ending in `__list_sessions` → save the result as `sessions`
* then, for **every `persistent_session_id` the triggers name that is not in
  that listing**, call the tool ending in `__get_session` with that id and
  append its row to `sessions`. A listing returns the newest N, and a session
  a routine has been firing into for days is old by construction — so the org's
  persistent sessions are the ones it drops, and they are its largest numbers
  (NumeroTech 2026-09-21: the dispatcher's bound session at US$5,462 cumulative
  was in no listing this account could take). Without them check 11's total
  excludes the biggest spender and check 4 cannot tell a dead bound session
  from an unlisted one; both say so, by name, rather than printing a figure.

Write them to a facts file in your scratchpad (never a bare `/tmp` name — they
collide across sessions):

```bash
FACTS="$CLAUDE_SCRATCHPAD/doctor-facts.json"   # {"triggers": [...], "sessions": [...]}
```

If neither tool is present, do not improvise: those checks will report
`NEEDS_FACTS`, and step 4 records `sessions` under `could_not_reach`.

## 3. Gather the tempo facts, then run the doctor

Checks 14 and 19 read the org's speed (SPEC §13) from a facts file the doctor does not gather itself:

```bash
org tempo --repo "$REPO" gather --since "$(date -u -d '7 days ago' +%Y-%m-%dT00:00:00Z)" ${FACTS:+--facts "$FACTS"}
```

It writes `$REPO/.org/tempo/facts-<today>.json` (board records, pull requests, run ledgers, and the triggers you saved above). Exit 2 means a source could not be read — the file still exists and says which; report that with the checks, not instead of them. Commit the file in step 5; the history of the org's speed exists only in these files.


```bash
org doctor --repo "$REPO" --manifest "$REPO/org.yaml" ${FACTS:+--facts "$FACTS"} --json > "$CLAUDE_SCRATCHPAD/doctor.json"
org doctor --repo "$REPO" --manifest "$REPO/org.yaml" ${FACTS:+--facts "$FACTS"}
```

Check 7 in served mode runs `diff` only if your session already holds the store
credential the manifest names (`ports.work_store.credential`); otherwise it reads
the org's sync workflow, which is the gate that ran `diff`. Read that credential
if you hold it; never mint one for this check — a doctor that mints is the
standing grant the org's own gate refuses. Check 8 reports a claim; releasing it
is the holder's or the operator's act, never yours.

Exit 1 means something is DEAD or FAIL; exit 2 means a port was unreachable —
report that as a finding about the port, not as a pass. Read the final line:
*ran N of 21 checks*. N is part of your headline whenever it is not 21.

An absent record has three causes and only one is a dead role (Lucille,
2026-09-19): the role writes under a key that is not its manifest name (read the
key its own file declares — the doctor already does, from `report_key`); it
wrote with the MCP client and the record expired in a day (it reappears every
run and is absent between — read its previous runs before calling it dead); or
it genuinely never wrote. The second and third are indistinguishable from the
board — a write after an expiry returns `revision: 1` exactly like a first write
— so name the absence as the fact and say the cause is undetermined; never
promote `revision: 1` into "never written". An absence goes in your headline by
name, not into `could_not_reach`.

## 4. Write the record — every run

The board record, from the same JSON the doctor just wrote, so the two cannot disagree:

```bash
REC="$CLAUDE_SCRATCHPAD/doctor-record.json"
org record-from-doctor "$CLAUDE_SCRATCHPAD/doctor.json" --repo "$REPO" --runtime fresh > "$REC"
org record "$REC"                                   # exit 0 or the record is not written anywhere
switchboard --json board set roles/doctor/last-run "$(python3 -c '
import json, sys, datetime
r = json.load(open(sys.argv[1]))
print(json.dumps({"at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "by": r["name"],
  "checks_total": r["counts"]["checks_total"], "ran": r["counts"]["ran"], "bad": r["counts"]["bad"], "dead": r["counts"]["dead"],
  "blocked": r["blocked"], "could_not_reach": r["could_not_reach"], "suite": r.get("suite") or {}, "headline": r["headline"]}))' "$REC")" --ttl 604800
switchboard --json say ops "doctor ({[ names.doctor ]}): $(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["headline"])' "$REC")" --ttl 86400
```

## 5. Ledger and stamp, in one PR

The durable half. The board record expires in seven days; the ledger line and
the operator file do not.

```bash
cd "$REPO"                                          # the worktree of step 1b, already at the origin/{[ default_branch ]} you measured
git switch -c "claude/doctor-$(date -u +%Y%m%d-%H%M)"
mkdir -p .org/runs && cat "$REC" >> .org/runs/doctor.jsonl && echo >> .org/runs/doctor.jsonl
```

Never `git checkout -B` in `{[ checkout ]}` itself: it moves the branch under
every other session using that directory.

Your section of `{[ operator_surface ]}` — `### {[ names.doctor ]} — doctor · {[ cadence_label.doctor ]}`,
three lines: **last run**, **outcome** (the `ran N of 21` sentence plus the dead
and blocked roles by name), **blocked** — is rendered by the chair from the record
you wrote, on `main`, on its next wake (`org operator render`). Do not edit the
file from this branch: a stamp in a PR sits behind whatever merges before it, and
the file then said `never ran` for roles that ran daily (rows 65, 98). Write the
record; the file follows. This PR carries the ledger line and the facts only.

```bash
git add .org/runs/doctor.jsonl .org/tempo/
git commit -m "doctor $(date -u +%Y-%m-%d): $(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["headline"])' "$REC")"
git push -u origin HEAD
gh api repos/{[ repo ]}/pulls -f title="doctor $(date -u +%Y-%m-%d)" -f head="$(git branch --show-current)" -f base={[ default_branch ]} \
  -f body="$(python3 -c 'import json,sys; r=json.load(open(sys.argv[1])); print(r["headline"] + "\n\nblocked: " + str(r["blocked"]) + "\ncould_not_reach: " + ", ".join(r["could_not_reach"]))' "$REC")"
```

`gh` is REST-only in cloud sessions; `gh pr create` 403s. You never merge the
PR — the CEO does.

## 6. Escalate

A DEAD role and a BLOCKED role each get one sentence in the "Waiting on the
operator" part of the operator file if — and only if — nothing in the org can
act on it: a trigger that needs re-attaching in the web UI, a session that
needs restarting by a human, a credential nobody unattended may mint. Anything
a role can act on stays in your record for the CEO's next wake.

## 7. On a drill

If this run was started by `org verify --drill`, the record carries
`"drill": true` and the headline says which role was killed on purpose. A
drill that the doctor did not notice is a failed verify, not a quiet day.
