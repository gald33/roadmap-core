"""The two files an org owns that the suite has to be wired into (SPEC §6 detection matrix, §18): `.claude/settings.json`
gets the setup hook at the top of its SessionStart list (position orders nothing: all matching hooks run in parallel —
Claude Code docs, read by Reed on NumeroTech #210, 2026-09-20 — so the org's own scripts must not install the same modules;
`org setup check` reports a duplicate) and the suite's MCP servers in `enabledMcpjsonServers`;
`.mcp.json` gets each declared server the org has not defined itself. Never a removal, never a rewrite of an entry
the org wrote, never an `env` key (a committed env key is a standing grant nobody is present for — Lucille #1492/#1537)."""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

from .suite import HOOK_COMMAND, MCP_REL, SETTINGS_REL, SETUP_REL, Suite, mcp_definition


def load(p: Path) -> dict[str, Any] | None:
    """The parsed file, None when absent; raises ValueError when present and not JSON (the plan reports that as an error)."""
    if not p.exists():
        return None
    try:
        data = json.loads(p.read_text())
    except json.JSONDecodeError as e:
        raise ValueError(f"{p.name} is not valid JSON: {e}") from e
    if not isinstance(data, dict):
        raise ValueError(f"{p.name} is not a JSON object")
    return data


def dump(data: dict[str, Any]) -> str:
    return json.dumps(data, indent=2, ensure_ascii=False) + "\n"


def merge_settings(existing: dict[str, Any] | None, suite: Suite) -> tuple[dict[str, Any], list[str]]:
    """(merged, what changed). The hook goes at the top of the list — where a reader looks first; it does not run first,
    SessionStart hooks are parallel, which is why the suite must be the only installer of its modules (row 91)."""
    s = copy.deepcopy(existing) if existing is not None else {}
    changes: list[str] = []
    hooks = s.setdefault("hooks", {})
    groups = hooks.setdefault("SessionStart", [])
    if not isinstance(groups, list):
        raise ValueError("hooks.SessionStart is not a list")
    wired = any(SETUP_REL in str(h.get("command", "")) for g in groups if isinstance(g, dict) for h in (g.get("hooks") or []) if isinstance(h, dict))
    if not wired:
        groups.insert(0, {"matcher": "startup|resume", "hooks": [{"type": "command", "command": HOOK_COMMAND}]})
        changes.append(f"SessionStart: {SETUP_REL} wired (top of the list; hooks run in parallel, position orders nothing)")
    servers = [name for _, name in suite.mcp_servers()]
    if "enabledMcpjsonServers" in s:
        lst = s["enabledMcpjsonServers"]
        if not isinstance(lst, list):
            raise ValueError("enabledMcpjsonServers is not a list")
        for name in servers:
            if name not in lst:
                lst.append(name)
                changes.append(f"enabledMcpjsonServers += {name}")
    elif existing is None and servers:
        s["enabledMcpjsonServers"] = list(servers)
        changes.append("enabledMcpjsonServers = " + ", ".join(servers))
    return s, changes


def merge_mcp(existing: dict[str, Any] | None, suite: Suite) -> tuple[dict[str, Any], list[str]]:
    """(merged, what changed): each declared server added under its name when absent; an org's own definition stands."""
    m = copy.deepcopy(existing) if existing is not None else {}
    changes: list[str] = []
    servers = m.setdefault("mcpServers", {})
    if not isinstance(servers, dict):
        raise ValueError("mcpServers is not an object")
    for module, name in suite.mcp_servers():
        if name in servers:
            continue
        servers[name] = mcp_definition(module, suite.modules[module])
        changes.append(f"mcpServers += {name} ({module})")
    return m, changes


def plan_file(repo: Path, rel: str, suite: Suite) -> tuple[str, str, str | None]:
    """(status, detail, content) for one of the two files: new / unchanged / merge / error."""
    p = repo / rel
    try:
        existing = load(p)
        merged, changes = (merge_settings if rel == SETTINGS_REL else merge_mcp)(existing, suite)
    except ValueError as e:
        return "error", f"{e} — fix the file before apply; the suite never rewrites what it cannot parse", None
    content = dump(merged)
    if existing is None:
        return "new", "; ".join(changes) or "created", content
    if not changes:
        return "unchanged", "", content if p.read_text() == content else p.read_text()
    return "merge", "; ".join(changes) + " — every entry the org wrote is kept", content


__all__ = ["MCP_REL", "SETTINGS_REL", "dump", "load", "merge_mcp", "merge_settings", "plan_file"]
