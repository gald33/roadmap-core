"""Items that read `ready` while a merged commit already did their work (row 22's promise, built at row 111).

Lucille's `scripts/roadmap_status_audit.py` (2026-09-19/21) is the reference, ported: for each item file at a ref,
the commits after the one that created it which touched the item AND files outside the tracker (fewer than
`max_item_files` item files, so a bulk roadmap sweep is not attribution) are the commits that shipped the work
while the status never moved. Measured 2026-09-21 on Lucille's `origin/main`: 9 of the 14 items offered at
`priority: now` had already been worked by a merged commit, and four had each cost a builder run to discover.

A shallow clone cannot tell a boundary commit from a creation commit — git reports every file in a graft as
ADDED — so a history that does not reach the creation is *undetermined*, never clean: the obvious
implementation reassures in exactly that direction (Lucille's `test_a_shallow_history_is_undetermined_not_clean`).
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import yaml

ITEMS_DIR = "roadmap/items/"
TRACKER_ONLY = ("roadmap/", "ARCS.md")
STATUS_LINE = re.compile(r"^status:\s*['\"]?([A-Za-z_-]+)", re.M)

Git = Callable[..., str]


@dataclass(frozen=True)
class Commit:
    sha: str
    date: str
    subject: str
    outside: tuple[str, ...]
    item_files: int


@dataclass(frozen=True)
class History:
    key: str
    creation_visible: bool
    statuses: tuple[str | None, ...]
    later: tuple[Commit, ...] = ()


@dataclass(frozen=True)
class Shipped:
    key: str
    status: str | None
    attributing: tuple[Commit, ...]


def git_runner(repo: Path) -> Git:
    def run(*args: str) -> str:
        p = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, timeout=120)
        if p.returncode != 0:
            raise RuntimeError(f"git {' '.join(args[:3])}: {(p.stderr or p.stdout).strip()[:200]}")
        return p.stdout
    return run


def is_shallow(git: Git) -> bool:
    return git("rev-parse", "--is-shallow-repository").strip() == "true"


def _is_graft(git: Git, sha: str) -> bool:
    """The bottom of a shallow clone: a commit whose parents were cut off, which git diffs against nothing."""
    return len(git("rev-list", "--parents", "-n", "1", sha).split()) == 1


def _outside(paths: list[str]) -> tuple[str, ...]:
    return tuple(p for p in paths if not p.startswith(TRACKER_ONLY))


def read_history(git: Git, key: str, ref: str, *, shallow: bool | None = None, items_dir: str = ITEMS_DIR) -> History:
    """Everything `classify` needs, read out of git, for one item."""
    path = f"{items_dir}{key}.yaml"
    shas = [s for s in git("log", ref, "--format=%H", "--", path).split() if s]
    shas.reverse()
    if not shas:
        return History(key=key, creation_visible=False, statuses=())
    if shallow is None:
        shallow = is_shallow(git)
    added = git("log", ref, "--diff-filter=A", "--format=%H", "--", path).split()
    creation_visible = bool(added) and added[-1] == shas[0] and not (shallow and _is_graft(git, shas[0]))
    statuses: list[str | None] = []
    for sha in shas:
        m = STATUS_LINE.search(git("show", f"{sha}:{path}"))
        statuses.append(m.group(1) if m else None)
    later: list[Commit] = []
    for sha in shas[1:]:
        meta = git("log", "-1", "--format=%cs%x00%s", sha).rstrip("\n").split("\x00")
        touched = [p for p in git("show", "--pretty=", "--name-only", sha).splitlines() if p]
        later.append(Commit(sha=sha, date=meta[0], subject=meta[1].strip() if len(meta) > 1 else "",
                            outside=_outside(touched), item_files=sum(1 for p in touched if p.startswith(items_dir))))
    return History(key=key, creation_visible=creation_visible, statuses=tuple(statuses), later=tuple(later))


def classify(h: History, *, max_item_files: int = 4) -> Shipped | None | str:
    """A `Shipped`, None (nothing to say), or the sentence saying why it cannot tell. Pure, so the rule is testable
    against constructed histories."""
    if not h.creation_visible:
        return f"the history does not reach the commit that added {ITEMS_DIR}{h.key}.yaml (deepen the clone: `git fetch --unshallow`)"
    if len({s for s in h.statuses if s}) > 1:
        return None   # somebody moved it: not this population
    attributing = tuple(c for c in h.later if c.outside and c.item_files <= max_item_files)
    if not attributing:
        return None
    return Shipped(key=h.key, status=h.statuses[-1] if h.statuses else None, attributing=attributing)


def ready_keys(items: Path, statuses: tuple[str, ...] = ("ready",)) -> list[str]:
    """Item keys whose file in the working tree reads one of `statuses`."""
    out = []
    for p in sorted(items.glob("*.yaml")):
        try:
            doc = yaml.safe_load(p.read_text()) or {}
        except (OSError, yaml.YAMLError):
            continue
        if isinstance(doc, dict) and str(doc.get("status") or "") in statuses:
            out.append(str(doc.get("id") or p.stem))
    return out


def ready_keys_at(git: Git, ref: str, statuses: tuple[str, ...] = ("ready",), items_dir: str = ITEMS_DIR) -> list[str]:
    """Item keys whose file AT `ref` reads one of `statuses` — the population the dispatcher offers is what the default
    branch says, not what this checkout's branch says (a status moved on a side branch is still offered from main)."""
    names = [n for n in git("ls-tree", "--name-only", ref, "--", items_dir.rstrip("/") + "/").splitlines() if n.endswith(".yaml")]
    out = []
    for name in sorted(names):
        m = STATUS_LINE.search(git("show", f"{ref}:{name}"))
        if m and m.group(1) in statuses:
            out.append(Path(name).stem)
    return out


def audit(git: Git, ref: str, keys: list[str], *, max_item_files: int = 4) -> tuple[list[Shipped], list[str], int]:
    """(shipped, undetermined keys, examined). Raises RuntimeError when the ref does not resolve — nothing was
    checked, which is not an all-clear."""
    git("rev-parse", "--verify", f"{ref}^{{commit}}")
    shallow = is_shallow(git)
    shipped: list[Shipped] = []
    undetermined: list[str] = []
    for key in keys:
        verdict = classify(read_history(git, key, ref, shallow=shallow), max_item_files=max_item_files)
        if isinstance(verdict, str):
            undetermined.append(key)
        elif verdict is not None:
            shipped.append(verdict)
    return shipped, undetermined, len(keys)
