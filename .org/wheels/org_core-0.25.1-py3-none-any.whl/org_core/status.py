"""`org status` — what is stopped right now, read at call time (SPEC §13; Appendix A rows 61, 62, 65, 81).

**Live is one clock read over the sources as they stand. It is not fresh history.** Three of the four
sources keep history and one does not:

| tier | what it holds | history? |
|---|---|---|
| `git` | `.org/runs/<role>.jsonl`, committed | yes |
| `github` | pull requests, their comments, their merges | yes — GitHub keeps it |
| `board` | `roles/*`, `coord/*` | **no** — one record per key, overwritten every wake (row 62) |
| `sessions` | triggers, sessions | not reachable from a terminal at all |

So a `github` edge prints a median with its `n`, and a `board` edge prints the worst thing waiting now
and says why it has no median to print. A number with no history behind it must never appear in the same
grammar as one that has it: that is what let a 0.87 h median read as health on the morning eight
verdicted pull requests stood, the oldest at 36.8 h (row 61). `org status --store` widens the board tier
by replaying snapshots the store kept; the tier line then says so.

Pure — `status(facts, now)` is a function of the facts and the clock and reaches nothing. The gathering is
`tempo.gather` (live) or `store.facts_since` (replayed); both hand it the same shape.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from . import tempo as tp

#: what a tier can and cannot answer — printed on every tile, because it is the tile's epistemic weight
GIT, GITHUB, BOARD, SESSIONS = "git", "github", "board", "sessions"
TIERS = {
    GIT: "committed — history survives",
    GITHUB: "GitHub's own history — medians are real",
    BOARD: "present only — one record per key, overwritten each wake (row 62)",
    SESSIONS: "needs a session holding the sessions port — unreachable from a terminal",
}

#: which source each edge's two timestamps come from (`tempo.item_flow`). A board-ended edge has a median
#: only as far as the records still on the board reach, which after one wake is nothing.
EDGE_TIER = {"finding_to_dispatch": BOARD, "dispatch_to_pr": BOARD, "merge_to_verified": BOARD,
             "open_to_verdict": GITHUB, "verdict_to_merge": GITHUB, "unsound_open": GITHUB}
EDGE_OWNER = {"finding_to_dispatch": "dispatcher", "dispatch_to_pr": "builder", "open_to_verdict": "reviewer",
              "verdict_to_merge": "ceo", "merge_to_verified": "verifier", "unsound_open": "builder"}
#: edges whose median is unbuildable in the tool as it ships — named, never printed as a blank that reads as fast
NO_MEDIAN = {"unsound_open": "n is 0 by construction (tempo.py:711) — the SLOW half is unreachable; WAITING is real"}

RED, CLEAR, DARK = "RED", "CLEAR", "DARK"
#: how a finding opens, in headline priority order — one list, so the headline and the page agree on what
#: counts as a finding, and the question the command asks ("what is stopped RIGHT NOW") decides which wins.
#: A thing stuck now outranks a median: `SLOW` is last because a slow median is a trend, not a blockage.
FINDING = ("DEAD", "WAITING", "NOT RECEIVED", "BLOCKED", "QUEUE", "CEO record ABSENT", "SKEWED",
           "UNFORWARDED", "FIRED-NO-RECEIVER", "SUPPRESSED", "NOT LISTENING", "NEVER REGISTERED",
           "ABSENT", "SLOW")
DEFAULT_TOLERANCE = 1.5


def _tile(tid: str, title: str, tier: str, state: str, lines: list[str], broken: str) -> dict[str, Any]:
    """A tile is its lines plus the sentence that says what broken looks like. A tile with no reachable
    red state is a defect (CLAUDE.md rule 2), so `broken` is required and never empty."""
    assert broken, f"tile {tid} has no broken-state line"
    return {"id": tid, "title": title, "tier": tier, "state": state, "lines": lines, "broken_looks_like": broken}


def _period(meta: dict[str, Any], now: dt.datetime) -> float | None:
    if meta.get("period_hours"):
        return float(meta["period_hours"])
    return tp.cron_period_hours(str(meta.get("cadence") or ""), now)


def roles_overdue(facts: dict[str, Any], rep: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    """Every enabled role against its own clock. A role with no cadence is aged by nothing, so its absence is
    a presence finding and not a DEAD line — row 81, where the CEO's missing record printed inside a PASS."""
    by_role = {b["role"]: b for b in rep.get("blocked") or []}
    out = []
    for role, meta in sorted((facts.get("roles") or {}).items()):
        b = by_role.get(role) or {}
        period = _period(meta, now)
        tol = float(meta.get("tolerance") or DEFAULT_TOLERANCE)
        age = b.get("record_age_hours")
        row = {"role": role, "cadence": meta.get("cadence"), "period_hours": period, "tolerance": tol,
               "record_at": b.get("record_at"), "age_hours": age, "state": "ok", "why": ""}
        if b.get("record_at") is None:
            row["state"] = "dead" if period else "absent"
            cad = str(meta.get("cadence") or "none")
            row["why"] = (f"no record at {meta.get('report_key') or f'roles/{role}/last-run'} — never ran, or ran and could not report"
                          if period else
                          f"no record, and cadence `{cad}` is not a clock — nothing ages it, so this is presence only (row 81)")
        elif period is not None and age is not None and age > period * tol:
            row["state"] = "dead"
            row["why"] = f"last record {b['record_at']} is {age}h old; expected within {round(period * tol, 2)}h ({meta.get('cadence')} x {tol})"
        out.append(row)
    return out


def status(facts: dict[str, Any], now: dt.datetime | None = None, *, tiers: dict[str, str] | None = None) -> dict[str, Any]:
    """The live reading, as tiles. One clock read; every tile carries its tier and its broken-state line."""
    now = now or dt.datetime.now(dt.timezone.utc)
    rep = tp.report(facts, now)
    tier_notes = dict(TIERS)
    tier_notes.update(tiers or {})
    unread = list(rep.get("could_not_read") or [])
    board_unread = any(c.startswith("board:") for c in unread)
    prs_unread = any(c.startswith("prs:") for c in unread)
    facts_age = tp.hours(facts.get("gathered_at"), now.isoformat()) if facts.get("gathered_at") else None

    tiles: list[dict[str, Any]] = []
    # the roster is a separate read from the board: a store replay has the board and not the roster, so
    # folding them into one reason darkened every board tile over a missing `switchboard agents` call.
    board_why = next((c for c in unread if c.startswith("board:")), "")
    agents_why = next((c for c in unread if c.startswith("agents:")), "")
    prs_why = next((c for c in unread if c.startswith("prs:")), "")

    def state_of(red: bool, unread: bool) -> str:
        """RED outranks DARK, always. A finding the reading DID make must never be downgraded because some
        other source was unreachable — that is how a real queue hides behind partial coverage. The doctor
        orders its statuses the same way (doctor.py: DEAD/FAIL above UNREACHABLE/NEEDS_FACTS)."""
        return RED if red else (DARK if unread else CLEAR)

    def unjudged(why: str) -> str:
        """A source that could not be read produces no findings — only the sentence saying so. An absent record
        means 'nobody looked' here, and printing it as DEAD is row 65's lie in a new costume."""
        return "not judged — " + (why[:96] + "…" if len(why) > 96 else why)

    # --- the chain ---------------------------------------------------------
    lines, skew = [], []
    for name, e in rep["edges"].items():
        tier = EDGE_TIER.get(name, BOARD)
        why = board_why if tier == BOARD else prs_why
        t = rep["targets"].get(name)
        head = f"{name:<20} [{tier:<7}] owner {EDGE_OWNER.get(name, '?'):<11} "
        if why:
            lines.append(head + unjudged(why))
            continue
        if e.get("median_hours") is not None and e["median_hours"] < 0:
            # a duration cannot be negative: the two ends are out of order (a record overwritten by a later
            # wake, or two clocks). It is a finding about the reading, never a number to print beside real ones.
            skew.append(f"SKEWED {name}: median {e['median_hours']}h — a duration cannot be negative; "
                        f"the two ends are out of order over n {e['n']}")
            lines.append(head + f"median — (negative over n {e['n']}: timestamps out of order)")
            continue
        med = (f"median {e['median_hours']}h over n {e['n']}" if e["median_hours"] is not None
               else (f"no median — {NO_MEDIAN[name]}" if name in NO_MEDIAN
                     else f"no median over n {e['n']}" + (" — the board kept no earlier record (row 62)" if tier == BOARD else "")))
        worst = f"  worst {e['worst_waiting_item']} {e['worst_waiting_hours']}h" if e["worst_waiting_item"] else ""
        lines.append(head + f"{med}; waiting {e['waiting']}{worst}" + (f"  (target {t}h)" if t is not None else ""))
    red = (list(rep.get("slow") or []) if not (board_why and prs_why) else []) + skew
    tiles.append(_tile("chain", "the chain — finding to verified", "mixed",
                       state_of(bool(red), bool(board_why or prs_why)), lines + red,
                       "SLOW <edge>: median <h> over n <n> (target <h>) / WAITING <edge>: <item> for <h>h (target <h>)"))

    # --- the chair ---------------------------------------------------------
    c = rep["cycle"]
    ve = rep["edges"].get("verdict_to_merge") or {}
    ceo = next((b for b in rep.get("blocked") or [] if b["role"] == "ceo"), None)
    if prs_why:
        chair, chair_red = [unjudged(prs_why)], False
    else:
        chair = [f"open SOUND pull requests {ve.get('waiting', 0)}"
                 + (f", worst {ve['worst_waiting_item']} {ve['worst_waiting_hours']}h" if ve.get("worst_waiting_item") else ""),
                 (f"last merge {c['last_merge_at']} — {c['hours_since_last_merge']}h ago" if c.get("last_merge_at")
                  else f"no merge in the window since {facts.get('since')}")]
        ceo_absent = ceo is not None and ceo.get("record_at") is None and not board_why
        chair.append(unjudged(board_why) + " (CEO record)" if board_why else
                     ("CEO record ABSENT — the chair has never written, or its record expired" if ceo_absent else
                      (f"CEO record {ceo['record_at']} ({ceo.get('record_age_hours')}h old)" if ceo else "no ceo role declared")))
        tgt = rep["targets"].get("verdict_to_merge")
        chair_red = bool(ceo_absent or (ve.get("worst_waiting_hours") is not None and tgt is not None and ve["worst_waiting_hours"] > tgt))
    tiles.append(_tile("chair", "the chair — is anything merging", GITHUB,
                       state_of(bool(chair_red), bool(prs_why or board_why)), chair,
                       "QUEUE <n> SOUND PR(s) open, <m> past <h>h (#<n> <h>h); last merge <h>h ago; CEO record ABSENT"))

    # --- roles against their own clocks ------------------------------------
    overdue = [] if board_why else roles_overdue(facts, rep, now)
    bad = [r for r in overdue if r["state"] != "ok"]
    tiles.append(_tile("roles", "roles against their own clocks", BOARD, DARK if board_why else (RED if bad else CLEAR),
                       [unjudged(board_why)] if board_why else
                       ([f"{r['state'].upper()} {r['role']}: {r['why']}" for r in bad]
                        or [f"{len(overdue)} enabled role(s), every record within cadence x tolerance"]),
                       "DEAD <role>: last record <at> is <h>h old; expected within <h>h / ABSENT <role>: no record, and no cadence to age it by"))

    # --- blocked, and blocked nobody forwarded -----------------------------
    blocked = [b for b in rep.get("blocked") or [] if b.get("blocked")]
    unforwarded = (rep.get("actuator") or {}).get("orphans", {}).get("unforwarded") or []
    bl = [f"BLOCKED {b['role']}: {b['blocked']}" for b in blocked] + [
        f"UNFORWARDED blocked {u.get('role')} {u.get('age_hours')}h — {str(u.get('text') or '')[:120]}"
        if isinstance(u, dict) else f"UNFORWARDED {u}" for u in unforwarded]
    tiles.append(_tile("blocked", "blocked now, and what never reached the queue", BOARD,
                       DARK if board_why else (RED if bl else CLEAR),
                       [unjudged(board_why)] if board_why else (bl or ["no role's record carries a blocker"]),
                       "BLOCKED <role>: <text> / UNFORWARDED blocked <role> <h>h"))

    # --- handoffs written and never received -------------------------------
    hu = rep.get("handoffs_unreceived") or []
    tiles.append(_tile("handoffs", "handoffs written and never received", BOARD,
                       DARK if board_why else (RED if hu else CLEAR),
                       [unjudged(board_why)] if board_why else
                       ([f"NOT RECEIVED {e['from']} -> {e['to']} [{e['item']}] written {e['written_at']} — waiting {e['waiting_hours']}h" for e in hu]
                        or [f"{len(rep.get('handoffs') or [])} handoff key(s) on the board, all acked"]),
                       "NOT RECEIVED <from> -> <to> [<item>] written <at> — waiting <h>h"))

    # --- the actuator, and fires nobody answered ---------------------------
    a = rep.get("actuator") or {}
    hb = a.get("heartbeat")
    orph = a.get("orphans") or {}
    fnr, sup = orph.get("fired_no_receiver") or [], orph.get("suppressed") or []
    if board_why:
        act, act_state = [unjudged(board_why)], DARK
    else:
        if hb:
            act = [f"heartbeat {hb.get('at')} ({a.get('heartbeat_age_hours')}h ago), next wake {hb.get('next_wake_at')}, "
                   f"{hb.get('context_tokens')} tokens, session {hb.get('session_id')}",
                   f"wakes {a.get('wakes')} ({a.get('wakes_idle')} idle), spawns {a.get('spawns')}, fires {a.get('fires')}, refused {a.get('refused')}"]
        else:
            act = ["DEAD actuator: no heartbeat at coord/tempo/actuator"
                   + (f"; {a.get('wakes')} ledger row(s) exist — the chain died or the session ended" if a.get("wakes")
                      else " and no ledger row ever — the four-call wake is not running")]
        act += [f"FIRED-NO-RECEIVER {f}" for f in fnr] + [f"SUPPRESSED {s}" for s in sup]
        act_state = RED if (not hb or fnr or sup) else CLEAR
    tiles.append(_tile("actuator", "the wake chain that moves everything else", BOARD, act_state, act,
                       "DEAD actuator: no heartbeat / FIRED-NO-RECEIVER <role> <run_id> <h>h / SUPPRESSED <role>"))

    # --- listeners ---------------------------------------------------------
    ls = rep.get("listeners") or []
    roster_dark = board_why or any(not l.get("roster_read") for l in ls)
    lapsed = [l for l in ls if not l["listening"] and l.get("roster_read") and l.get("agent_id")]
    never = [l for l in ls if not l.get("agent_id")]
    tiles.append(_tile("listeners", "persistent roles: registered, and on the roster now", BOARD,
                       DARK if roster_dark else (RED if (lapsed or never) else CLEAR),
                       [unjudged(board_why or agents_why or "the roster was not read — `switchboard agents` returned nothing")] if roster_dark else
                       ([f"NOT LISTENING {l['role']}: registered {l['registered_age_hours']}h ago, not on the roster — its listener lapsed" for l in lapsed]
                        + [f"NEVER REGISTERED {l['role']}: no `org tempo register` from its session yet" for l in never]
                        or [f"{len(ls)} persistent role(s), all on the roster"]),
                       "NOT LISTENING <role> — its listener lapsed / NEVER REGISTERED <role>"))

    # --- what this reading could not see -----------------------------------
    dark = [t["id"] for t in tiles if t["state"] == DARK]
    reds = [t for t in tiles if t["state"] == RED]
    cover = {"tiles": len(tiles), "measured": len(tiles) - len(dark), "dark": dark,
             "facts_gathered_at": facts.get("gathered_at"), "facts_age_hours": facts_age,
             "sessions_tier": "not read — triggers and sessions need a session holding the sessions port",
             "could_not_read": unread}
    if unread and len(dark) == len(tiles):
        headline = "NOT MEASURED — could not read: " + "; ".join(unread)
    elif reds:
        first = next((l for kind in FINDING for t in reds for l in t["lines"] if l.startswith(kind)),
                     reds[0]["title"])
        headline = f"{first}  [{len(reds)} of {len(tiles)} tiles red, {len(dark)} dark]"
    else:
        headline = (f"no tile past target; {cover['measured']} of {cover['tiles']} tiles measured"
                    + (f", {len(dark)} dark ({', '.join(dark)})" if dark else "")
                    + (f"; facts {facts_age}h old" if facts_age is not None else ""))
    return {"kind": "org-status", "org": facts.get("org"), "at": now.isoformat(timespec="seconds"),
            "headline": headline, "tiles": tiles, "coverage": cover, "tiers": tier_notes,
            "could_not_read": unread, "report": rep}


def exit_code(st: dict[str, Any]) -> int:
    """0 every tile measured and clear; 2 a tile is red; 3 nothing red but coverage is partial; 1 nothing readable.
    Each code is reachable: 3 is today's normal reading from a terminal, which cannot see the sessions tier."""
    states = [t["state"] for t in st["tiles"]]
    if all(s == DARK for s in states):
        return 1
    if RED in states:
        return 2
    return 3 if DARK in states else 0


def render(st: dict[str, Any]) -> str:
    c = st["coverage"]
    L = [f"status — {st['org']} at {st['at']}", f"  {st['headline']}", ""]
    for t in st["tiles"]:
        L.append(f"[{t['state']:<5}] {t['title']}  ({t['tier']}: {st['tiers'].get(t['tier'], 'several sources')})")
        for line in t["lines"]:
            L.append(f"        {line}")
        if t["state"] != RED:
            L.append(f"        broken looks like: {t['broken_looks_like']}")
        L.append("")
    L.append(f"read {c['measured']} of {c['tiles']} tiles"
             + (f"; dark: {', '.join(c['dark'])}" if c["dark"] else "")
             + (f"; facts {c['facts_gathered_at']} ({c['facts_age_hours']}h old)" if c["facts_gathered_at"] else "; gathered live"))
    L.append(f"sessions tier: {c['sessions_tier']}")
    if c["could_not_read"]:
        L.append("could not read: " + "; ".join(c["could_not_read"]))
    return "\n".join(L) + "\n"
