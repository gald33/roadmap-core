"""The suite (SPEC §18, 0.16.0): every tool an org's ports need, installed as one thing, modular by port.

org-core is one of six modules — roadmap-core, switchboard, repoctx, the built-in checks and tickets
tools, the org's own database (a service reached, never installed) and `gh` are the others. Until
0.16.0 each org installed them from its own SessionStart scripts: NumeroTech's `session-start.sh`
and Lucille's five `cloud_*_setup.sh`, two independent authorings of the same install, each carrying
a lesson the other had to learn again (`--ignore-installed cryptography`, row 36; the presence gate,
row 87; an under-pinned roadmap-core, Lucille 2026-09-19). The install is now rendered: `org apply`
writes `.claude/hooks/org-setup.sh` from the manifest's ports and its optional `suite:` block, wires
it first in `.claude/settings.json`, declares the MCP servers in `.mcp.json`, and every session start
ends with one machine-readable report that the roles' records carry and the doctor reads (check 21).

Policies — how a module reaches a container:
  vendored   a wheel the repository carries (org-core; row 54); installed by version, never behind a presence gate
  pinned     a PyPI spec with a range; pip is the comparator: satisfied is a no-op, outside the range reinstalls
  tracking   PyPI's current release, unpinned and upgraded once a day (switchboard: a stale client fails silently)
  builtin    inside org-core (checks-core, tickets-core); nothing to install, enabled by the port
  service    a thing reached, not installed (the org's database behind prod_read); the doctor probes it
  external   present in the environment or installed by the org's own scripts (gh); probed, reported
"""

from __future__ import annotations

import datetime as dt
import importlib.metadata as md
import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import __version__
from .render import render_base, sha256
from .vendor import DIST_NAME, HOOK_SNIPPET, WHEELS_REL, vendored_wheel, wheel_version

SETUP_REL = ".claude/hooks/org-setup.sh"
SETTINGS_REL = ".claude/settings.json"
MCP_REL = ".mcp.json"
REPORT_NAME = "org-setup-report.json"
TEMPLATE = Path(__file__).parent / "templates" / "setup.core.sh"
HOOK_COMMAND = 'bash "${CLAUDE_PROJECT_DIR:-.}/' + SETUP_REL + '" || true'
HEAD_PREFIX = "# org-core: role=org file=setup base="

POLICIES = ("vendored", "pinned", "tracking", "builtin", "service", "external")
#: a token in a SessionStart hook command that names a script in the repo (`bash "${CLAUDE_PROJECT_DIR:-.}/scripts/x.sh" || true`)
_HOOK_SCRIPT_RE = re.compile(r"""[^\s"']+\.sh\b""")
_HOOK_PREFIX_RE = re.compile(r"^\$\{CLAUDE_PROJECT_DIR(?::-\.)?\}/|^\$CLAUDE_PROJECT_DIR/|^\./")
PIP_POLICIES = ("pinned", "tracking")

#: the modules, in install order; `enabled` and the port-bound fields are derived per manifest by `suite_of`
DEFAULT_SUITE: dict[str, dict[str, Any]] = {
    "org-core": {"policy": "vendored", "dist": DIST_NAME, "cli": "org", "port": None},
    "switchboard": {"policy": "tracking", "spec": "agent-switchboard[all]", "dist": "agent-switchboard", "cli": "switchboard", "mcp": "switchboard", "port": "coordination",
                    "register": True,
                    # the Debian image ships cryptography 41 with no RECORD file, so a plain install aborts uninstalling it (row 36)
                    "install_args": ["--ignore-installed", "cryptography"],
                    "post_install": ['python3 -c "import cffi" >/dev/null 2>&1 || pipi --force-reinstall cffi >/dev/null 2>&1 || true']},
    "roadmap-core": {"policy": "pinned", "spec": "roadmap-core[files]>=0.3.1,<0.4", "dist": "roadmap-core", "cli": "roadmap", "mcp": "roadmap", "port": "work_store"},
    "repoctx": {"policy": "pinned", "spec": "repoctx-mcp>=1.6", "dist": "repoctx-mcp", "cli": "repoctx", "mcp": "repoctx", "port": "code_context"},
    "checks": {"policy": "builtin", "port": "checks"},
    "tickets": {"policy": "builtin", "port": "tickets"},
    "db": {"policy": "service", "port": "prod_read"},
    "gh": {"policy": "external", "cli": "gh", "port": "vcs"},
}
OVERRIDABLE = ("enabled", "spec", "cli", "mcp", "register", "policy", "env", "install_args")


@dataclass
class Suite:
    modules: dict[str, dict[str, Any]]
    cloud_only: bool = True
    problems: list[str] = field(default_factory=list)

    def enabled(self) -> dict[str, dict[str, Any]]:
        return {k: v for k, v in self.modules.items() if v.get("enabled")}

    def mcp_servers(self) -> list[tuple[str, str]]:
        """(module, server name) for every enabled module that declares an MCP server."""
        return [(k, v["mcp"]) for k, v in self.enabled().items() if v.get("mcp")]


def dist_of(spec: str | None) -> str | None:
    if not spec:
        return None
    m = re.match(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)", spec)
    return m.group(1).lower().replace("_", "-") if m else None


def suite_of(manifest: dict[str, Any]) -> Suite:
    """The suite this manifest needs: defaults per module, enablement derived from the ports, the `suite:` block layered last."""
    ports = manifest.get("ports") or {}
    block = manifest.get("suite") or {}
    overrides = block.get("modules") or {}
    problems: list[str] = []
    out: dict[str, dict[str, Any]] = {}
    ws = ports.get("work_store") or {}
    co = ports.get("coordination") or {}
    for name, base in DEFAULT_SUITE.items():
        cfg: dict[str, Any] = {k: (list(v) if isinstance(v, list) else v) for k, v in base.items()}
        cfg["env"] = {}
        if name == "org-core":
            cfg["enabled"] = True
        elif name == "switchboard":
            cfg["enabled"] = bool(co)
            if co:
                cfg["url"], cfg["workspace"] = co.get("url"), co.get("workspace")
                cfg["env"] = {"SWITCHBOARD_URL": str(co.get("url", "")), "SWITCHBOARD_WORKSPACE": str(co.get("workspace", ""))}
        elif name == "roadmap-core":
            cfg["enabled"] = bool(ws)
            cfg["mode"] = ws.get("mode")
            cfg["cli"] = ws.get("cli") or cfg["cli"]
            if ws.get("mode") == "files":
                cfg["env"] = {"ROADMAP_SOURCE": "local"}
            else:
                cfg["mcp"] = None    # a served store is the org's backend; roadmap-mcp in local mode would read a different store
        elif name == "repoctx":
            cfg["enabled"] = "code_context" in ports
        elif name == "checks":
            cfg["enabled"] = (ports.get("checks") or {}).get("tool") == "checks-core"
        elif name == "tickets":
            cfg["enabled"] = (ports.get("tickets") or {}).get("tool") in ("in-app", "github-issues")
        elif name == "db":
            cfg["enabled"] = "prod_read" in ports
            cfg["method"] = (ports.get("prod_read") or {}).get("method")
        elif name == "gh":
            cfg["enabled"] = (ports.get("vcs") or {}).get("tool", "github") == "github"
        ov = overrides.get(name) or {}
        for k in OVERRIDABLE:
            if k not in ov:
                continue
            if k == "env":
                cfg["env"] = {**cfg["env"], **{str(a): str(b) for a, b in (ov["env"] or {}).items()}}
            elif k == "policy":
                if base["policy"] in PIP_POLICIES and ov[k] in PIP_POLICIES:
                    cfg["policy"] = ov[k]
                else:
                    problems.append(f"suite.modules.{name}.policy: {ov[k]!r} — {name} is {base['policy']}; only a pinned/tracking module may switch between those two")
            elif k in ("spec", "install_args") and base["policy"] not in PIP_POLICIES:
                problems.append(f"suite.modules.{name}.{k}: {name} is {base['policy']}, not installed from PyPI")
            elif k == "mcp" and "mcp" not in base:
                problems.append(f"suite.modules.{name}.mcp: {name} has no MCP server")
            elif k == "register" and name != "switchboard":
                problems.append(f"suite.modules.{name}.register: only switchboard registers")
            else:
                cfg[k] = ov[k]
        if cfg.get("spec"):
            cfg["dist"] = dist_of(cfg["spec"]) or cfg.get("dist")
        for a, b in cfg["env"].items():
            if not re.fullmatch(r"[A-Z_][A-Z0-9_]*", a) or "'" in b or "\n" in b:
                problems.append(f"suite.modules.{name}.env: {a}={b!r} is not a shell-safe export")
        out[name] = cfg
    for name in overrides:
        if name not in DEFAULT_SUITE:
            problems.append(f"suite.modules.{name}: not a suite module (one of {', '.join(DEFAULT_SUITE)})")
    return Suite(out, cloud_only=bool(block.get("cloud_only", True)), problems=problems)


def _modules_json(suite: Suite) -> str:
    rows = []
    for name, cfg in suite.enabled().items():
        cli = str(cfg.get("cli") or "")
        bare = cli if cli and " " not in cli and "/" not in cli else None    # `python scripts/roadmap.py` is the org's script, not a PATH probe
        rows.append({"name": name, "policy": cfg["policy"], "dist": cfg.get("dist"), "cli": bare, "mcp": cfg.get("mcp"), "spec": cfg.get("spec")})
    text = json.dumps(rows, ensure_ascii=False)
    if "'''" in text:
        raise ValueError("a suite value contains ''' — not renderable into the report block")
    return text


def render_setup(manifest: dict[str, Any], suite: Suite | None = None) -> tuple[str, str]:
    """(script text, template sha256). The first line carries the head marker `# org-core: role=org file=setup base=<version>`."""
    suite = suite or suite_of(manifest)
    src = TEMPLATE.read_text()
    ctx = {
        "org_id": manifest["org"]["id"],
        "org_core_version": __version__,
        "cloud_only": suite.cloud_only,
        "modules": [dict(cfg, name=name) for name, cfg in suite.enabled().items()],
        "hook_snippet": HOOK_SNIPPET.rstrip("\n"),
        "modules_json": _modules_json(suite),
        "wheels_rel": WHEELS_REL,
        "head": HEAD_PREFIX + __version__,
    }
    text = re.sub(r"\n{3,}", "\n\n", render_base(src, ctx))
    return text, sha256(src)


def head_version(text: str) -> str | None:
    """The org-core version the script's first line names, or None when the file is not an org-setup script."""
    for line in text.split("\n", 3)[:3]:
        if line.startswith(HEAD_PREFIX):
            return line[len(HEAD_PREFIX):].split()[0]
    return None


# --- the MCP servers the suite declares -----------------------------------------------------------

REPOCTX_LAUNCH = ('for py in python3 python; do command -v "$py" >/dev/null 2>&1 && "$py" -c "import repoctx.mcp_server" >/dev/null 2>&1 '
                  '&& exec "$py" -m repoctx.mcp_server; done; command -v uv >/dev/null 2>&1 && exec uv run --no-project --with {spec} python -m repoctx.mcp_server; '
                  'python3 -m pip install --quiet --break-system-packages {spec} 1>&2 && exec python3 -m repoctx.mcp_server; '
                  'echo "repoctx: could not launch the MCP server (no Python with repoctx-mcp, no uv, and pip install failed). Fix with: pip install {spec}" >&2; exit 1')
ROADMAP_LAUNCH = ("command -v roadmap-mcp >/dev/null 2>&1 && exec roadmap-mcp; command -v uvx >/dev/null 2>&1 && exec uvx --from '{spec}' roadmap-mcp; "
                  "echo 'roadmap: roadmap-mcp not found and uvx unavailable; pip install \"{spec}\"' >&2; exit 127")


def mcp_definition(module: str, cfg: dict[str, Any]) -> dict[str, Any]:
    """The server entry `.mcp.json` gets when the org declares none under that name (an existing entry is never rewritten)."""
    if module == "switchboard":
        return {"command": "switchboard-mcp", "env": {"SWITCHBOARD_URL": str(cfg.get("url", "")), "SWITCHBOARD_WORKSPACE": str(cfg.get("workspace", ""))}}
    if module == "repoctx":
        spec = cfg.get("spec") or "repoctx-mcp"
        return {"command": "sh", "args": ["-c", REPOCTX_LAUNCH.format(spec=json.dumps(spec) if " " in spec else f"'{spec}'")]}
    if module == "roadmap-core":
        return {"command": "sh", "env": {"ROADMAP_SOURCE": "local"}, "args": ["-c", ROADMAP_LAUNCH.format(spec=cfg.get("spec") or "roadmap-core[files]")]}
    raise ValueError(f"{module} declares no MCP server")


# --- the report a session start writes -----------------------------------------------------------

def report_path() -> Path:
    return Path(os.environ.get("TMPDIR") or "/tmp") / REPORT_NAME


def read_report(path: Path | None = None) -> dict[str, Any] | None:
    p = path or report_path()
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def compact(report: dict[str, Any] | None) -> dict[str, Any]:
    """What a role's record carries: `{org_core: "0.16.0", switchboard: "2.4.1", …}` — the installed modules' versions, nothing
    else; `{"report": "absent"}` when no session start wrote a report here. A record whose `suite` is `{}` was written by a
    capture line that failed (`org` not on PATH, or a usage error): the record then says nothing about its container, and
    check 21 says so rather than reading it as a rollout lag (Reed on NumeroTech #210, 2026-09-20, row 91)."""
    if not report:
        return {"report": "absent"}
    out: dict[str, Any] = {}
    for name, m in (report.get("modules") or {}).items():
        if m.get("policy") in ("builtin", "service"):
            continue
        out[name.replace("-", "_")] = m.get("version")
    return out


# --- probes: what this container has, against what the tree says it should ----------------------

def _dist_version(dist: str | None) -> str | None:
    if not dist:
        return None
    try:
        return md.version(dist)
    except md.PackageNotFoundError:
        return None


def _cli_version(cli: str | None) -> str | None:
    """`<cli> --version`'s first version number, None when the command is not on PATH or prints none."""
    if not cli or shutil.which(cli) is None:
        return None
    try:
        p = subprocess.run([cli, "--version"], capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.SubprocessError):
        return None
    m = re.search(r"\d+(\.\d+)+", (p.stdout or "") + (p.stderr or ""))
    return m.group(0) if m else None


def _satisfies(spec: str | None, version: str | None) -> bool | None:
    """Whether `version` satisfies the spec's range; None when it cannot be judged (no packaging, or no range)."""
    if not spec or not version:
        return None
    try:
        from packaging.requirements import Requirement  # type: ignore
        from packaging.version import Version  # type: ignore
    except Exception:  # noqa: BLE001
        try:
            from pip._vendor.packaging.requirements import Requirement  # type: ignore
            from pip._vendor.packaging.version import Version  # type: ignore
        except Exception:  # noqa: BLE001
            return None
    try:
        req = Requirement(spec)
    except Exception:  # noqa: BLE001
        return None
    if not str(req.specifier):
        return None
    try:
        return req.specifier.contains(Version(version), prereleases=True)
    except Exception:  # noqa: BLE001
        return None


def check(repo: Path, manifest: dict[str, Any], suite: Suite | None = None, lock: dict[str, Any] | None = None, *, runtime: bool = True) -> list[dict[str, Any]]:
    """One row per enabled module plus the wiring rows: `{id, ok, expected, found, why}`. `runtime=False` reads the tree only."""
    suite = suite or suite_of(manifest)
    rows: list[dict[str, Any]] = []
    for name, cfg in suite.enabled().items():
        row: dict[str, Any] = {"id": name, "policy": cfg["policy"], "ok": None, "expected": None, "found": None, "why": ""}
        if cfg["policy"] == "vendored":
            w = vendored_wheel(repo)
            row["expected"] = wheel_version(w) if w else None
            if not w:
                row["ok"], row["why"] = False, f"no wheel under {WHEELS_REL}/ — run `org vendor --repo .`"
            elif runtime:
                row["found"] = _cli_version(cfg.get("cli") or "org") or _dist_version(cfg.get("dist"))
                row["ok"] = row["found"] == row["expected"]
                row["why"] = "" if row["ok"] else (f"installed {row['found'] or 'none'}, the tree vendors {row['expected']} — the hook did not run, or ran before this wheel (rows 87, 88)")
            else:
                row["ok"], row["why"] = True, "wheel present"
        elif cfg["policy"] in PIP_POLICIES:
            row["expected"] = cfg.get("spec")
            if runtime:
                row["found"] = _dist_version(cfg.get("dist"))
                sat = _satisfies(cfg.get("spec"), row["found"])
                row["ok"] = row["found"] is not None and sat is not False
                row["why"] = "" if row["ok"] else ("not installed" if row["found"] is None else f"{row['found']} is outside {cfg.get('spec')}")
            else:
                row["ok"], row["why"] = True, "installed by the setup script at session start"
        elif cfg["policy"] == "builtin":
            row["expected"], row["found"], row["ok"] = "org-core", __version__, True
            row["why"] = f"inside org-core ({cfg.get('port')} port)"
        elif cfg["policy"] == "service":
            row["expected"] = cfg.get("method")
            row["ok"], row["why"] = None, "a service reached through the prod_read port — the doctor's check 6 probes it, the setup installs nothing"
        elif cfg["policy"] == "external":
            if runtime:
                p = shutil.which(cfg.get("cli") or name)
                row["found"] = p
                row["ok"] = p is not None
                row["why"] = "" if p else f"`{cfg.get('cli') or name}` not on PATH — the environment or the org's own scripts provide it, not the suite"
            else:
                row["ok"], row["why"] = None, "probed at runtime only"
        rows.append(row)
    # the wiring: the script, the hook, the MCP servers
    setup = repo / SETUP_REL
    rendered, _ = render_setup(manifest, suite)
    locked = ((lock or {}).get("files") or {}).get(SETUP_REL) or {}
    if not setup.exists():
        rows.append({"id": "setup-script", "ok": False, "expected": SETUP_REL, "found": None, "why": f"{SETUP_REL} missing — run `org apply`"})
    else:
        text = setup.read_text()
        same = sha256(text) == sha256(rendered) or (bool(locked) and sha256(text) == locked.get("rendered_sha256"))
        rows.append({"id": "setup-script", "ok": same, "expected": head_version(rendered), "found": head_version(text),
                     "why": "" if same else f"{SETUP_REL} differs from what this org-core renders — run `org upgrade`"})
    settings = _load_json(repo / SETTINGS_REL)
    wired = bool(settings) and any(SETUP_REL in str(h.get("command", "")) for g in (settings.get("hooks", {}).get("SessionStart") or []) for h in (g.get("hooks") or []))
    rows.append({"id": "settings-hook", "ok": wired, "expected": HOOK_COMMAND, "found": None, "why": "" if wired else f"{SETTINGS_REL} has no SessionStart hook running {SETUP_REL} — no session installs the suite"})
    rows.extend(duplicate_installs(repo, suite))
    mcp = _load_json(repo / MCP_REL)
    declared = set((mcp or {}).get("mcpServers") or {})
    enabled_list = (settings or {}).get("enabledMcpjsonServers")
    for module, server in suite.mcp_servers():
        missing = server not in declared
        not_enabled = enabled_list is not None and server not in enabled_list
        rows.append({"id": f"mcp:{server}", "ok": not (missing or not_enabled), "expected": server, "found": None if missing else "declared",
                     "why": (f"{MCP_REL} declares no `{server}` server" if missing else "") + ("; " if missing and not_enabled else "") + (f"`{server}` is not in {SETTINGS_REL} enabledMcpjsonServers" if not_enabled else "")})
    return rows


def hooked_scripts(repo: Path) -> list[str]:
    """The repo scripts `.claude/settings.json` runs on SessionStart — the only ones that run beside the setup script. A base-image
    bake such as Lucille's `scripts/cloud_setup.sh` installs the same modules and is not a race: it ran before any session."""
    settings = _load_json(repo / SETTINGS_REL) or {}
    out: list[str] = []
    for g in (settings.get("hooks") or {}).get("SessionStart") or []:
        for h in (g.get("hooks") or []) if isinstance(g, dict) else []:
            for tok in _HOOK_SCRIPT_RE.findall(str(h.get("command", "")) if isinstance(h, dict) else ""):
                rel = _HOOK_PREFIX_RE.sub("", tok)
                if rel not in out:
                    out.append(rel)
    return out


def duplicate_installs(repo: Path, suite: Suite) -> list[dict[str, Any]]:
    """One FAIL row per SessionStart-hooked script that pip-installs a module the suite installs. Hooks run in parallel,
    so on a cold container the two pips race for one site-packages — and the org's copy is usually unpinned (NumeroTech's
    `session-start.sh` installed `roadmap-core[files]` with no floor beside the suite's `>=0.3.1,<0.4`)."""
    names: dict[str, str] = {}
    for module, cfg in suite.enabled().items():
        if cfg["policy"] == "vendored":
            names[f"{module}"] = "org_core-"
        elif cfg["policy"] in PIP_POLICIES and cfg.get("dist"):
            names[module] = cfg["dist"]
    out: list[dict[str, Any]] = []
    for rel in hooked_scripts(repo):
        f = repo / rel
        if rel == SETUP_REL or not f.is_file():
            continue
        hits: list[str] = []
        for line in f.read_text(errors="replace").splitlines():
            s = line.strip()
            if s.startswith("#") or "pip install" not in s and "pip3 install" not in s:
                continue
            for module, needle in names.items():
                if needle in s and module not in hits:
                    hits.append(module)
        if hits:
            out.append({"id": f"duplicate:{rel}", "ok": False, "expected": f"one install, {SETUP_REL}", "found": ", ".join(hits),
                        "why": f"{rel} pip-installs {', '.join(hits)} beside {SETUP_REL} — SessionStart hooks run in parallel, so on a cold container two pips race for one site-packages, and the org's copy carries its own pin or none; retire it (the suite is the one place that installs)"})
    return out


def _load_json(p: Path) -> dict[str, Any] | None:
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def render_check(rows: list[dict[str, Any]]) -> str:
    lines = []
    for r in rows:
        status = "PASS" if r["ok"] else ("FAIL" if r["ok"] is False else "-")
        what = r.get("policy", "")
        found = r.get("found")
        exp = r.get("expected")
        lines.append(f"  {status:<5} {r['id']:<16} {what:<9} " + (f"{found} " if found else "") + (f"(expected {exp}) " if exp and found != exp else "") + (r.get("why") or ""))
    bad = sum(1 for r in rows if r["ok"] is False)
    lines.append("")
    lines.append(f"suite: {len(rows)} rows, {bad} bad")
    return "\n".join(lines)


def render_status(report: dict[str, Any] | None) -> str:
    if not report:
        return f"no setup report at {report_path()} — the setup script has not run in this container (hook not wired, org-core before 0.16.0, or a local machine with cloud_only)"
    at = report.get("at")
    age = ""
    try:
        t = dt.datetime.fromisoformat(str(at).replace("Z", "+00:00"))
        age = f" ({(dt.datetime.now(dt.timezone.utc) - t).total_seconds() / 3600:.1f}h ago)"
    except (TypeError, ValueError):
        pass
    lines = [f"setup report {at}{age}: org-core {report.get('org_core') or 'none'}"]
    for name, m in (report.get("modules") or {}).items():
        ok = m.get("ok")
        lines.append(f"  {'ok  ' if ok else ('FAIL' if ok is False else '-   ')} {name:<14} {m.get('policy', ''):<9} {m.get('version') or '-'}")
    if report.get("installed"):
        lines.append("installed this start: " + ", ".join(report["installed"]))
    if report.get("failed"):
        lines.append("FAILED this start: " + ", ".join(report["failed"]))
    return "\n".join(lines)
