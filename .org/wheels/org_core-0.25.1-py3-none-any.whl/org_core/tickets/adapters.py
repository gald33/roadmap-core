"""Where the rows come from: a file a role saved, psql over a DSN, or Lucille's admin API. The core never knows which."""

from __future__ import annotations

import json
import os
import subprocess
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

GENERIC_TICKETS_SQL = (
    "select id, source, reporter_ref, feedback_text, status, kinds, refs, metadata, sentiment_score, "
    "deployed_version, created_at, updated_at from feedback_tickets order by created_at desc"
)
GENERIC_NOTES_SQL = "select ticket_id, author, note, meta, created_at from feedback_ticket_notes order by created_at"
LUCILLE_TICKETS_SQL = (
    "select id, user_id::text as reporter_ref, source, feedback_text, status, kinds, metadata_json as metadata, "
    "sentiment_score, deployed_version, created_at from feedback_tickets order by created_at desc"
)
LUCILLE_NOTES_SQL = "select ticket_id, author, note, meta, created_at from feedback_ticket_notes order by created_at"


def sql_for(dialect: str = "generic") -> dict[str, str]:
    """The read-only SELECTs a role runs through the org's read port (the Supabase MCP, psql over SSH) and saves as rows."""
    if dialect == "lucille":
        return {"tickets": LUCILLE_TICKETS_SQL, "notes": LUCILLE_NOTES_SQL}
    return {"tickets": GENERIC_TICKETS_SQL, "notes": GENERIC_NOTES_SQL}


def _rows(payload: Any, key: str) -> list[dict[str, Any]]:
    if isinstance(payload, dict):
        payload = payload.get(key) or payload.get("rows") or []
    return [r for r in (payload or []) if isinstance(r, dict)]


def load_tickets_json(path: Path) -> list[dict[str, Any]]:
    return _rows(json.loads(Path(path).read_text()), "tickets")


def load_notes_json(path: Path) -> list[dict[str, Any]]:
    return _rows(json.loads(Path(path).read_text()), "notes")


def attach_notes(tickets: list[dict[str, Any]], notes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_ticket: dict[str, list[dict[str, Any]]] = {}
    for n in notes:
        by_ticket.setdefault(str(n.get("ticket_id") or "").lower(), []).append(n)
    for t in tickets:
        t.setdefault("notes", by_ticket.get(str(t.get("id") or "").lower(), []))
    return tickets


def load_items(path: Path) -> list[dict[str, Any]]:
    """Roadmap items from `roadmap/items/*.yaml` (files mode) or a JSON dump of a served store."""
    path = Path(path)
    if path.is_dir():
        import yaml

        items = []
        for p in sorted(path.glob("*.yaml")):
            d = yaml.safe_load(p.read_text()) or {}
            d.setdefault("id", p.stem)
            items.append(d)
        return items
    return _rows(json.loads(path.read_text()), "items")


def psql_rows(dsn: str, sql: str, timeout: int = 120) -> list[dict[str, Any]]:
    """Run one read-only SELECT through psql and get rows as JSON. Never for writes: the read port is read-only by rule."""
    wrapped = f"select coalesce(json_agg(t), '[]'::json) from ({sql.rstrip().rstrip(';')}) t"
    p = subprocess.run(["psql", dsn, "-X", "-A", "-t", "-v", "ON_ERROR_STOP=1", "-c", wrapped], capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError(f"psql failed: {(p.stderr or p.stdout).strip()[:300]}")
    return _rows(json.loads(p.stdout.strip() or "[]"), "rows")


def _get(base_url: str, token: str, path: str, params: dict[str, Any] | None = None, timeout: int = 30) -> Any:
    url = base_url.rstrip("/") + path + (("?" + urllib.parse.urlencode(params)) if params else "")
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 — the org's own backend
        return json.loads(resp.read().decode("utf-8") or "null")


def api_tickets(base_url: str, token: str, page_size: int = 1000, get=_get) -> tuple[list[dict[str, Any]], bool]:
    """Lucille's `/admin/feedback`, paged to exhaustion — a page shorter than the page size is the end of the table,
    which is the only way completeness is ESTABLISHED rather than assumed (review_feedback.fetch_all)."""
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    offset = 0
    while True:
        page = get(base_url, token, "/admin/feedback", {"limit": page_size, "offset": offset})
        if not isinstance(page, list):
            raise RuntimeError(f"expected a list from /admin/feedback, got {type(page).__name__}")
        for row in page:
            key = str(row.get("id"))
            if key not in seen:
                seen.add(key)
                rows.append(row)
        if len(page) < page_size:
            return rows, True
        offset += page_size


def api_items(base_url: str, token: str, get=_get) -> list[dict[str, Any]]:
    return _rows(get(base_url, token, "/admin/roadmap"), "items")


def api_notes(base_url: str, token: str, ticket_id: str, get=_get) -> list[dict[str, Any]]:
    return _rows(get(base_url, token, f"/admin/feedback/{ticket_id}/notes"), "notes")


def token_from_env(name: str, file: str | None = None) -> str:
    """Read a credential somebody already approved: the env var, else a cache file (Lucille: ~/.lucille/admin.jwt,
    which its own scripts read the same way). Never mint one here — that gate is the operator's."""
    value = os.environ.get(name, "").strip()
    if value:
        return value
    if file:
        p = Path(os.path.expanduser(file))
        if p.exists():
            value = p.read_text().strip()
            if value:
                return value
    raise RuntimeError(f"{name} is not set" + (f" and {file} is absent or empty" if file else "") + " — pass --tickets <rows.json> to run offline, or set the credential")
