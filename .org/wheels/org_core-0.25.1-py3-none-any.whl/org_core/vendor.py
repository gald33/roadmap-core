"""The tool ships with the org (SPEC §6, Appendix A row 54).

A routine-fired session holds no credential and cannot fetch a private repository,
so `pip install git+https://…/org-core` fails there — measured 2026-09-18 in both
installed orgs: their doctors ran 0 of 18 checks on their first fire. `org vendor`
writes a wheel of the running org-core into the org's repository so the
session-start hook installs it from disk, before any network path.

The wheel is built from the installed package itself, not from a source tree or a
build backend: every file under the `org_core` package plus a dist-info the way
PEP 427 lays it out. That makes `org vendor` work wherever `org` runs.
"""

from __future__ import annotations

import base64
import hashlib
import re
import zipfile
from pathlib import Path

from . import __version__

DIST_NAME = "org-core"
PACKAGE = "org_core"
WHEELS_REL = ".org/wheels"
# Mirrors [project] in pyproject.toml; a test asserts they agree.
DEPENDENCIES = ["pyyaml>=6", "jinja2>=3.1", "jsonschema>=4.18"]
REQUIRES_PYTHON = ">=3.11"
SUMMARY = ("The org builder: installs, verifies and measures a named cast of engineering agent roles "
           "into a repository, and learns better defaults from the fleet of installed orgs.")
_SKIP_DIRS = {"__pycache__"}
_SKIP_SUFFIXES = {".pyc", ".pyo"}
_FIXED_TIME = (1980, 1, 1, 0, 0, 0)   # reproducible: the wheel of a version is one artifact


def wheel_name(version: str = __version__) -> str:
    return f"{PACKAGE}-{version}-py3-none-any.whl"


def wheel_version(path: Path) -> str | None:
    m = re.fullmatch(rf"{PACKAGE}-(?P<v>[^-]+)-py3-none-any\.whl", path.name)
    return m["v"] if m else None


def package_files() -> list[tuple[str, Path]]:
    """(archive path, source path) for every file the installed package carries."""
    root = Path(__file__).resolve().parent
    out: list[tuple[str, Path]] = []
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(root)
        if any(part in _SKIP_DIRS for part in rel.parts) or p.suffix in _SKIP_SUFFIXES:
            continue
        out.append((f"{PACKAGE}/{rel.as_posix()}", p))
    return out


def _record_hash(data: bytes) -> str:
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()


def build_wheel(dest_dir: Path, version: str = __version__) -> Path:
    """Write `<dest_dir>/org_core-<version>-py3-none-any.whl` from the installed package."""
    dest_dir.mkdir(parents=True, exist_ok=True)
    out = dest_dir / wheel_name(version)
    info = f"{PACKAGE}-{version}.dist-info"
    metadata = "\n".join(
        ["Metadata-Version: 2.1", f"Name: {DIST_NAME}", f"Version: {version}", f"Summary: {SUMMARY}",
         f"Requires-Python: {REQUIRES_PYTHON}"] + [f"Requires-Dist: {d}" for d in DEPENDENCIES]
    ) + "\n"
    wheel_meta = "Wheel-Version: 1.0\nGenerator: org-core\nRoot-Is-Purelib: true\nTag: py3-none-any\n"
    entry_points = "[console_scripts]\norg = org_core.cli:main\n"
    entries: list[tuple[str, bytes]] = [(arc, src.read_bytes()) for arc, src in package_files()]
    entries += [(f"{info}/METADATA", metadata.encode()), (f"{info}/WHEEL", wheel_meta.encode()),
                (f"{info}/entry_points.txt", entry_points.encode()), (f"{info}/top_level.txt", f"{PACKAGE}\n".encode())]
    record_lines = [f"{arc},{_record_hash(data)},{len(data)}" for arc, data in entries] + [f"{info}/RECORD,,"]
    entries.append((f"{info}/RECORD", ("\n".join(record_lines) + "\n").encode()))
    tmp = out.with_suffix(".whl.tmp")
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for arc, data in entries:
            zi = zipfile.ZipInfo(arc, date_time=_FIXED_TIME)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, data)
    tmp.replace(out)
    return out


def vendored_wheel(repo: Path) -> Path | None:
    """The one wheel the repo carries, or None. Two is a defect and reads as the newest by version string."""
    d = repo / WHEELS_REL
    if not d.is_dir():
        return None
    wheels = sorted((p for p in d.glob(f"{PACKAGE}-*-py3-none-any.whl")), key=lambda p: wheel_version(p) or "")
    return wheels[-1] if wheels else None


def vendor(repo: Path, version: str = __version__) -> Path:
    """Write this org-core's wheel into `<repo>/.org/wheels/`, removing older ones."""
    d = repo / WHEELS_REL
    d.mkdir(parents=True, exist_ok=True)
    for old in d.glob(f"{PACKAGE}-*-py3-none-any.whl"):
        if old.name != wheel_name(version):
            old.unlink()
    return build_wheel(d, version)


HOOK_MARKER = "org-core: install by version"
HOOK_SNIPPET = f"""# {HOOK_MARKER} — the newest org-core wheel this container can see, the checkout's or origin/main's,
# installed whenever its version differs from the org-core on PATH (SPEC Appendix A rows 54, 87, 88).
# Never gate this on `command -v org`: a restarted persistent session keeps the binary its first container
# installed (row 87). And a persistent session lives on its own branch, whose hook and wheel can be days
# behind main — so main's wheel is read too and the newer of the two wins (row 88, Marshal 2026-09-20).
REPO="${{CLAUDE_PROJECT_DIR:-${{REPO:-.}}}}"
WHEEL="$(ls "$REPO"/{WHEELS_REL}/{PACKAGE}-*-py3-none-any.whl 2>/dev/null | sort -V | tail -n 1)"
MAIN_WHEEL="$(git -C "$REPO" fetch -q origin main 2>/dev/null; git -C "$REPO" ls-tree -r --name-only origin/main -- {WHEELS_REL}/ 2>/dev/null | grep -E '{PACKAGE}-.*-py3-none-any\\.whl$' | sort -V | tail -n 1)"
if [ -n "$MAIN_WHEEL" ] && [ "$(basename "$MAIN_WHEEL")" != "$(basename "$WHEEL")" ] \\
   && [ "$(printf '%s\\n%s\\n' "$(basename "$WHEEL")" "$(basename "$MAIN_WHEEL")" | sort -V | tail -n 1)" = "$(basename "$MAIN_WHEEL")" ]; then
  mkdir -p /tmp/org-core-wheels && git -C "$REPO" show "origin/main:$MAIN_WHEEL" > "/tmp/org-core-wheels/$(basename "$MAIN_WHEEL")" 2>/dev/null \\
    && WHEEL="/tmp/org-core-wheels/$(basename "$MAIN_WHEEL")" && log "org-core: origin/main vendors $(basename "$MAIN_WHEEL"), newer than this branch's"
fi
if [ -n "$WHEEL" ]; then
  WANT="$(basename "$WHEEL" | sed -E 's/^{PACKAGE}-([0-9][0-9.]*)-.*/\\1/')"
  HAVE="$(org --version 2>/dev/null | grep -oE '[0-9]+(\\.[0-9]+)+' | head -n 1)"
  if [ "$HAVE" != "$WANT" ]; then
    python3 -m pip install --quiet --break-system-packages "$WHEEL" 2>/tmp/org-core-install.err \\
      && log "org-core ${{HAVE:-none}} -> $WANT from $(basename "$WHEEL")" \\
      || log "org-core install from $WHEEL failed: $(tail -3 /tmp/org-core-install.err | tr '\\n' ' ')"
  fi
else
  log "no vendored org-core wheel under {WHEELS_REL}/ — run \\`org vendor --repo .\\` from a session that holds org-core"
fi
"""

#: the two shapes of a presence gate around the wheel install: `if ! command -v org` (NumeroTech's hook until 2026-09-20)
#: and `if command -v org … exit 0` (Lucille's cloud_org_core_setup.sh). Either leaves a restarted container on its first org-core.
PRESENCE_GATE_RE = re.compile(r"if\s+!\s*command\s+-v\s+org\b|if\s+command\s+-v\s+org[^\n]*then[ \t]*\n(?:[^\n]*\n){0,3}?[ \t]*exit\s+0", re.M)


def hook_installs_by_version(text: str) -> tuple[bool | None, str]:
    """Read a session-start script: None when it installs no vendored wheel; False with the reason when it gates the
    install on `command -v org` or never compares `org --version` to the wheel; True when it carries the marker and
    the comparison (row 87)."""
    if f"{PACKAGE}-" not in text:
        return None, "installs no vendored org-core wheel"
    if PRESENCE_GATE_RE.search(text):
        return False, "gates the wheel install on `command -v org` — a restarted container keeps the org-core its first container installed and never installs the newer wheel (row 87)"
    if "org --version" not in text or HOOK_MARKER not in text:
        return False, f"installs the wheel without comparing `org --version` to the wheel's version (no `{HOOK_MARKER}` block; row 87)"
    return True, "installs the vendored wheel whenever its version differs from the org-core on PATH"
