"""`org verify` (SPEC.md §7): prove an install works, including the dead-role drill.

Each step names what it would print if the thing were broken. Steps that need
facts a session must gather say NEEDS_FACTS; nothing here passes by assertion.
The drill injects one role's absence at the doctor's read layer and requires
the doctor to call that role DEAD. It deliberately does not touch the live
board: a record deleted and restored would re-stamp as fresh, and the drill
would then mask exactly the death it exists to detect.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import doctor as dr
from .lock import read as read_lock
from .plan import make_plan
from .render import normalize, parse_managed, sha256
from .vendor import WHEELS_REL, hook_installs_by_version, vendored_wheel, wheel_version


@dataclass
class Step:
    id: str
    status: str
    text: str
    broken_looks_like: str


def _installed(repo: Path, manifest: dict[str, Any], packages: dict[str, Any]) -> list[Step]:
    plan = make_plan(repo, manifest, packages)
    by = plan.by_status()
    not_installed = [a for a in plan.actions if a.status != "unchanged"]
    if not_installed:
        return [Step("installed", dr.FAIL, f"{len(not_installed)} file(s) not at the package: " + ", ".join(f"{a.path} ({a.status})" for a in not_installed[:6]), "<path> (new|changed|markers-only) — apply has not been run, or the package moved")]
    return [Step("installed", dr.PASS, f"all {by['unchanged']} managed files match the package", "<path> (new|changed) — apply has not been run, or the package moved")]


def _tracked(repo: Path) -> list[Step]:
    """Every managed file, the lock and the wheel are ones git carries — tracked, not ignored, not merely on this disk.
    Lucille 2026-09-20 (row 93): `.claude/*` in .gitignore, the hook written by two applies, in no commit, and every step
    here PASSed because each read the disk. A fresh container reads the commit."""
    from . import gitfiles as gf
    broken = "<path>: IGNORED by .gitignore:<line> `<pattern>` / <path>: untracked — written by apply, committed by nobody"
    if not gf.is_git_repo(repo):
        return [Step("tracked", dr.PASS, "not the top of a git work tree — whether git carries the managed files is not checked here", broken)]
    lock = read_lock(repo)
    if not lock:
        return [Step("tracked", dr.FAIL, ".org/lock.yaml missing — nothing to check against", broken)]
    paths = [p for p in list(lock.get("files") or {}) + [".org/lock.yaml", str(lock.get("vendored_wheel") or "")] if p and (repo / p).exists()]
    bad: list[str] = []
    for rel in paths:
        if gf.tracked(repo, rel):
            continue
        ig = gf.ignored(repo, rel)
        bad.append(f"{rel}: IGNORED by {ig} — no commit can carry it; `org apply` whitelists it, then commit" if ig else f"{rel}: untracked — written by apply, committed by nobody; a fresh container will not have it")
    if bad:
        return [Step("tracked", dr.FAIL, f"{len(bad)} of {len(paths)} managed file(s) git does not carry: " + "; ".join(bad[:4]) + (" …" if len(bad) > 4 else ""), broken)]
    return [Step("tracked", dr.PASS, f"git carries all {len(paths)} managed files (tracked, none ignored)", broken)]


def _lock(repo: Path, manifest: dict[str, Any], packages: dict[str, Any]) -> list[Step]:
    lock = read_lock(repo)
    if not lock:
        return [Step("lock", dr.FAIL, ".org/lock.yaml missing — this repo was never applied", ".org/lock.yaml missing")]
    bad = []
    for path, meta in lock.get("files", {}).items():
        p = repo / path
        if not p.exists():
            bad.append(f"{path}: in the lock, not on disk")
        elif meta.get("kind") == "setup":
            # whole-file generated (SPEC §18): no project section, so the rendered hash is the comparison
            if sha256(p.read_text()) != meta.get("rendered_sha256"):
                bad.append(f"{path}: differs from what apply wrote — the setup script is generated from org.yaml; edits belong in `suite:` or the org's own scripts")
        else:
            text = p.read_text()
            try:
                managed = parse_managed(text)
            except ValueError as e:
                bad.append(f"{path}: content differs from what apply wrote — {e}")
                continue
            if managed is None:
                bad.append(f"{path}: no org-core markers — not a managed file any more")
            elif meta.get("base_sha256"):
                # the project section is the org's own text and is never compared (SPEC Appendix A, row 46:
                # NumeroTech's lock read 10/20 files as drift after three merged PRs that edited only project sections)
                if sha256(normalize(managed.base)) != meta["base_sha256"]:
                    bad.append(f"{path}: base section differs from what apply wrote (edited inside the managed markers, or the package moved)")
            elif sha256(text) != meta.get("rendered_sha256"):
                bad.append(f"{path}: content differs from what apply wrote (lock predates base hashes — run apply again)")
    if lock.get("manifest_version") != manifest.get("manifest_version"):
        bad.append(f"lock manifest_version {lock.get('manifest_version')} != manifest {manifest.get('manifest_version')}")
    if bad:
        return [Step("lock", dr.FAIL, "; ".join(bad[:5]), "<path>: content differs from what apply wrote")]
    return [Step("lock", dr.PASS, f"lock matches {len(lock.get('files', {}))} files, manifest_version {lock.get('manifest_version')}", "<path>: content differs")]


def _from_doctor(ctx: dr.Ctx, n: int, step_id: str) -> list[Step]:
    results = dr.run(ctx, only={n})
    r = results[0]
    return [Step(step_id, f.status, f.text, r.check.broken_looks_like) for f in r.findings]


def _records_ever(ctx: dr.Ctx) -> list[Step]:
    out = []
    for role in dr.clock_roles(ctx):
        key = ctx.report_key(role)
        try:
            rec = ctx.record(key)
        except dr.UnreachablePort as e:
            return [Step("records-ever", dr.UNREACHABLE, str(e), "no record at <key>")]
        out.append(Step("records-ever", dr.PASS if rec is not None else dr.FAIL, f"{role}: " + ("has fired at least once" if rec is not None else f"no record at {key} — never fired on this install"), "<role>: no record at <key> — never fired"))
    return out or [Step("records-ever", dr.FAIL, "no clock roles enabled", "no clock roles enabled")]


def _drill(ctx: dr.Ctx, role: str | None) -> list[Step]:
    roles = dr.clock_roles(ctx)
    if not roles:
        return [Step("drill", dr.FAIL, "no clock role to drill", "no clock role to drill")]
    chosen = role if role and role != "random" else random.choice(roles)
    if chosen not in roles:
        return [Step("drill", dr.FAIL, f"{chosen} is not an enabled clock role", "drill role not enabled")]
    drill_ctx = dr.Ctx(repo=ctx.repo, manifest=ctx.manifest, facts=ctx.facts, now=ctx.now)
    drill_ctx.board_get = ctx.board_get  # type: ignore[method-assign]  # share any stub/cache the caller provided
    drill_ctx.drill_absent = {ctx.report_key(chosen)}
    try:
        results = dr.run(drill_ctx, only={1})
    except dr.UnreachablePort as e:
        return [Step("drill", dr.UNREACHABLE, str(e), "the doctor did not report the killed role DEAD")]
    dead = [f for f in results[0].findings if f.status == dr.DEAD and f.text.startswith(chosen + ":")]
    summary = dr.summarize(results)
    detected = bool(dead) and chosen in summary["dead_roles"]
    return [Step("drill", dr.PASS if detected else dr.FAIL,
                 f"{chosen}: injected absent at the read layer → doctor " + ("reported DEAD and listed it" if detected else "did NOT report it DEAD — the org would not notice this role dying"),
                 "the doctor did not report the killed role DEAD")]


def _vendored(repo: Path) -> list[Step]:
    """The install path a cold container has (row 54): a wheel of the lock's org-core under .org/wheels/."""
    lock = read_lock(repo) or {}
    w = vendored_wheel(repo)
    if w is None:
        return [Step("vendored", dr.FAIL, f"no org-core wheel under {WHEELS_REL}/ — a routine-fired session cannot install org-core from a private repository; run `org vendor --repo .`", f"no wheel under {WHEELS_REL}/")]
    v = wheel_version(w)
    if lock.get("org_core") and v != lock["org_core"]:
        return [Step("vendored", dr.FAIL, f"{w.relative_to(repo)} is {v} but the lock was rendered by org-core {lock['org_core']} — run `org vendor --repo .` (or apply) again", "wheel version != lock org_core")]
    return [Step("vendored", dr.PASS, f"{w.relative_to(repo)} matches the lock (org-core {v})", f"no wheel under {WHEELS_REL}/")]


HOOK_GLOBS = (".claude/hooks/*.sh", "scripts/cloud_*.sh")


def _hook(repo: Path) -> list[Step]:
    """The install the hook performs (row 87): every session-start script that installs the vendored wheel must do it by
    version, never behind `command -v org` — the presence gate left both of NumeroTech's restarted sessions on 0.8.0 while
    main vendored 0.14.0 (2026-09-20)."""
    out: list[Step] = []
    for g in HOOK_GLOBS:
        for f in sorted(repo.glob(g)):
            ok, why = hook_installs_by_version(f.read_text(errors="replace"))
            if ok is None:
                continue
            out.append(Step("hook", dr.PASS if ok else dr.FAIL, f"{f.relative_to(repo)}: {why}", "<script>: gates the wheel install on `command -v org`, or never compares versions"))
    return out or [Step("hook", dr.FAIL, f"no session-start script under {', '.join(HOOK_GLOBS)} installs the vendored wheel — a cold or restarted container has no path to the org-core the lock names (rows 54, 87)", "no script installs the vendored wheel")]


def _suite(repo: Path, manifest: dict[str, Any]) -> list[Step]:
    """The suite's wiring in the tree (SPEC §18): the setup script at the package, wired in settings.json, every declared MCP
    server present and enabled, and no org-owned script installing the same modules beside it (hooks run in parallel: a
    second installer is a race, row 91). What a container actually installed is the runtime's to say — checks 6 and 21."""
    from . import suite as su

    lock = read_lock(repo) or {}
    rows = su.check(repo, manifest, lock=lock, runtime=False)
    wiring = [r for r in rows if r["id"] in ("setup-script", "settings-hook") or r["id"].startswith(("mcp:", "duplicate:"))]
    bad = [r for r in wiring if r["ok"] is False]
    if bad:
        return [Step("suite", dr.FAIL, "; ".join(r["why"] for r in bad[:4]), f"{su.SETUP_REL} missing / not wired in {su.SETTINGS_REL} / <server> not in {su.MCP_REL} / <script> pip-installs a suite module beside it")]
    mods = ", ".join(f"{r['id']} ({r['policy']})" for r in rows if r.get("policy"))
    return [Step("suite", dr.PASS, f"setup script at the package and wired; MCP servers declared and enabled; no other script installs a suite module; modules: {mods}", f"{su.SETUP_REL} missing / not wired / a duplicate install")]


def run_verify(repo: Path, manifest: dict[str, Any], packages: dict[str, Any], facts: dict[str, Any] | None = None, drill: str | None = "random", ctx: dr.Ctx | None = None) -> list[Step]:
    ctx = ctx or dr.Ctx(repo=repo, manifest=manifest, facts=facts or {})
    steps: list[Step] = []
    steps += _installed(repo, manifest, packages)
    steps += _tracked(repo)
    steps += _lock(repo, manifest, packages)
    steps += _vendored(repo)
    steps += _hook(repo)
    steps += _suite(repo, manifest)
    steps += _from_doctor(ctx, 6, "ports")
    steps += _from_doctor(ctx, 3, "triggers")
    steps += _records_ever(ctx)
    if drill:
        steps += _drill(ctx, drill)
    return steps


def summarize(steps: list[Step]) -> dict[str, Any]:
    ids = sorted({s.id for s in steps})
    return {
        "steps": len(ids),
        "bad": sum(1 for s in steps if s.status in dr.BAD),
        "needs_facts": sum(1 for s in steps if s.status == dr.NEEDS_FACTS),
        "unreachable": sum(1 for s in steps if s.status == dr.UNREACHABLE),
        "drill": next((s.status for s in steps if s.id == "drill"), None),
    }


def exit_code(steps: list[Step]) -> int:
    s = summarize(steps)
    if s["bad"]:
        return 1
    if s["unreachable"] or s["needs_facts"]:
        return 2
    return 0


def render_text(steps: list[Step]) -> str:
    lines = []
    for s in steps:
        lines.append(f"  {s.status:<15} {s.id:<13} {s.text}")
        if s.status in dr.BAD:
            lines.append(f"  {'':<15} {'':<13} broken looks like: {s.broken_looks_like}")
    sm = summarize(steps)
    lines.append("")
    lines.append(f"verify: {sm['bad']} bad; {sm['needs_facts']} need facts; {sm['unreachable']} unreachable; drill={sm['drill']}")
    if sm["needs_facts"] or sm["unreachable"]:
        lines.append("verify is NOT a pass while any step needs facts or a port is unreachable — gather the facts from a session holding the sessions port and re-run")
    return "\n".join(lines)
